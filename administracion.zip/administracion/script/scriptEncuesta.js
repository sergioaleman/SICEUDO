function verificarVoto()
{
	var cedula = document.getElementById('ced_estudiante').value;
	var contenido_codigo = abrirAjax();
	contenido_codigo.open("GET", "administracion/consultas.php?accion=10&cedula="+cedula, true);
    contenido_codigo.onreadystatechange=function()
	{
		if (contenido_codigo.readyState==4)
		{
			var datos;
			datos = contenido_codigo.responseText;
			if (datos == 'S') {
				alert('Usted ya participÃ³ en nuestra consulta');
				return;
			}
			else if (datos == 'C') {
				alert('La consulta ha concluido ! ! ! ');
				return;
			} else {
				enviarOpcionConsulta();
			}
		}
	}	
	contenido_codigo.send(null);
}

function enviarOpcionConsulta()
{	
	var cedula     = document.getElementById("ced_estudiante").value;
	var formulario = document.getElementById("frmConsulta");
	var opcion , i, j=0;
		
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.type == "radio") {
			if(elemento.checked) {
				j=j+1;
				opcion = elemento.value;
			}
		}
	}
	
	if (j == 0)
	{
		alert("Debe seleccionar alguna opciÃ³n de la consulta");
	}
	else
	{ 
	
	var mensaje = "Â¿Confirma su elecciÃ³n? \n Recuerde que posteriormente no podrÃ¡ ser modificada!" ;
	if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {'cedula':cedula,
													'opcion':opcion,
													'accion':'registrarConsulta'
											   }
								,'onSuccess': validarOpcionConsulta
								,'url':'administracion/transEncuesta.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}}
}

function validarOpcionConsulta(req)
{	
	var cedula = document.getElementById("ced_estudiante").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		//alert("La inscripciÃ³n del estudiante ("+cedula+") ha sido registrada con Ã©xito");
		//limpiarRegularesWeb();
		//cambiar_cuerpo('admision/inscripcion_web.php', 'cuerpo');
		cambiar_cuerpo('administracion/encuesta.php', 'cuerpo');
	} else {
		alert("...ERROR! Su elecciÃ³n no pudo ser registrada \n Por favor intente nuevamente");
		return;
	}
}