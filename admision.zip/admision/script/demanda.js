function isset( obj ) {
  if (typeof(eval(obj)) != 'undefined')
     if (eval(obj) != null)
         return true;
    return false;
   }
   

function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}


function mostrarMsg (req){
	//var resp=eval ("("+ req.responseText +")");
	document.getElementById("contenido").innerHTML =req.responseText;
	}
	
function registrarDemanda() {	
	var opcion = document.getElementById("opcion").value;
	var periodo = document.getElementById("periodo").value;	
	if (opcion!='0') {
	   if (confirm ("Â¿ Esta seguro que desea registrar esta asignatura? ")){
		AjaxRequest.post( {
				'parameters': { 				   
					'op':opcion,
					'per':periodo,
					'accion':'registrarDemanda'
					}
				,'onSuccess': mensajeOK
				,'url':'admision/transDemanda.php'
				,'onError': function(req)
				{
					alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
				}
			}
			);
		
		}
		else {return;}
	}
	else { alert ("error en datos");	}
	
}

function cargaSolicitud(){
	var periodo = document.getElementById("periodo").value;	
		AjaxRequest.post( {
				'parameters': { 				   					
					'per':periodo,
					'accion':'consultarDemanda'
					}
				,'onSuccess': mensajeOK
				,'url':'admision/transDemanda.php'
				,'onError': function(req)
				{
					alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
				}
			}
			);
}

function mensajeOK (req){
	document.getElementById("mensaje").innerHTML =req.responseText;
	}