function especialidadesEstu() {
	var cedula = document.getElementById('cedula');
	var especialidades = document.getElementById('especialidad');
	var contenido = abrirAjax();
	contenido.open("GET", "admision/consultas.php?accion=7&cedula="+cedula.value, true);
   contenido.onreadystatechange=function()
	{
		if (contenido.readyState==1)
		{
			especialidades.length=0;
			var opcion=document.createElement("opcion");
			opcion.value=0;
			opcion.innerHTML= "Cargando...";
			especialidades.appendChild(opcion);
			especialidades.disabled=true;
		}
		if (contenido.readyState==4)
		{
			especialidades.parentNode.innerHTML = contenido.responseText;
		}
	}
	contenido.send(null);
}

function abrirAjax()
{
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function formato_fecha(fecha) {
	dia = fecha.substr(8,2);
	mes = fecha.substr(5,2);
	ano = fecha.substr(0,4);
	return dia+'/'+mes+'/'+ano;
}

function obtiene_fecha() {
    var fecha_actual = new Date();
    var dia = fecha_actual.getDate() - 1;
    var mes = fecha_actual.getMonth() + 1;
    var anio = fecha_actual.getFullYear();
    if (mes < 10)
        mes = '0' + mes;
    if (dia < 10)
        dia = '0' + dia;
    return (dia + "/" + mes + "/" + anio);
}

function calcular_edad(fecha) {
	var dia, mes, ano, edad;
	var fechaAct = obtiene_fecha();
	
	var hoy = fechaAct.split("/");
	var dia = hoy[0];
	var mes = hoy[1];
	var ano = hoy[2];
	
	var fechaNac = fecha.split("/");
	var diaNac = fechaNac[0];
	var mesNac = fechaNac[1];
	var anoNac = fechaNac[2];

	if ((mesNac == mes) && (diaNac > dia)) {
		ano = (ano - 1);
	}

	if (mesNac > mes) {
		ano = (ano - 1);
	}
	edad = (ano - anoNac);
	return edad;
}

function mostrarEstudiante() {
	var cedula = document.getElementById('cedula');
	var nombres = document.getElementById('nombres');
	var apellidos = document.getElementById('apellidos');
	var nucleo = document.getElementById('nucleo');
	var asig1 = document.getElementById('codigo1');
	var contenido_codigo = abrirAjax();
	
	contenido_codigo.open("GET", "admision/consultas.php?accion=4&cedula="+cedula.value, true);
   contenido_codigo.onreadystatechange=function()
	{
		if (contenido_codigo.readyState==4)
		{
			var arregloDatos;
			arregloDatos = contenido_codigo.responseText.split('||');
			if ((arregloDatos[0] == 0) && (cedula.value != '')) {
				alert("El nÃºmero de cÃ©dula no ha sido registrado como estudiante");
				cedula.value = '';
				cedula.focus();
				return;
			}
			if (arregloDatos[3] != 0) { //&& (arregloDatos[4] != 0)
				alert("El estudiante ha sido registrado en la inscripciÃ³n del semestre actual");
				cedula.value = '';
				cedula.focus();
				return;
			} else if ((arregloDatos[3] == 0) || (arregloDatos[4] == 0) || ((arregloDatos[3] != 0) || (arregloDatos[4] == 0))) {
				apellidos.value = arregloDatos[1];
				nombres.value = arregloDatos[2];
				nucleo.value = arregloDatos[5];
				especialidadesEstu();
				cargar_obligatorias();
			}
		}
	}
	contenido_codigo.send(null);
}

function infoAsig(nro) {
	var codigo = document.getElementById('codigo'+nro);
	var nombre = document.getElementById('nombre'+nro);
	var creditos = document.getElementById('creditos'+nro);
	var secciones = document.getElementById('secciones'+nro);
	var cod_esp = document.getElementById('cod_esp');
	var sig = nro + 1;
	var asig_sig = document.getElementById('codigo'+sig);
	
	verificar_codigos(codigo.value, nro);
	
	var contenido_codigo = abrirAjax();
	contenido_codigo.open("GET", "admision/consultas.php?accion=5&codigo="+codigo.value, true);
   contenido_codigo.onreadystatechange=function()
	{
		if (contenido_codigo.readyState==4)
		{
			var arregloDatos;
			arregloDatos = contenido_codigo.responseText.split('||');
			if ((arregloDatos[0] == 0) && (codigo.value != '')) {
				alert("El cÃ³digo de la asignatura no ha sido registrado");
				codigo.value = '';
				codigo.focus();
				return;
			}
			nombre.value = arregloDatos[1];
			creditos.value = arregloDatos[2];
			secciones.innerHTML = arregloDatos[3];
// 			cod_esp.value = arregloDatos[4];
			actualizar_creditos();
			asig_sig.focus();
		}
	}
	contenido_codigo.send(null);
}

function verificar_codigos(valor, nro)
{
	var codigo = document.getElementById('codigo'+nro);
	var cod1 = document.getElementById('codigo1').value;
	var cod2 = document.getElementById('codigo2').value;
	var cod3 = document.getElementById('codigo3').value;
	var cod4 = document.getElementById('codigo4').value;
	var cod5 = document.getElementById('codigo5').value;
	var cod6 = document.getElementById('codigo6').value;
	var cod7 = document.getElementById('codigo7').value;
	var cod8 = document.getElementById('codigo8').value;
	var cod9 = document.getElementById('codigo9').value;
	var cod10 = document.getElementById('codigo10').value;
	var codigos = [cod1, cod2, cod3, cod4, cod5, cod6, cod7, cod8, cod9, cod10];
	var sw = 0, i = 0;

	while ((i < 10) && (i != (nro-1)))
	{
		if (valor == codigos[i]) {
			sw = 1;
		}
		i++;
	}
	if (sw == 1) {
		alert('CÃ³digo de la Asignatura ha sido Introducido');
		codigo.value = '';
		codigo.focus();
		return;
	}
}

function cargar_cupos(nro)
{
	var codigo = document.getElementById('codigo'+nro);
	var seccion = document.getElementById('secciones'+nro);
	var inscritos = document.getElementById('inscritos'+nro);
	var cupos = document.getElementById('cupos'+nro);
	
	var contenido_codigo = abrirAjax();
	contenido_codigo.open("GET", "admision/consultas.php?accion=6&codigo="+codigo.value+"&seccion="+seccion.value, true);
   contenido_codigo.onreadystatechange=function()
	{
		if (contenido_codigo.readyState==4)
		{
			var arregloDatos;
			arregloDatos = contenido_codigo.responseText.split('||');
			
			inscritos.value = arregloDatos[0];
			cupos.value = arregloDatos[1];
		}
	}
	contenido_codigo.send(null);
}

function enviarInscripcion()
{
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("codNucleo").value;
	var asig1        = document.getElementById("codigo1").value;
	var secc1        = document.getElementById("secciones1").value;
	var asig2        = document.getElementById("codigo2").value;
	var secc2        = document.getElementById("secciones2").value;
	var asig3        = document.getElementById("codigo3").value;
	var secc3        = document.getElementById("secciones3").value;
	var asig4        = document.getElementById("codigo4").value;
	var secc4        = document.getElementById("secciones4").value;
	var asig5        = document.getElementById("codigo5").value;
	var secc5        = document.getElementById("secciones5").value;
	var asig6        = document.getElementById("codigo6").value;
	var secc6        = document.getElementById("secciones6").value;
	var asig7        = document.getElementById("codigo7").value;
	var secc7        = document.getElementById("secciones7").value;
	var asig8        = document.getElementById("codigo8").value;
	var secc8        = document.getElementById("secciones8").value;
	var asig9        = document.getElementById("codigo9").value;
	var secc9        = document.getElementById("secciones9").value;
	var asig10       = document.getElementById("codigo10").value;
	var secc10       = document.getElementById("secciones10").value;
	var maxCred      = document.getElementById("max_cred").value;
	var totCred      = document.getElementById("tot_cred").value;
	
	if (cedula=='') {
		alert ("No se puede dejar en campo cÃ©dula en blanco");
		return;
	}
	if ((asig1=='') || (secc1==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 1");
		return;
	}
	if ((asig2!='') && (secc2==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 2");
		return;
	}
	if ((asig3!='') && (secc3==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 3");
		return;
	}
	if ((asig4!='') && (secc4==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 4");
		return;
	}
	if ((asig5!='') && (secc5==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 5");
		return;
	}
	if ((asig6!='') && (secc6==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 6");
		return;
	}
	if ((asig7!='') && (secc7==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 7");
		return;
	}
	if ((asig8!='') && (secc8==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 8");
		return;
	}
	if ((asig9!='') && (secc9==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 9");
		return;
	}
	if ((asig10!='') && (secc10==0)) {
		alert ("Debe completar los datos para la Asignatura NÂº 10");
		return;
	}
	//alert(totCred+' > '+maxCred);
	
	if (totCred > maxCred) {
		alert ("No puede inscribir una cantidad crÃ©ditos mayor a la permitida. MÃ¡ximo: "+maxCred+" cÅ•editos");
		return;
	}
	if (confirm ('Â¿Desea confirmar la inscripciÃ³n del estudiante?')) {
	AjaxRequest.post(
						{
								'parameters': {'cedula':cedula,
													'cod_esp':especialidad,
													'nucleo':nucleo,
													'asig1':asig1,
													'secc1':secc1,
													'asig2':asig2,
													'secc2':secc2,
													'asig3':asig3,
													'secc3':secc3,
													'asig4':asig4,
													'secc4':secc4,
													'asig5':asig5,
													'secc5':secc5,
													'asig6':asig6,
													'secc6':secc6,
													'asig7':asig7,
													'secc7':secc7,
													'asig8':asig8,
													'secc8':secc8,
													'asig9':asig9,
													'secc9':secc9,
													'asig10':asig10,
													'secc10':secc10,
													'accion':'nuevaInscripcion'
													}
								,'onSuccess': nuevaInscripcion
								,'url':'admision/transInscripcion.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function nuevaInscripcion(req)
{
	var cedula = document.getElementById("cedula").value;
	var esp = document.getElementById("especialidad").value;
	var resp = req.responseText;
	alert("El estudiante ha sido inscrito correctamente");
	window.open('admision/constancia_inscripcion.php?cedula='+cedula+'&esp='+esp, 'constancia', 'width=800, height=800, scrollbars=1, location=0, resizable=0');
	limpiarRegulares();
}

function actualizar_creditos()
{
	var total_cred = 0;
	var total = document.getElementById("tot_cred");
	var cred1 = document.getElementById("creditos1").value;
	var cred2 = document.getElementById("creditos2").value;
	var cred3 = document.getElementById("creditos3").value;
	var cred4 = document.getElementById("creditos4").value;
	var cred5 = document.getElementById("creditos5").value;
	var cred6 = document.getElementById("creditos6").value;
	var cred7 = document.getElementById("creditos7").value;
	var cred8 = document.getElementById("creditos8").value;
	var cred9 = document.getElementById("creditos9").value;
	var cred10 = document.getElementById("creditos10").value;
	
	if(cred1 == '')
		cred1 = 0;
	if(cred2 == '')
		cred2 = 0;
	if(cred3 == '')
		cred3 = 0;
	if(cred4 == '')
		cred4 = 0;
	if(cred5 == '')
		cred5 = 0;
	if(cred6 == '')
		cred6 = 0;
	if(cred7 == '')
		cred7 = 0;
	if(cred8 == '')
		cred8 = 0;
	if(cred9 == '')
		cred9 = 0;
	if(cred10 == '')
		cred10 = 0;
	
	total_cred = parseInt(cred1) + parseInt(cred2) + parseInt(cred3) + parseInt(cred4) + parseInt(cred5) + parseInt(cred6) + parseInt(cred7) + parseInt(cred8) + parseInt(cred9) + parseInt(cred10);
	
	total.value = total_cred;
}

function formato_codigo(entrada) {
	var temp = document.getElementById(entrada);
	var cadena = temp.value.toString();

	if(cadena.length == 3) {
		temp.value = temp.value.toString()+"-";
	}
}

function cargarAsignaturas(valor) {
	var cedula = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var i, codigos=[];
	for (i=1; i<=10; i++) {
		var cod = document.getElementById('codigo'+i).value;
		if (cod != '')
			codigos[i-1] = cod;
	}
	if (cedula == '') {
		alert ("Ha dejado el campo identificaciÃ³n en blanco. Por favor sumistre su cÃ©dula o pasaporte");
		return;
	} else if (especialidad=='0') {
		alert ("Sus datos personales no han sido cargados correctamente. Por favor intente de nuevo");
		return;
	}
	if(valor=="cargarAsignatura")
	{
		window.open('admision/cargar_asignaturas.php?cedula='+cedula+'&esp='+especialidad+'&codigos='+codigos, 'pensum', 'width=630, height=600, scrollbars=1, location=0, resize=no');
	}
	else if(valor=="verPensum")
	{
		window.open('admision/ver_pensum.php?cedula='+cedula+'&esp='+especialidad, 'pensum', 'width=1024, height=768, scrollbars=1, location=0, resize=no');	
	}
}

function cargarCodigos() {
	var i, n, p, j=0, k=0, cred=0;
	var maxCreditos = 22;
	var codigos=[], formulario=[], creditos=[];
	for (n=0; n<11; n++) {
		formulario[n] = document.getElementById('semestre'+n);
		for (i=0; i<formulario[n].elements.length; i++) {
			var elemento = formulario[n].elements[i];
			if(elemento.type == "checkbox") {
				if(elemento.checked) {
					j=j+1;
					codigos[k] = elemento.value;
					k++;
				}
			}
		}
	}
	for (c=0; c<codigos.length; c++) {
		cred += parseInt(codigos[c].substr(7,1));
	}
	if (j == 0) {
		alert('Debe seleccionar por lo menos un item de la lista para cargar');
		return;
	} else if (cred > maxCreditos) {
		alert('No se puede registrar mÃ¡s de '+maxCreditos+' crÃ©ditos en la inscripciÃ³n. Seleccionados: '+cred+' crÃ©ditos');
		return;
	} else if (confirm('Â¿Confirma cargar las asignaturas seleccionadas?')) {
		for (p=0; p<10; p++) {
			var nro = p+1;
			if (codigos[p] == undefined) {
				codigos[p] = '';
			}
			window.opener.document.getElementById('codigo'+nro).value = codigos[p];
			infoAsig_2(nro);
		}
		window.close();
	}
}

function infoAsig_2(nro) {
	var codigo = window.opener.document.getElementById('codigo'+nro);
	var nombre = window.opener.document.getElementById('nombre'+nro);
	var creditos = window.opener.document.getElementById('creditos'+nro);
	var secciones = window.opener.document.getElementById('secciones'+nro);
	var sig = nro + 1;
	
	var contenido_codigo = abrirAjax();
	contenido_codigo.open("GET", "../admision/consultas.php?accion=5&codigo="+codigo.value, true);
   contenido_codigo.onreadystatechange=function()
	{
		if ((contenido_codigo.readyState==4) && (codigo.value != ''))
		{
			var arregloDatos;
			arregloDatos = contenido_codigo.responseText.split('||');
			
			nombre.value = arregloDatos[1];
			creditos.value = arregloDatos[2];
			secciones.innerHTML = arregloDatos[3];
 			actualizar_creditos_2();
		}
	}
	contenido_codigo.send(null);
}

function actualizar_creditos_2()
{
	var total_cred = 0;
	var total = window.opener.document.getElementById("tot_cred");
	var cred1 = window.opener.document.getElementById("creditos1").value;
	var cred2 = window.opener.document.getElementById("creditos2").value;
	var cred3 = window.opener.document.getElementById("creditos3").value;
	var cred4 = window.opener.document.getElementById("creditos4").value;
	var cred5 = window.opener.document.getElementById("creditos5").value;
	var cred6 = window.opener.document.getElementById("creditos6").value;
	var cred7 = window.opener.document.getElementById("creditos7").value;
	var cred8 = window.opener.document.getElementById("creditos8").value;
	var cred9 = window.opener.document.getElementById("creditos9").value;
	var cred10 = window.opener.document.getElementById("creditos10").value;
	
	if(cred1 == '')
		cred1 = 0;
	if(cred2 == '')
		cred2 = 0;
	if(cred3 == '')
		cred3 = 0;
	if(cred4 == '')
		cred4 = 0;
	if(cred5 == '')
		cred5 = 0;
	if(cred6 == '')
		cred6 = 0;
	if(cred7 == '')
		cred7 = 0;
	if(cred8 == '')
		cred8 = 0;
	if(cred9 == '')
		cred9 = 0;
	if(cred10 == '')
		cred10 = 0;
	
	total_cred = parseInt(cred1) + parseInt(cred2) + parseInt(cred3) + parseInt(cred4) + parseInt(cred5) + parseInt(cred6) + parseInt(cred7) + parseInt(cred8) + parseInt(cred9) + parseInt(cred10);
	
	total.value = total_cred;
}

function cargar_obligatorias() {
	var cedula = document.getElementById('cedula');
	var maxCred = document.getElementById('max_cred');
	var creditos, i, j;
	var contenido_codigo = abrirAjax();
	contenido_codigo.open("GET", "admision/consultas.php?accion=8&cedula="+cedula.value, true);
   contenido_codigo.onreadystatechange=function()
	{
		if (contenido_codigo.readyState == 4)
		{
			var arregloDatos;
			arregloDatos = contenido_codigo.responseText.split('||');
			var veces = arregloDatos[1].split('Â·');
			var asig = arregloDatos[0].split('Â·');
			for(i=0; i<(veces.length)-1; i++) {
				if ((veces[i] == 1) || (veces[i] == 2) || (veces[i] == 3)) {
					creditos = 18;
				} else if(veces[i] == 4) {
					creditos = 8;
				} else if(veces[i] == 5) {
					creditos = asig[i].substr(7,1);
				} else if(veces[i] == 6) {
					creditos = 0;
					alert('La matrÃ­cula del estudiante ha sido suspendida. Debe solicitar reingreso');
					return;
				}
			}

			var j = 0, m = 0, tam;
			tam = asig.length - 1;

			while (m < tam) {
				var k = m + 1;
				var cod = document.getElementById('codigo'+k);
				if (veces[m] > 0) {
					cod.value = asig[m];
					infoAsig(k);
				}
				m++;
			}
			if (maxCred.value == undefined)
				maxCred.value = 22;
			else
				maxCred.value = creditos;
		}
	}
	contenido_codigo.send(null);
}

function limpiarRegulares() {
	var formulario = document.getElementById('frmInscripcion');
	formulario.reset();
	for (i=1; i<=10; i++) {
		var sec = document.getElementById('secciones'+i);
		sec.innerHTML = "<OPTION value='00'>..</OPTION>";
	}
}