function isset( obj ) {
  if (typeof(eval(obj)) != 'undefined')
     if (eval(obj) != null)
         return true;
    return false;
   }
   

function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}


function mostrarMsg (req){
	//var resp=eval ("("+ req.responseText +")");
	document.getElementById("contenido").innerHTML =req.responseText;
	}
	
function inscribirServComun() {	
	var cedula  = document.getElementById("cedula").value;	
	var opcion1 = document.getElementById("opcion1").value;
	var especialidad = document.getElementById("especialidad").value;
	if (opcion1!='0') {
	   if (confirm ("Â¿ Esta seguro que desea inscribir estas opciones? \n Recuerde que una vez Inscrito no podrÃ¡ cambiar de secciÃ³n! ")){
		AjaxRequest.post(
			{
				'parameters': { 				   
					'op1':opcion1,
					'especialidad': especialidad,
					'accion':'inscribirServC'
					}
				,'onSuccess': imprimirConstancia
				,'url':'admision/transInscripcionServCom.php'
				,'onError': function(req)
				{
					alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
				}
			}
			);
		
		}
		else {return;}
	}
	else { alert ("Debe seleccionar una opcion");	}
	
}

function preinscribirServComun() {	
	var cedula  = document.getElementById("cedula").value;	
	var opcion1 = document.getElementById("opcion1").value;
	var opcion2 = document.getElementById("opcion2").value;
	var opcion3 = document.getElementById("opcion3").value;	
	if (opcion1!='0' && opcion2!='0' && opcion3!='0') {
	   if (confirm ("Â¿ Esta seguro que desea inscribir estas opciones? \n Recuerde que una vez Inscrito no podrÃ¡ cambiar de secciÃ³n! ")){
		AjaxRequest.post(
			{
				'parameters': { 				   
					'op1':opcion1,
					'op2':opcion2,
					'op3':opcion3,
					'accion':'PreinscribirServC'
					}
				,'onSuccess': imprimirConstancia
				,'url':'admision/transInscripcionServCom.php'
				,'onError': function(req)
				{
					alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
				}
			}
			);
		
		}
		else {return;}
	}
	else { alert ("Debe seleccionar 1 opcion");	}
	
}

function imprimirConstancia (req){
	//var resp=eval ("("+ req.responseText +")");
	if (req.responseText=='1')  alert (" NO EXISTE DISPONIBILIDAD PARA ESA SECCION, Seleccione otra opcion");
	else document.getElementById("contenido").innerHTML =req.responseText;
	}