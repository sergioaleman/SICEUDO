function abrirAjax()
{
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function datosEstu()
{
	var codigo = document.getElementById('cedula').value;
	
	if(codigo!='')
	{
		AjaxRequest.post(
		{
			'parameters': {'cedula':codigo,											
						   'accion':'datosEstu'
						  }
				,'onSuccess': respDatosEstu
				,'url':'admision/transEstudiante.php'
				,'onError': function(req)
				{
						alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
				}
			}
		);
	}
	else
	{
		alert("Error! algo salio mal");
		cambiar_cuerpo('admision/editar_estu.php','cuerpo');
		return;
	}
}


function respDatosEstu(req) {
	var resp = eval ("("+ req.responseText +")");
	var codigo = document.getElementById('cedula');
	var apellidos = document.getElementById('apellidos');
	var nombres = document.getElementById('nombres');
	var sexo = document.getElementById('sexo');
	var tipo_sangre = document.getElementById('tipo_sangre');
	var edo_civil = document.getElementById('edo_civil');
	var nacionalidad = document.getElementById('nacionalidad');
	var fecha_nac = document.getElementById('fecha_nac');
	var etnia = document.getElementById('etnia');
	var pais = document.getElementById('pais');
	var estado = document.getElementById('estado');
	var ciudad = document.getElementById('ciudad');
	var condicion_res = document.getElementById('condicion');
	var libertad = document.getElementById('libertad');
	var direccion = document.getElementById('direccion');
	var telefono = document.getElementById('telefono');
	var celular = document.getElementById('celular');
	var email = document.getElementById('email');
	var anyo_grad = document.getElementById('anyo_grad');
	var becado = document.getElementById('becado');
	var promedio = document.getElementById('promedio');
	var titulo = document.getElementById('titulo');
	var plantel = document.getElementById('plantel');
	var rusnies = document.getElementById('rusnies');
	
	var arregloDatos;
	arregloDatos = resp.split('||');
	
	if (arregloDatos[0] == 1)
	{
			apellidos.disabled = false;
			nombres.disabled = false;
			sexo.disabled = false;
			tipo_sangre.disabled = false;
			edo_civil.disabled = false;
			nacionalidad.disabled = false;
			fecha_nac.disabled = false;
			etnia.disabled = false;
			pais.disabled = false;
			estado.disabled = false;
			ciudad.disabled = false;
			condicion_res.disabled = false;
			libertad.disabled = false;
			direccion.disabled = false;
			telefono.disabled = false;
			celular.disabled = false;
			email.disabled = false;
			anyo_grad.disabled = false;
			becado.disabled = false;
			promedio.disabled = false;
			titulo.disabled = false;
			plantel.disabled = false;
			rusnies.disabled = false;
			

			apellidos.value = arregloDatos[2];
			nombres.value = arregloDatos[3];
			sexo.value = arregloDatos[4];
			tipo_sangre.value = arregloDatos[5];
			edo_civil.value = arregloDatos[6];
			nacionalidad.value = arregloDatos[7];
			fecha_nac.value = formato_fecha(arregloDatos[8]);
			etnia.value = arregloDatos[9];
			pais.value = arregloDatos[10];
			marcar_estado(arregloDatos[10], arregloDatos[11], 1);
			estado.value = arregloDatos[11];
			ciudad.value = arregloDatos[12];
			condicion_res.value = arregloDatos[13];
			libertad.value = arregloDatos[14];
			direccion.value = arregloDatos[15];
			telefono.value = arregloDatos[16];
			celular.value = arregloDatos[17];
			email.value = arregloDatos[18];
			anyo_grad.value = arregloDatos[19];
			becado.value = arregloDatos[20];
			promedio.value = arregloDatos[21];
			titulo.value = arregloDatos[22];
			plantel.value = arregloDatos[23];
			rusnies.value = arregloDatos[24];
	}
	else if (arregloDatos[0] == 0)
	{
		alert("Error! algo salio mal");
		cambiar_cuerpo('admision/editar_estu.php','cuerpo');
	} 
}

function marcar_estado(cod_pais, cod_estado, habilitar) {
	var pais = document.getElementById('pais');
	var estado = document.getElementById('estado');
	var contenido_estado = abrirAjax();
	contenido_estado.open("GET", "admision/consultas.php?accion=10&pais="+cod_pais+"&estado="+cod_estado+"&hab="+habilitar, true);
    contenido_estado.onreadystatechange=function()
	{
		if (contenido_estado.readyState==1)
		{
			estado.length=0;
			var opcion=document.createElement("opcion");
			opcion.value=0;
			opcion.innerHTML= "Cargando...";
			estado.appendChild(opcion);
			estado.disabled=true;
		}
		if (contenido_estado.readyState==4)
		{
			estado.parentNode.innerHTML = contenido_estado.responseText;
		}
	}
	contenido_estado.send(null);
}

function cargar_estados() {
	var pais = document.getElementById('pais');
	var estado = document.getElementById('estado');
	var contenido_estado = abrirAjax();
	contenido_estado.open("GET", "admision/consultas.php?accion=1&pais="+pais.value, true);
    contenido_estado.onreadystatechange=function()
	{
		if (contenido_estado.readyState==1)
		{
			estado.length=0;
			var opcion=document.createElement("opcion");
			opcion.value=0;
			opcion.innerHTML= "Cargando...";
			estado.appendChild(opcion);
			estado.disabled=true;
		}
		if (contenido_estado.readyState==4)
		{
			estado.parentNode.innerHTML = contenido_estado.responseText;
		}
	}
	contenido_estado.send(null);
}

function limpiarEstudiante() {
	var cedula = document.getElementById('cedula');
	//var formulario = document.getElementById('fEstudiante');
	//formulario.reset();
	
	var apellidos = document.getElementById('apellidos');
	var nombres = document.getElementById('nombres');
	var sexo = document.getElementById('sexo');
	var tipo_sangre = document.getElementById('tipo_sangre');
	var edo_civil = document.getElementById('edo_civil');
	var nacionalidad = document.getElementById('nacionalidad');
	var fecha_nac = document.getElementById('fecha_nac');
	var etnia = document.getElementById('etnia');
	var pais = document.getElementById('pais');
	var estado = document.getElementById('estado');
	var ciudad = document.getElementById('ciudad');
	var condicion_res = document.getElementById('condicion');
	var libertad = document.getElementById('libertad');
	var direccion = document.getElementById('direccion');
	var telefono = document.getElementById('telefono');
	var celular = document.getElementById('celular');
	var email = document.getElementById('email');
	var anyo_grad = document.getElementById('anyo_grad');
	var becado = document.getElementById('becado');
	var promedio = document.getElementById('promedio');
	var titulo = document.getElementById('titulo');
	var plantel = document.getElementById('plantel');
	var rusnies = document.getElementById('rusnies');
	

	apellidos.disabled = true;
	nombres.disabled = true;
	sexo.disabled = true;
	tipo_sangre.disabled = true;
	edo_civil.disabled = true;
	nacionalidad.disabled = true;
	fecha_nac.disabled = true;
	etnia.disabled = true;
	pais.disabled = true;
	estado.disabled = true;
	ciudad.disabled = true;
	condicion_res.disabled = true;
	libertad.disabled = true;
	direccion.disabled = true;
	telefono.disabled = true;
	celular.disabled = true;
	email.disabled = true;
	anyo_grad.disabled = true;
	becado.disabled = true;
	promedio.disabled = true;
	titulo.disabled = true;
	plantel.disabled = true;
	rusnies.disabled = true;
	cedula.focus();
}

function enviarDatosEstu()
{
	var cedula       = document.getElementById("cedula").value;
	var anyo_grad    = document.getElementById("anyo_grad").value;
	var direccion    = document.getElementById("direccion").value;
	var fecha_nac    = document.getElementById("fecha_nac").value;
	var sexo         = document.getElementById("sexo").value;
	var edo_civil    = document.getElementById("edo_civil").value;
	var nacionalidad = document.getElementById("nacionalidad").value;
	var titulo       = document.getElementById("titulo").value;
	var pais         = document.getElementById("pais").value;
	var estado       = document.getElementById("estado").value;
	var ciudad       = document.getElementById("ciudad").value;
	var celular      = document.getElementById("celular").value;
	var telefono     = document.getElementById("telefono").value;
	var plantel      = document.getElementById("plantel").value;
	var tipo_sangre  = document.getElementById("tipo_sangre").value;
	var condicion    = document.getElementById("condicion").value;
	var etnia        = document.getElementById("etnia").value;
	var becado       = document.getElementById("becado").value;
	var libertad     = document.getElementById("libertad").value;
	var rusnies      = document.getElementById("rusnies").value;
	var edad;
	
	edad = calcular_edad(fecha_nac);
	if (edad < 14) {
		alert('La edad del estudiante es de '+edad+' aÃ±os, sus datos no pueden ser actualizados');
		return;
	}
	if((cedula=='')||(apellidos=='')||(nombres=='')||(sexo==0)||(edo_civil==0)||(fecha_nac=='')||(nacionalidad==0)||(titulo==0))
	// se eliminÃ³ (promedio=='')
	{
		alert ("No se puede agregar el registro. Faltan campos obligatorios");
		return;
	} else if (confirm('Â¿Confirma que desea modificar los datos del estudiante?')) {
	
		AjaxRequest.post(
							{
									'parameters': {'cedula':cedula,
														'fecha_nac':fecha_nac,
														'sexo':sexo,
														'edo_civil':edo_civil,
														'nacionalidad':nacionalidad,
														'direccion':direccion,
														'telefono':telefono,
														'titulo':titulo,
														'anyo_grad':anyo_grad,
														'pais':pais,
														'estado':estado,
														'ciudad':ciudad,
														'celular':celular,
														'plantel':plantel,
														'tipo_sangre':tipo_sangre,
														'condicion':condicion,
														'etnia':etnia,
														'becado':becado,
														'libertad':libertad,
														'rusnies':rusnies,
														'accion':'modificarEstu'
														}
									,'onSuccess': modificarEstu
									,'url':'admision/transEstudiante.php'
									,'onError': function(req)
									{
										alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
									}
							}
							);
	}
}

function modificarEstu(req)
{
	var cedula = document.getElementById("cedula").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp!=false)
	{
		alert("Los datos del estudiante "+cedula+" han sido registrados con Ã©xito");
		limpiarEstudiante();
	}
	else
	{
		alert("Error! algo salio mal");
		cambiar_cuerpo('admision/editar_estu.php','cuerpo');
		return;
	}
}

function obtiene_fecha() {
    var fecha_actual = new Date();
    var dia = fecha_actual.getDate() - 1;
    var mes = fecha_actual.getMonth() + 1;
    var anio = fecha_actual.getFullYear();
    if (mes < 10)
        mes = '0' + mes;
    if (dia < 10)
        dia = '0' + dia;
    return (dia + "/" + mes + "/" + anio);
}

function calcular_edad(fecha) {
	var dia, mes, ano, edad;
	var fechaAct = obtiene_fecha();
	var hoy = fechaAct.split("/");
	var dia = hoy[0];
	var mes = hoy[1];
	var ano = hoy[2];
	var fechaNac = fecha.split("/");
	var diaNac = fechaNac[0];
	var mesNac = fechaNac[1];
	var anoNac = fechaNac[2];

	if ((mesNac == mes) && (diaNac > dia)) {
		ano = (ano - 1);
	}
	if (mesNac > mes) {
		ano = (ano - 1);
	}
	edad = (ano - anoNac);
	return edad;
}

function imprimirPlanillaCnu()
{
	var cedula       = document.getElementById("cedula").value;
	var apellidos    = document.getElementById("apellidos").value;
	var nombres      = document.getElementById("nombres").value;
	var anyo_grad    = document.getElementById("anyo_grad").value;
	var direccion    = document.getElementById("direccion").value;
	var fecha_nac    = document.getElementById("fecha_nac").value;
	var sexo         = document.getElementById("sexo").value;
	var edo_civil    = document.getElementById("edo_civil").value;
	var nacionalidad = document.getElementById("nacionalidad").value;
	var titulo       = document.getElementById("titulo").value;
	var pais         = document.getElementById("pais").value;
	var estado       = document.getElementById("estado").value;
	var ciudad       = document.getElementById("ciudad").value;
	var celular      = document.getElementById("celular").value;
	var telefono     = document.getElementById("telefono").value;
	var email        = document.getElementById("email").value;
	var promedio     = document.getElementById("promedio").value;
	var plantel      = document.getElementById("plantel").value;
	var tipo_sangre  = document.getElementById("tipo_sangre").value;
	var tipo_doc     = document.getElementById("tipo_doc").value;
	var condicion    = document.getElementById("condicion").value;
	var etnia        = document.getElementById("etnia").value;
	var becado       = document.getElementById("becado").value;
	var libertad     = document.getElementById("libertad").value;
	var rusnies      = document.getElementById("rusnies").value;
	
	
	
	if((cedula=='')||(apellidos=='')||(nombres=='')||(sexo==0)||(edo_civil==0)||(fecha_nac=='')||(nacionalidad==0)||(titulo==0)||(promedio=='') ||(anyo_grad ==0) || (direccion=='') || (pais==0) || (estado==0) || (ciudad=='') || (celular=='') || (telefono=='') || (email=='') || (plantel==0) || (tipo_sangre==0) || (condicion==0) || (etnia=='00') || (becado==0) || (libertad==0) || (rusnies==''))
	{
		alert("La informacion en el formulario esta incompleta. Para imprimir planilla CNU, por favor verifique sus datos y/o presione el enlace <Cargar mis datos>");	
	}
	else
	{
		popup('admision/planillas/planilla_CNU.php?cedula='+cedula, 800, 700);
	}	
}