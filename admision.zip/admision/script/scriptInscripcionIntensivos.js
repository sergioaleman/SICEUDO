function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function creditos_inscritos_intensivos()
{
	var i, k=0; creditos=0;
	var formulario   = document.getElementById("frmInscripcion");
	var totCred      = document.getElementById("tot_cred");
	
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.name.substring(0,9)  == "secciones") {
			if(elemento.value != "00") {
				creditos=parseInt(creditos)+parseInt(formulario.elements[i-1].value);
			}
		}
	}
	totCred.value = creditos;
}

function cantidad_asignaturas_inscritas_intensivos() {
	var especialidad = document.getElementById("especialidad").value;
	
	AjaxRequest.post(
						{
							'parameters':  {    'especialidad':especialidad,
												'accion':'buscarInscritasIntensivo'
											}
							,'onSuccess': respCantidadAsignaturasInscritasIntensivo
							,'url':'admision/transConsultasAdmision.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							}
						}
					);
}

function respCantidadAsignaturasInscritasIntensivo(req) {	
	var resp = eval ("("+ req.responseText +")");
	
	if(resp != false) {
		var arregloDatos;
		arregloDatos = resp.split('||');
		var maxAsig	= document.getElementById("max_asig");
		maxAsig.value = arregloDatos[0];
	} else {
		alert("ERROR..! No se pudo cargar los datos");
		return;
	}
}

function inscribir_asignatura_intensivos(nro, accion)
{
	var mensaje = '';
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var credito      = document.getElementById("creditos"+nro).value;
	var nombre       = document.getElementById("nombre"+nro).value;
	var asignatura   = document.getElementById("codigo"+nro).value;
	var seccion      = document.getElementById("secciones"+nro);
	var maxCred      = document.getElementById("max_cred").value;
	var totCred      = document.getElementById("tot_cred");
	var asig_ins     = document.getElementById("asig_inscribir");
	var maxAsig	     = document.getElementById("max_asig").value;
	
	asig_ins.value = seccion.name;
	creditos_inscritos_intensivos();
	cantidad_asignaturas_inscritas_intensivos();

	if (accion == 'borrar') {
		seccion.value='00';
	}
	if (seccion.value=='00') {
		mensaje = "Â¿REALMENTE DESEA ELIMINAR LA ASIGNATURA: ("+asignatura+") "+nombre+"?" ;
	} else {
		mensaje="Â¿Desea inscribir la asignatura ("+asignatura+") "+nombre+" en la secciÃ³n ("+seccion.value+")?";
	}
	if(!confirm(mensaje)) {
		mostrarSeccionesInscritasIntensivos();
		return;
	} else if (parseInt(totCred.value) > parseInt(maxCred)) {
		//alert ("Usted no puede inscribir una cantidad mayor a ("+maxCred+") unidades de cÅ•editos");
		alert ("SegÃºn sus pagos, solo puede registrar una inscripciÃ³n igual a ("+maxCred+") unidades de crÃ©ditos. Revise sus pagos");
		seccion.value = '00';
		creditos_inscritos_intensivos();
		return;
	} else if ((parseInt(maxAsig) >= 2) && (accion != 'borrar') && (seccion.value != '00')){
		alert ("Usted no puede inscribir mÃ¡s de dos (2) asignaturas en semestre actual");
		seccion.value = '00';
		creditos_inscritos();
		return;
	} else {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'cod_esp':especialidad,
													'nucleo':nucleo,
													'asignatura':asignatura,
													'seccion':seccion.value,
													'accion':'nuevaInscripcion'
													}
								,'onSuccess': nuevaInscripcionIntensivos
								,'url':'admision/transInscripcionIntensivos.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function nuevaInscripcionIntensivos(req)
{
	var asig_ins = document.getElementById("asig_inscribir");
	var seccion = document.getElementById(asig_ins.value);
	var maxAsig = document.getElementById("max_asig");
	var resp=eval ("("+ req.responseText +")");
	
	if(resp == false)
	{
		seccion.value = '00';
		alert("La asignatura no pudo ser registrada.\nSe ha alcanzado la capacidad de cupos de la secciÃ³n!");
	}
	mostrarSeccionesInscritasIntensivos();
	creditos_inscritos_intensivos();
	cantidad_asignaturas_inscritas_intensivos();
	MostrarInscripcionIntensivos();
}

function mostrarSeccionesInscritasIntensivos() {
	
	var especialidad = document.getElementById('especialidad').value;
	
	AjaxRequest.post(
						{
							'parameters':  {    'especialidad':especialidad,
												'accion':'buscarInscritasIntensivo'
											}
							,'onSuccess': respMostrarSeccionesInscritasIntensivo
							,'url':'admision/transConsultasAdmision.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							}
						}
					);
}

function respMostrarSeccionesInscritasIntensivo(req) {
	var i, k=0;
	var formulario = document.getElementById("frmInscripcion");
	var fechaActual = document.getElementById('fecha_actual').value;
	var resp = eval ("("+ req.responseText +")");

	if(resp != false) {
		var arregloDatos;
		arregloDatos = resp.split('||');
		if (arregloDatos[0] >= 0) {
			var codAsig=Array();
			var seccion=Array();
			var fecha=Array();
			codAsig=arregloDatos[1].split('-');
			seccion=arregloDatos[2].split('-');
			fecha=arregloDatos[3].split('*');
			for (i=0; i<formulario.elements.length; i++) {
				var elemento = formulario.elements[i];
				if(elemento.name.substring(0,9)  == "secciones") {
					formulario.elements[i].value='00';
					formulario.elements[i].disabled=false;
					formulario.elements[i+1].disabled=true;
					for(var j=0;j<arregloDatos[0];j++) {
						if(formulario.elements[i-3].value==codAsig[j]) {
							formulario.elements[i].value=seccion[j];
							if(fecha[j] < fechaActual) {
								formulario.elements[i].disabled = true;
								formulario.elements[i+1].disabled = true;
							}
						}
					}
				}
			}
			creditos_inscritos_intensivos();
		}
		marcarBorrarIntensivos();
	} else {
		alert("ERROR..! No se pudo cargar los datos");
		return;
	}
}

function marcarBorrarIntensivos() {
	var formulario = document.getElementById("frmInscripcion");
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.name.substring(0,9) == "secciones") {
			formulario.elements[i+1].disabled=true;
			if (formulario.elements[i].value == '00')
				formulario.elements[i+1].disabled=true;
			else if (formulario.elements[i].disabled)
				formulario.elements[i+1].disabled=true;
			else
				formulario.elements[i+1].disabled=false;
		}
	}
}

function MostrarInscripcionIntensivos()
{
	AjaxRequest.post 
	(
		{			
			'onSuccess': respMostrarInscripcionIntensivos,
			'url': 'admision/VisualizaInscripcionIntensivos.php',
			'onError': function(req){
			alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
		}
	});
}

function respMostrarInscripcionIntensivos(req)
{
	var inscripcion=document.getElementById('tablaInscritas');
	inscripcion.innerHTML='';
	inscripcion.innerHTML=req.responseText;
}

function limpiarRegularesIntensivos() {
	var formulario = document.getElementById("frmInscripcion");
	var tablaA = document.getElementById("tablaInscripcion");
	formulario.reset();
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.name.substring(0,9)  == "secciones") {
			formulario.elements[i].value=='00';
			formulario.elements[i].disabled=true;
			formulario.elements[i+1].disabled=true;
		}
	}
	tablaA.innerHTML="<table align='center' width='100%' border='0' cellpadding='1' cellspacing='1' id='tablaInscripcion'><tr id='fila' bgcolor='#CCCCCC' height='15'><td width='12%' align='center'><strong>C&oacute;digo</strong></td><td width='64%' align='left'><strong> &nbsp;&nbsp;Nombre Asignatura</strong></td><td width='12%' align='center'><strong>Cr&eacute;ditos</strong></td><td width='12%' align='center'><strong>Secci&oacute;n</strong></td></tr><tr id='fila'><td height='15' bgcolor='#FF9' colspan='5' align='center'>*** USTED NO POSEE ASIGNATURAS INSCRITAS ***</td></tr></table>";
}

function enviarInscripcionIntensivos()
{	
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var formulario   = document.getElementById("frmInscripcion");
	var tot_cred     = document.getElementById("tot_cred").value;
	var sw = 0;
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.name.substring(0,9)  == "secciones") {
			if (elemento.value != '00')
				sw = 1;
		}
	}
	var mensaje = "Â¿Confirma registrar la inscripciÃ³n del estudiante ("+cedula+")? \n Recuerde que posteriormente no podrÃ¡ ser modificada!";
	
	if (sw == 0) {
		alert('Usted debe inscribir por lo menos una asignatura\n Por favor verifique los datos seleccionados!');
		return;
	} else if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'cod_esp':especialidad,
													'nucleo':nucleo,
													'tot_cred':tot_cred,
													'accion':'validarInscripcionIntensivos'
													}
								,'onSuccess': validarInscripcionIntensivos
								,'url':'admision/transInscripcionIntensivos.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function validarInscripcionIntensivos(req)
{	
	var cedula = document.getElementById("cedula").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		cambiar_cuerpo('admision/inscripcion_intensivos_vista.php', 'cuerpo');
	} else {
		alert("...ERROR! Su inscripciÃ³n no pudo ser registrada \n Por favor revise los datos suministrados");
		return;
	}
}