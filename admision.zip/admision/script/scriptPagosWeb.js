function abrirAjax()
{
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function enviarPagoWeb() {
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo	   = document.getElementById("nucleo").value;
	var deposito     = document.getElementById("deposito").value;
	var exoneracion  = document.getElementById("exoneracion").value;
	var nro_cuenta   = document.getElementById("cuenta").value;
	var nro_deposito = document.getElementById("nro_deposito").value;
	var monto        = document.getElementById("monto_deposito").value;
	var fecha_dep    = document.getElementById("fecha_dep").value;
	var tipo_exo     = document.getElementById("tipo_exo").value;
	var nro_planilla = document.getElementById("nro_planilla").value;
	var cod_asig     = document.getElementById("cod_asignatura").value;
	var tipo_pago = verMarcaPagoWeb();
	
	var mensajeGuardar = 'Â¿Confirma registrar el pago del estudiante '+cedula+'?';
	if(tipo_pago=='deposito') {
		if (nro_deposito=="" || monto=="" || fecha_dep=="") {
			alert("Ha dejado campos vacios. Por favor verifique sus datos");
			return;
		}
	}
	if(tipo_pago=='exoneracion') {
		if (nro_planilla=="" || cod_asig=="") {
			alert("Ha dejado campos vacios. Por favor verifique sus datos");
			return;
		}
	}
	if(tipo_pago=="deposito,exoneracion") {
		if (nro_deposito=="" || monto=="" || fecha_dep=="" || nro_planilla=="" || cod_asig=="") {
			alert("Ha dejado campos vacios. Por favor verifique sus datos");
			return;
		}
	}
	if(cedula!="" && tipo_pago!='')
	{
		if(confirm(mensajeGuardar))
		{
			AjaxRequest.post
			(
				{'parameters':{ 'cedula':cedula,
						   'especialidad':especialidad,
						   'nro_deposito':nro_deposito,
						   'nucleo':nucleo,
						   'monto':monto,
						   'fecha_dep':fecha_dep,
						   'tipo_exo':tipo_exo,
						   'nro_planilla':nro_planilla,
						   'cod_asig':cod_asig,
						   'tipo_pago':tipo_pago,
						   'accion':'registrarPago'}
						   ,'onSuccess':function(req){verificarTransaccionPagoWeb(req, cedula)}
						   ,'url':'admision/transPagoWeb.php'
						   ,'onError': function(req)
						   {
							 alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						   }
						}
			);
		}
	}
	else
	{
		alert("Ha dejado campos vacios. Por favor verifique sus datos");
	}
}

function verificarTransaccionPagoWeb(req,cedula)
{
	var resp=eval ("("+ req.responseText +")");
	if(resp!=false)
	{
		alert("El pago del estudiante "+cedula+" ha sido registrado con Ã©xito");
		limpiarPagoWeb();
		cargarPagosWeb();
	}
	else
	{
		alert("Error. Por favor verifique sus datos");
	}
}

function verMarcaPagoWeb() {
	var i, j=0, k=0;
	var marcados=[];
	formulario = document.getElementById("frmPago");
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.type == "checkbox") {
			if(elemento.checked) {
				j=j+1;
				marcados[k] = elemento.value;
				k++;
			}
		}
	}
	return marcados;
}

function limpiarPagoWeb() {
	var formulario = document.getElementById('frmPago');
	formulario.reset();
}

function buscarAsignaturaWeb() {
	var codigo = document.getElementById('cod_asignatura').value;
	var especialidad = document.getElementById('especialidad').value;
	
	AjaxRequest.post
			(
				{'parameters':{ 'codigo':codigo,
						   'especialidad':especialidad,
						   'accion':'buscarAsig'}
						   ,'onSuccess':respBuscarAsignaturaWeb
						   ,'url':'admision/transPagoWeb.php'
						   ,'onError': function(req)
						   {
							 alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						   }
						}
 		 );
}

function respBuscarAsignaturaWeb(req) {
	var codigo = document.getElementById('cod_asignatura');
	var nombre = document.getElementById('nombre_asignatura');
	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false)
	{
		nombre.value = resp[0]['nombre'];
	} else {
		alert ('El cÃ³digo de la asignatura ('+codigo.value+') no se encuentra en su pensum de estudios. Revise sus datos');
		codigo.value="";
		nombre.value="";
		codigo.focus();
	}
}

function cargarPagosWeb()
{
	var cedula = document.getElementById("cedula").value;
	AjaxRequest.post
	(
		{
			'parameters':{ 'cedula':cedula },
			'onSuccess': respCargarPagosWeb,
			'url': 'admision/mostrarPagos.php',
			'onError': function(req){
				alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
			}
		}
	);
}

function respCargarPagosWeb(req)
{
	var tablaPagos = document.getElementById('pagos');
	tablaPagos.innerHTML = '';
	tablaPagos.innerHTML = req.responseText;
}

function validarDeposito() {
	var monto = document.getElementById('nro_deposito');
	if (monto.value.length != parseInt(11))
	{
		alert ('El nÃºmero de depÃ³sito debe contener 11 dÃ­gitos');
		monto.value = '';
		monto.focus();
	}
}