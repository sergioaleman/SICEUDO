function inscribir_asignatura_ua(nro, accion) 
{
	var mensaje      = '';
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var credito      = document.getElementById("creditos"+nro).value;
	var nombre       = document.getElementById("nombre"+nro).value;
	var asignatura   = document.getElementById("codigo"+nro).value;
	var seccion      = document.getElementById("secciones"+nro);
	var maxCred      = document.getElementById("max_cred").value;
	var totCred      = document.getElementById("tot_cred");
	var asig_ins     = document.getElementById("asig_inscribir");
	var asig_obl     = document.getElementById("asig_obligatoria").value;
	var maxAsig	     = document.getElementById("max_asig").value;
	var obligatorias = document.getElementById("obligatorias").value;
	
	asig_ins.value = seccion.name;
	creditos_inscritos();
	cantidad_asignaturas_inscritas();

	if (obligatorias != '') {
		if (!buscar_obligatorias(asignatura)) {
			alert('Debes inscribir obligatoriamente la(s) asignatura(s) con problema(s) de repitencia(s)');
			mostrarSeccionesInscritas();
			return;
		}
	}
	if (accion == 'borrar') {
		seccion.value='00';
	}
	if ((seccion.value=='95') || (seccion.value=='98')) {
		alert ("SECCIÃ“N NO DISPONIBLE EN EL PROCESO DE INSCRIPCIÃ“N");
		mostrarSeccionesInscritas();
		return;
	}
	if (seccion.value=='00') {
		mensaje = "Â¿REALMENTE DESEA ELIMINAR LA ASIGNATURA: ("+asignatura+") "+nombre+"?" ;
	} else {
		mensaje = "Â¿Desea inscribir la asignatura ("+asignatura+") "+nombre+" en la secciÃ³n ("+seccion.value+")?";
	}
	if (!confirm(mensaje)) {
		mostrarSeccionesInscritas();
		return;
	} else if (!Asig_Obligatoria_Inscrita()) {
		alert ("Usted debe inscribir la asignatura ("+asig_obl+"). Y tiene un mÃ¡ximo de ("+maxCred+") crÃ©ditos a inscribir");
		mostrarSeccionesInscritas();
		return;
	} else if (parseInt(totCred.value) > parseInt(maxCred)) {
		alert ("Usted no puede inscribir una cantidad mayor a ("+maxCred+") unidades de cÅ•editos");
		seccion.value = '00';
		creditos_inscritos();
		return;
	} else {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'cod_esp':especialidad,
													'nucleo':nucleo,
													'asignatura':asignatura,
													'seccion':seccion.value,
													'accion':'nuevaInscripcion'
													}
								,'onSuccess': function(req){ nuevaInscripcion_ua(req, seccion.value) }
								,'url':'admision/transInscripcionUa.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function nuevaInscripcion_ua(req, seccion_ins)
{
	var asig_ins = document.getElementById("asig_inscribir");
	var seccion = document.getElementById(asig_ins.value);
	var maxAsig = document.getElementById("max_asig");
	var resp=eval ("("+ req.responseText +")");
	
	if(resp!=true)
	{
		seccion.value = '00';
		alert("ASIGNATURA NO REGISTRADA. "+resp);
	}
	mostrarSeccionesInscritas();
	creditos_inscritos();
	cantidad_asignaturas_inscritas();
	MostrarInscripcion();
	mostrarRepitencias();
}