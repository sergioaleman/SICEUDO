function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}
//MS: Si la seccion es == 99 no debe contar entre los total_cred
function creditos_inscritos()
{
	var i, k=0; creditos=0;
	var formulario   = document.getElementById("frmInscripcion");
	var totCred      = document.getElementById("tot_cred");
	
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.name.substring(0,9)  == "secciones") {
			if(elemento.value != "00" && elemento.value != "99") {
				creditos=parseInt(creditos)+parseInt(formulario.elements[i-1].value);
			}
		}
	}
	totCred.value = creditos;
}

function cantidad_asignaturas_inscritas() {
	var especialidad = document.getElementById("especialidad").value;
	
	AjaxRequest.post(
						{
							'parameters':  {    'especialidad':especialidad,
												'accion':'buscarInscritas'
											}
							,'onSuccess': respCantidadAsignaturasInscritas
							,'url':'admision/transConsultasAdmision.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							}
						}
					);
}

function respCantidadAsignaturasInscritas(req) {
	var resp = eval ("("+ req.responseText +")");
	
	if(resp != false) {
		var arregloDatos;
		arregloDatos = resp.split('||');
		var maxAsig	= document.getElementById("max_asig");
		maxAsig.value = arregloDatos[0];
	} else {
		alert("ERROR..! No se pudo cargar los datos");
		return;
	}
}

function inscribir_asignatura(nro, accion)
{
	var mensaje      = '';
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var credito      = document.getElementById("creditos"+nro).value;
	var nombre       = document.getElementById("nombre"+nro).value;
	var asignatura   = document.getElementById("codigo"+nro).value;
	var seccion      = document.getElementById("secciones"+nro);
	var maxCred      = document.getElementById("max_cred").value;
	var totCred      = document.getElementById("tot_cred");
	var asig_ins     = document.getElementById("asig_inscribir");
	var asig_obl     = document.getElementById("asig_obligatoria").value;
	var maxAsig	     = document.getElementById("max_asig").value;
	var obligatorias = document.getElementById("obligatorias").value;
	
	asig_ins.value = seccion.name;
	creditos_inscritos();
	cantidad_asignaturas_inscritas();

	if (obligatorias != '') {
		if (!buscar_obligatorias(asignatura)) {
			alert('Debes inscribir obligatoriamente la(s) asignatura(s) con problema(s) de repitencia(s)');
			mostrarSeccionesInscritas();
			return;
		}
	}
	if (accion == 'borrar') {
		seccion.value='00';
	}
	if ((seccion.value=='95') || (seccion.value=='98')) {
		alert ("SECCIÃ“N NO DISPONIBLE EN EL PROCESO DE INSCRIPCIÃ“N");
		mostrarSeccionesInscritas();
		return;
	}
	if (seccion.value=='00') {
		mensaje = "Â¿REALMENTE DESEA ELIMINAR LA ASIGNATURA: ("+asignatura+") "+nombre+"?" ;
	} else {
		mensaje = "Â¿Desea inscribir la asignatura ("+asignatura+") "+nombre+" en la secciÃ³n ("+seccion.value+")?";
	}
	if (!confirm(mensaje)) {
		mostrarSeccionesInscritas();
		return;
	} else if (!Asig_Obligatoria_Inscrita()) {
		alert ("Usted debe inscribir la asignatura ("+asig_obl+"). Y tiene un mÃ¡ximo de ("+maxCred+") crÃ©ditos a inscribir");
		mostrarSeccionesInscritas();
		return;
	} else if (parseInt(totCred.value) > parseInt(maxCred)) {
		alert ("Usted no puede inscribir una cantidad mayor a ("+maxCred+") unidades de cÅ•editos");
		seccion.value = '00';
		creditos_inscritos();
		return;
	} else {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'cod_esp':especialidad,
													'nucleo':nucleo,
													'asignatura':asignatura,
													'seccion':seccion.value,
													'accion':'nuevaInscripcion'
													}
								,'onSuccess': function(req){ nuevaInscripcion(req, seccion.value) }
								,'url':'admision/transInscripcionWeb.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function nuevaInscripcion(req, seccion_ins)
{
	var asig_ins = document.getElementById("asig_inscribir");
	var seccion = document.getElementById(asig_ins.value);
	var maxAsig = document.getElementById("max_asig");
	var resp=eval ("("+ req.responseText +")");
	
	if(resp!=true)
	{
		seccion.value = '00';
		alert("ASIGNATURA NO REGISTRADA. "+resp);
	}
	mostrarSeccionesInscritas();
	creditos_inscritos();
	cantidad_asignaturas_inscritas();
	MostrarInscripcion();
	mostrarRepitencias();
}

function buscar_obligatorias(asignatura) {
	var obligatorias = document.getElementById("obligatorias").value;
	var totCred      = document.getElementById("tot_cred").value;
	var credOblig    = document.getElementById("credObligatorios").value;
	var asig = obligatorias.split('||');
	var retorno = false;
	var enLista = 0;
	
	for (var i=0; i<asig.length-1; i++) {
		if (asignatura == asig[i])
			enLista = 1;
	}

	if ((enLista == 1) || (parseInt(totCred) > parseInt(credOblig))) {
		retorno = true;
	}
	return retorno;
}

function mostrarSeccionesInscritas() {
	var especialidad = document.getElementById('especialidad').value;
	
	AjaxRequest.post(
						{
							'parameters':  {    'especialidad':especialidad,
												'accion':'buscarInscritas'
											}
							,'onSuccess': respMostrarSeccionesInscritas
							,'url':'admision/transConsultasAdmision.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							}
						}
					);
}

function respMostrarSeccionesInscritas(req) {
	var i, k=0;
	var formulario = document.getElementById("frmInscripcion");
	var fechaActual = document.getElementById('fecha_actual').value;
	var resp = eval ("("+ req.responseText +")");

	if(resp != false) {
		var arregloDatos;
		arregloDatos = resp.split('||');
		if (arregloDatos[0] >= 0) {
			var codAsig=Array();
			var seccion=Array();
			var fecha=Array();
			codAsig=arregloDatos[1].split('-');
			seccion=arregloDatos[2].split('-');
			fecha=arregloDatos[3].split('*');
			for (i=0; i<formulario.elements.length; i++) {
				var elemento = formulario.elements[i];
				if(elemento.name.substring(0,9)  == "secciones") {
					formulario.elements[i].value='00';
					formulario.elements[i].disabled=false;
					formulario.elements[i+1].disabled=true;
					for(var j=0;j<arregloDatos[0];j++) {
						if(formulario.elements[i-3].value == codAsig[j]) {
							formulario.elements[i].value = seccion[j];
							if((fecha[j] < fechaActual) || (seccion[j] == '95') || (seccion[j] == '98')) {
								formulario.elements[i].disabled = true;
								formulario.elements[i+1].disabled = true;
							}
						}
					}
				}
			}
			creditos_inscritos();
		}
		marcarBorrar();	
	} else {
		alert("ERROR..! No se pudo cargar los datos");
		return;
	}
}

function marcarBorrar() {
	var formulario = document.getElementById("frmInscripcion");
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.name.substring(0,9) == "secciones") {
			formulario.elements[i+1].disabled=true;
			if (formulario.elements[i].value == '00')
				formulario.elements[i+1].disabled=true;
			else if (formulario.elements[i].disabled)
				formulario.elements[i+1].disabled=true;
			else
				formulario.elements[i+1].disabled=false;
		}
	}
}

function Asignatura_Obligatoria() {
	var i, k=0;
	var cedula = document.getElementById('cedula').value;
	var especialidad = document.getElementById('especialidad').value;
	var creditos = document.getElementById('max_cred');
	var asignatura_obligatoria = document.getElementById('asig_obligatoria');
	var creditosMaximos = document.getElementById('creditosMaximos');
	var asigObligatoria = document.getElementById('asigObligatoria');

	asignatura_obligatoria.value = asigObligatoria.value;
	creditos.value = creditosMaximos.value;
}

function Asig_Obligatoria_Inscrita() {
	var i;
	var formulario = document.getElementById("frmInscripcion");
	var asignatura_obligatoria = document.getElementById('asig_obligatoria').value;
	var inscrita=false;
	
	if ((asignatura_obligatoria == '')) {
		inscrita=true;
	} else {
		for (i=0; i<formulario.elements.length; i++) {
			var elemento = formulario.elements[i];
			if((elemento.name.substring(0,9)  == "secciones")&&(elemento.value != '00')) {
				if(formulario.elements[i-3].value==asignatura_obligatoria) {
						inscrita=true; 
				}
			}
		}
	}
	return inscrita;
}

function MostrarInscripcion()
{	
	AjaxRequest.post({
						
						'onSuccess': respMostrarInscripcion,
						'url': 'admision/VisualizaInscripcion.php',
						'onError': function(req){
							alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
		}
	});
}

function respMostrarInscripcion(req)
{
	var inscripcion=document.getElementById('tablaInscritas');
	inscripcion.innerHTML='';
	inscripcion.innerHTML=req.responseText;
}

function limpiarRegularesWeb() {
	var formulario = document.getElementById("frmInscripcion");
	var tablaA = document.getElementById("tablaInscripcion");
	formulario.reset();
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.name.substring(0,9)  == "secciones") {
			formulario.elements[i].value=='00';
			formulario.elements[i].disabled=true;
			formulario.elements[i+1].disabled=true;
		}
	}
	tablaA.innerHTML="<table align='center' width='100%' border='0' cellpadding='1' cellspacing='1' id='tablaInscripcion'><tr id='fila' bgcolor='#CCCCCC' height='15'><td width='12%' align='center'><strong>C&oacute;digo</strong></td><td width='64%' align='left'><strong> &nbsp;&nbsp;Nombre Asignatura</strong></td><td width='12%' align='center'><strong>Cr&eacute;ditos</strong></td><td width='12%' align='center'><strong>Secci&oacute;n</strong></td></tr><tr id='fila'><td height='15' bgcolor='#FF9' colspan='5' align='center'>*** USTED NO POSEE ASIGNATURAS INSCRITAS ***</td></tr></table>";
}

function enviarInscripcionWeb()
{	
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var formulario   = document.getElementById("frmInscripcion");
	var tot_cred     = document.getElementById("tot_cred").value;
	var sw = 0;
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.name.substring(0,9)  == "secciones") {
			if (elemento.value != '00')
				sw = 1;
		}
	}

	var mensaje = "Â¿Confirma registrar la inscripciÃ³n del estudiante ("+cedula+")? \n Recuerde que posteriormente no podrÃ¡ ser modificada!";
	
	if (sw == 0) {
		alert('Usted debe inscribir por lo menos una asignatura\n Por favor verifique los datos seleccionados!');
		return;
	} else if(confirm(mensaje)) {
		AjaxRequest.post(
			{
				'parameters': { 
				    'cedula':cedula,
					'cod_esp':especialidad,
					'nucleo':nucleo,
					'tot_cred':tot_cred,
					'accion':'validarInscripcionWeb'
					}
				,'onSuccess': validarInscripcionWeb
				,'url':'admision/transInscripcionWeb.php'
				,'onError': function(req)
				{
					alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
				}
			}
						);
	}
}

function validarInscripcionWeb(req)
{
	var cedula = document.getElementById("cedula").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		cambiar_cuerpo('admision/inscripcion_web_vista.php', 'cuerpo');
	} else {
		alert("...ERROR! Su inscripciÃ³n no pudo ser registrada \n Por favor revise los datos suministrados");
		return;
	}
}

function mostrarRepitencias()
{
	AjaxRequest.post({
						
						'onSuccess': respMostrarRepitencia,
						'url': 'admision/visualizaRepitencia.php',
						'onError': function(req){
							alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
		}
	});
}

function respMostrarRepitencia(req)
{
	var repitencia = document.getElementById('tablaRepitencia');
	repitencia.innerHTML = '';
	repitencia.innerHTML = req.responseText;
}

function inscribir_repitencias() {
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var obligatorias = document.getElementById("obligatorias").value;
	var tipo_rep = document.getElementById("tipo_rep").value;
	var cred_obl = document.getElementById("credObligatorios").value;
	
	AjaxRequest.post(
						{	'parameters':  {    'cedula':cedula,
												'cod_esp':especialidad,
												'nucleo':nucleo,
												'obligatorias':obligatorias,
												'tipo_rep':tipo_rep,
												'cred_obl':cred_obl,
												'accion':'inscripcionRep'
											}
							,'onSuccess': respInscribirRepitencias
							,'url':'admision/transInscripcionWeb.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							}
						}
					);	
}

function respInscribirRepitencias(req)
{
	var asig_ins = document.getElementById("asig_inscribir");
	var seccion = document.getElementById(asig_ins.value);
	var maxAsig = document.getElementById("max_asig");
	var resp = eval ("("+ req.responseText +")");
	
	mostrarSeccionesInscritas();
	creditos_inscritos();
	MostrarInscripcion();
	mostrarRepitencias();
}