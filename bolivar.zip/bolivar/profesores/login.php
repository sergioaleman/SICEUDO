<HTML>
<HEAD><TITLE>SICEUDO Bolívar - Profesores</TITLE>
<link href="estilos/estilos_login.css" rel="stylesheet" type="text/css"/>
<link rel="icon" type="image/x-icon" href="imagenes/logo.ico">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script type="text/JavaScript" language="JavaScript" src="include/js/funciones.js"></script>
<script type="text/JavaScript" language="JavaScript" src="include/js/AjaxRequest.js"></script>
<script type="text/JavaScript" language="JavaScript" src="script/scriptLogin.js"></script>
</HEAD>
<BODY>
<BR><BR><BR><BR><BR>
<div id="Main">
<div class="Contenedor-con-sombra" id="Main-BackCuerpoLeft">
	<div class="Contenedor-con-sombra" id="Main-BackCuerpoRight">
	<div id="top" align="center"></div>
<TABLE align="center" border="0" width="600" bgcolor="#FFFFFF">
	<TR><TD height="20"></TD></TR>
	<TR>
		<TD><div class="gradiente"><h1><span></span>Núcleo de Bolívar<br>Sistema Integral de Control de Estudios</h1></div>
		<TD height="50" width="100" align="right" class="tGris10"><img src="imagenes/version.png" name="version" width="32" height="32" border="0"><br>Versi&oacute;n 1.0.1</TD>
	</TR>
</TABLE>



<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2139263390076630"
     crossorigin="anonymous"></script>
<!-- Adsense -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2139263390076630"
     data-ad-slot="8044386606"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>


<TABLE width="600" align="center" border="0" cellpadding="1" cellspacing="0">
	<TR id="menu">
		<TD align="left" width="300" class="tBlanco10N">&nbsp;&nbsp;.: Bienvenido :.</TD>
		<TD align="right" width="300" class="tBlanco10N">SISTEMAS Open Source&nbsp;&nbsp;</TD>
	</TR>
</TABLE>
<TABLE width="600" align="center" bgcolor="#FFFFFF">
  <TR>
    <TD>
       <br>
        <BR>
      <FORM name="identificacion" action="http://201.249.180.234/bolivar/profesores/login.php" method="POST" target="_self">
<TABLE width="250" align="center" border="0" cellpadding="1" style="border-bottom-color : #8c8c8c; border-bottom-style : solid; border-bottom-width : 1px; border-left-color : #8C8C8C; border-left-style : solid; border-left-width : 1px; border-right-color : #8C8C8C; border-right-style : solid; border-right-width : 1px; border-top-color : #8C8C8C; border-top-style : solid; border-top-width : 1px;" bgcolor="#FFFFFF">
	<TR align="center">
		<TD colspan="2" class="tituloTabla">Autenticaci&oacute;n de Usuarios </TD>
	</TR>
	<TR><TD height="10"></TD></TR>
	<TR align="left">
		<TD  class="tGris10N">Nombre de Usuario:</TD>
		<TD rowspan="5"><IMG src="imagenes/seguridad.png" width="80" height="80" align="left" border="0"></TD>
	</TR>
	<TR>
		<TD><INPUT type="text" name="nombre" size="20" id="nombre" maxlength="30" tabindex="1" autocomplete="off"></TD>
	</TR>
	<TR><TD height="5"></TD></TR>
	<TR align="left">
		<TD class="tGris10N">Contrase&#241;a:</TD>
	</TR><TR>
		<TD><INPUT id="clave" type="password" name="clave" size="20" maxlength="30" tabindex="2" autocomplete="off"></TD>
	</TR>
	<TR>
		<TD><INPUT id="ipUser" type='hidden' name="ipUser" value=''></TD>
	</TR>
	<TR>
		<TD><INPUT id="macAddress" type='hidden' name="macAddress"  value='' ></TD>
	</TR>
	<TR><TD height="10"><INPUT id="base" type='hidden' name="base" value=''></TD></TR>
	<TR>
		<TD align="center" colspan="2"><BUTTON type="SUBMIT" class="boton" name="ingresar">
			<TABLE><TR><TD><IMG src="imagenes/ingresar.png"></TD><TD class="tGris10">Ingresar</TD></TR></TABLE>
			</BUTTON> <BUTTON type="RESET" class="boton">
			<TABLE><TR><TD><IMG src="imagenes/limpiar.png"></TD><TD class="tGris10">Limpiar</TD></TR></TABLE></BUTTON></TD>
	</TR>
</TABLE>
</FORM>
<BR>
<div align="right" class="tGris10N">Para un mejor funcionamiento, descarga Mozilla Firefox <a href="http://www.mozilla.org/es-ES" target="_blank" >AQUI</a> <img src="imagenes/mozilla.jpg" name="version" width="32" height="32" border="0"><br></div>
</TD></TR>
	<TR>
    <TD height="10"></TD>
  </TR>
</TABLE>
<TABLE align="center" width="602" cellspacing="0" cellpadding="0">
	<TR><TD height="20" bgcolor="Black" class="tBlanco10" align="center">&copy; 2012. Universidad de Oriente :: Rectorado</TD></TR>
</TABLE>
</div></div>
</FORM>
</BODY>
</HTML>