function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

/*****************************************************************/

function estado_cuenta() {
	var i, j=0;
	var formulario = document.getElementById("misReportes");
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('codNucleo').value;
	var codEsp = document.getElementById('sel_esp').value;
	var mensaje = document.getElementById('mensajes');
	
	mensaje.innerHTML = "";
	var url = "caja/reportes/estado_cuentaVista.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}

/***********************************************************/

function enviarDeposito() {
	var cedula    = document.getElementById("cedula").value;
	var idd       = document.getElementById("idd").value;
	var mel       = document.getElementById("mel").checked;
	var fecha_mel = document.getElementById("fecha_mel").value;
	var mensaje   = document.getElementById('mensajes');
	
	mensaje.innerHTML = "";
	
	if(cedula=="" || idd==''){
		mensaje.innerHTML = "Ha dejado campos vacios. Por favor verifique sus datos";
		return;
	}
	else if (mel && fecha_mel==''){
		mensaje.innerHTML = "Ha dejado la fecha vacia. Por favor verifique sus datos";
		return;
	}
	AjaxRequest.post
	(
		{'parameters':{ 'idd':idd
		 			   ,'mel':mel
		 			   ,'fecha_mel':fecha_mel
					   ,'accion':'registrarDeposito'}
					   ,'onSuccess':function(req){verificarTransaccionDeposito(req)}
					   ,'url':'caja/transaccion/transCaja.php'
					   ,'onError': function(req)
					   {
						 mensaje.innerHTML = 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText;
					   }
					  }
	);
}

function verificarTransaccionDeposito(req)
{
	var resp=eval ("("+ req.responseText +")");
	var mensaje = document.getElementById('mensajes');
	
	if(resp==false) mensaje.innerHTML = "el deposito no pudo ser registrado";
	else {	
	  limpiarDeposito();
	  mensaje.innerHTML = "<font color=blue>el deposito ha sido registrado con éxito</font>";
	}
}

function limpiarDeposito() {
	var formulario = document.getElementById('fDeposito');
	formulario.reset();
	var mensaje = document.getElementById('mensajes');
	mensaje.innerHTML = "";
	var mel = document.getElementById('mel');
	mel.checked = false;
	document.getElementById('div_mel').style.display='none';
}

function ayuda_deposito() {
	var url = "http://ccaanz.udo.edu.ve/DocumentosInformativos/registroDeposito.html";
	var myWin = window.open(url);
}
/**********************************************************/

function solicitarValDocumento()
{ 
    var cantidad = document.getElementById("cantidad").value;
	var doc_info = document.getElementById("documento").value;
	var doc_info2= doc_info.split("-");
	var codigo   = parseFloat(doc_info2[0]);
	var mensaje = document.getElementById('mensajes');
	mensaje.innerHTML = "";

	AjaxRequest.post({
							'parameters': { 'codigo':codigo,
											'cantidad':cantidad,
											'accion':'solicitarValDocumento'
											}
							,'onSuccess': respValDocumento
							,'url':'caja/transaccion/transCaja.php'
							,'onError': function(req)
							{
								mensaje.innerHTML = 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText;
							}
					});
}

function respValDocumento(req)
{
	var resp=eval ("("+ req.responseText +")");
	var mensaje  = document.getElementById('mensajes');
	
	if(resp==false) mensaje.innerHTML = "La solicitud no pudo ser registrada";
	else if (resp.status=="error") mensaje.innerHTML = resp.message;
	else mensaje.innerHTML = "<font color=blue>Solicitud registrada exitosamente!</font>";
}