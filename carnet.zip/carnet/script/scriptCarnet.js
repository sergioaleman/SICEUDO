function algo(laCedula) {
			alert(1);
			$('#file_upload').uploadify({
				'buttonText'     : 'Foto',
				'method'         : 'post',
				'multi'          : true,
				'preventCaching' : true,
				'swf'            : 'http://estudiantes.anz.udo.edu.ve/carnet/librarys/uploadify/uploadify.swf',
				'uploader'       : 'http://estudiantes.anz.udo.edu.ve/carnet/librarys/uploadify/uploadify.php',
				'onUploadSuccess': function(file, data, response) {
					var json = jQuery.parseJSON(data);
					if (json.success == 1) {
						// FINO!!!
						$('#result').html('');
						$('#result').append('<img src="' + json.message + '" /><br><a hfref="http://estudiantes.anz.udo.edu.ve/carnet/create.php"> imprimir</a>');
					} else {
						$('#result').html(json.message);
					}
				},
				'onUploadError': function(file, errorCode, errorMsg, errorString) {
					$('#result').html('ERROR: No se pudo subir la imagen ' + file.name + '<br />' + 
						"A: " + errorString + "<br />" +
						"B: " + errorMsg + "<br />" +
						"C: " + errorCode);
				},
				'onUploadStart': function(file) {
					$("#file_upload").uploadify("settings", "formData", {'cedula': laCedula});	// cÃ©dula del estudiante!!!
				}

			});
};