// JavaScript Document
var up,t,cmin1,csec1,min1,sec1,Hserver,Tsecons;
Tsecons=true;
Tssec-=2;
function Minutes(data) {
        for(var i=0;i<data.length;i++) if(data.substring(i,i+1)==":") break;
        return(data.substring(0,i)); 
		}
function Seconds(data) {
        for(var i=0;i<data.length;i++) if(data.substring(i,i+1)==":") break;
        return(data.substring(i+1,data.length)); 
		}
function Display_Titilar() {
        var disp;
		min=cmin1;
		sec=csec1;
		Tssec++;
        if(min<=9) disp=" 0";
        else disp=" ";
		if(Tsecons==true) { disp+=min+":"; Tsecons=false;}
		else {disp+=min+"<font color=\"#FFFFFF\">:</font>"; Tsecons=true; }
        if(sec<=9) disp+="0"+sec;
        else disp+=sec;
   		Hserver.innerHTML=disp;	
		t=setTimeout("Display_Titilar()",1000);
		if(Tssec>=60) { Tssec=0; UpRepeat();}
		}
function Display(min,sec) {
        var disp;
        if(min<=9) disp=" 0";
        else disp=" ";
        disp+=min+":";
        if(sec<=9) disp+="0"+sec;
        else disp+=sec;
        return(disp); 
		}
function Up() {
        cmin1=Minutes(Tserver);
        csec1=Seconds(Tserver);
        Hserver=document.getElementById("HoraServer");
        UpRepeat(); 
		}
function UpRepeat() {
        csec1++;
        if(csec1==60) { csec1=0; cmin1++; }
        Hserver.innerHTML=Display(cmin1,csec1);
        }