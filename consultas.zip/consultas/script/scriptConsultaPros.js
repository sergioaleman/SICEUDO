function consultaProsecucion(valor)
{
	var consulta=document.getElementById('sel_consultas').value;
	var codNucleo=document.getElementById('sel_nucleo').value;
	var anio=document.getElementById('sel_anio').value;
	var periodo=document.getElementById('sel_periodo').value;
	var esp=document.getElementById('sel_especialidad').value;
	var ancho='800';
	var largo='800';
	
	if(valor=="pros")
	{
		var url="consultas/consultas.php?consulta="+consulta+"&codNucleo="+codNucleo+"&anio="+anio+"&periodo="+periodo+"&esp="+esp;
	}
	else if(valor=="plan")
	{
		var codAsig=document.getElementById('sel_asignatura').value;
		var sec=document.getElementById('sel_seccion').value;
		var dpto=document.getElementById('sel_dpto').value;
		var url="consultas/planAcad.php?consulta="+consulta+"&codNucleo="+codNucleo+"&anio="+anio+"&periodo="+periodo+"&esp="+esp+"&codAsig="+codAsig+"&seccion="+sec+"&dpto="+dpto;
	}
	
	
	if(consulta!=0 && periodo!=0 && anio!=0 && codNucleo!=0)
		popup(url,ancho,largo);
	else
		alert("Debe selecionar el tipo de consulta, periodo y aÃ±o");
	
}

function buscarEstuAvanzado()
{
	var url="consultas/ver_estu.php";
	var alto='900';
	var ancho='900';
	popup(url,alto,ancho);
}

function buscar_resultado_estu()
{
	var consulta=document.getElementById('sel_consulta').value;
	var txt_buscar=document.getElementById('txt_buscar').value;
	var tipo=document.getElementById('tipo').value;
	var url;
	
	if(tipo=='s')
	{
		url="cons="+consulta+"&busc="+txt_buscar+"&tipo="+tipo;
		if(consulta==0)
			alert("Debe seleccionar el tipo de consulta que desea realizar");
	}
	else if(tipo=='m')
	{
		var cedula=document.getElementById('txt_cedula').value;
		var nombres=document.getElementById('txt_nombres').value;
		var apellidos=document.getElementById('txt_apellidos').value;
		url="cons="+consulta+"&busc="+txt_buscar+"&tipo="+tipo+"&ced="+cedula+"&nomb="+nombres+"&apel="+apellidos;
	}
	
		//alert(consulta);
		divPrimeraVista=document.getElementById('cargar_info_estu');
		divSegundaVista=document.getElementById('cargar_resul_estu');
		
		divPrimeraVista.innerHTML= '<img src="../imagenes/cargando.gif">';
		ajax=abrirAjax();
		ajax.open("POST", "consultar_estu.php",true);
		ajax.onreadystatechange=function()
		{
			if (ajax.readyState==4)
			{
				divSegundaVista.innerHTML = ajax.responseText;
				divPrimeraVista.style.display="none";//ocultar
				divSegundaVista.style.display="block";//mostrar
	
			}
		}
		
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		ajax.send(url);
}

function busquedaMultiple()
{
	var valor=document.getElementById("sel_consulta").value;
	
	if(valor=='4')
	{
		document.getElementById("camposMultiples").style.display="block";
		document.getElementById("tipo").value="m";
		
		document.getElementById("txt_buscar").value='';
		document.getElementById("txt_buscar").disabled=true;
		
		document.getElementById("txt_nombres").value='';
		document.getElementById("txt_apellidos").value='';
		document.getElementById("txt_cedula").value='';
	}
	else
	{
		document.getElementById("camposMultiples").style.display="none";
		document.getElementById("tipo").value="s";
		document.getElementById("txt_buscar").disabled=false;	
	}
}

function buscarInfoEstuConsul() 
{
	var accion="buscarInfoEstu";

	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"op":accion
		 }
		,'onSuccess':respBuscarInfoEstuConsul
		,'url':'consultas/transConsultas.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);	
}

function respBuscarInfoEstuConsul(req)
{
	resp=eval ("("+ req.responseText +")");
	
	if(resp.length>0)
	{
		document.getElementById("txt_cedula").value=resp[0]["cedula"];
		document.getElementById("txt_nombre").value=resp[0]["nombres"]+" "+resp[0]["apellidos"];
		document.getElementById("txt_nucleo").value=resp[0]["nucleo"];
		
		var cedula=resp[0]["cedula"];
		
		divPrimeraVista=document.getElementById('infoEstuConsu');
		divSegundaVista=document.getElementById('infoEstuResultado');
		
		divSegundaVista.innerHTML= '<img src="imagenes/cargando3.gif"><p>Cargando...</p>';
		ajax=abrirAjax();
		ajax.open("POST", "consultas/consultar_sem_act_estu.php",true);
		ajax.onreadystatechange=function()
		{
			if (ajax.readyState==4)
			{
				divSegundaVista.innerHTML = ajax.responseText;
				divPrimeraVista.style.display="none";//ocultar
				divSegundaVista.style.display="block";//mostrar
			}
		}
		
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		ajax.send("cedEstu="+cedula);
	}
	else
	{
		alert("Error! algo saliÃ³ mal");
		cambiar_cuerpo('consulta/estudiantes.php','cuerpo');
		return;
	}
}

function limpiarEstuConsul()
{
	document.getElementById('txt_cedula').value="";
	document.getElementById('txt_nombre').value="";
	document.getElementById('txt_nucleo').value="";
	document.getElementById('codEsp').value="";
	document.getElementById('estatus').value="";
	
	var divPrimeraVista=document.getElementById('infoEstuConsu');
	var	divSegundaVista=document.getElementById('infoEstuResultado');
	document.getElementById('txt_cedula').focus();

	divPrimeraVista.style.display='block';
	divSegundaVista.style.display='none';
}

function limpiarConsPlan()
{
	document.getElementById('sel_consultas').value=0;
	document.getElementById('sel_periodo').value=0;
	document.getElementById('sel_anio').value=0;
	document.getElementById('sel_dpto').value=0;
	document.getElementById('sel_especialidad').value=0;
	document.getElementById('sel_especialidad').disabled=false;
	document.getElementById('sel_asignatura').value=0;
	document.getElementById('sel_asignatura').disabled=false;
	document.getElementById('sel_seccion').value=0;
	document.getElementById('sel_seccion').disabled=false;
}

function verRegistroHisto(codEsp) //cambios
{
	var cedEstu=document.getElementById('txt_cedula').value;
	//var codEsp=document.getElementById('codEsp').value;
	
	var url="reportes/constancias/historico_nota.php?cedula="+cedEstu+"&esp="+codEsp;
	openMyModal(url);
}

function cargarAsigCons()
{
	var codEsp=document.getElementById("sel_especialidad").value;
	var accion="cargarAsig";
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"codEsp":codEsp,
			"op":accion
		 }
		,'onSuccess':respCargarAsigCons
		,'url':'consultas/transConsultas.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function respCargarAsigCons(req)
{
	var resp=eval ("("+ req.responseText +")");
	
	if(resp.length>0)
	{
		document.getElementById('sel_seccion').length=1;
		for(var i=1,j=0;j<resp.length;i++,j++)
		{
			document.getElementById('sel_asignatura').options[i]= new Option(resp[j]["codigo"]+" - "+resp[j]["nombre"]);
			document.getElementById('sel_asignatura').options[i].value=resp[j]["codigo"]+"-"+resp[j]["tipo_pensum"];
		}
	}
	else
	{
		alert("No se encontraron asignaturas registradas para la especialidad seleccionada");
		document.getElementById('sel_asignatura').length=1;
		document.getElementById('sel_seccion').length=1;
	}
	
}

function cargarSecCons()
{
	var codAsig=document.getElementById("sel_asignatura").value;
	var codNuc=document.getElementById("sel_nucleo").value;
	var periodo=document.getElementById("sel_periodo").value;
	var anio=document.getElementById("sel_anio").value;
	var accion="buscarSeccion";
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"codAsig":codAsig,
			"codNuc":codNuc,
			"periodo":periodo,
			"anio":anio,
			"op":accion
		 }
		,'onSuccess':respCargarSecCons
		,'url':'consultas/transConsultas.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function respCargarSecCons(req)
{
	var resp=eval ("("+ req.responseText +")");
	
	if(resp.length>0)
	{
		
		for(var i=1,j=0;j<resp.length;i++,j++)
		{
			document.getElementById('sel_seccion').options[i]= new Option(resp[j]["seccion"]);
			document.getElementById('sel_seccion').options[i].value=resp[j]["seccion"];
		}
	}
	else
	{
		alert("No se encontraron secciones planificadas para la asignatura seleccionada");
		document.getElementById('sel_seccion').length=1;
	}
}

function cargarAsigPrec()
{
	var codDpto=document.getElementById("sel_dpto").value;
	var codNuc=document.getElementById("sel_nucleo").value;
	var accion="buscarAsigPrecod";
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"codDpto":codDpto,
			"codNuc":codNuc,
			"op":accion
		 }
		,'onSuccess':respCargarAsigPrec
		,'url':'consultas/transConsultas.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function respCargarAsigPrec(req)
{
	var resp=eval ("("+ req.responseText +")");	
	
	if(resp!="")
	{
		resp=resp.split("|");
		document.getElementById('sel_seccion').length=1;
		for(var i=1,j=0;j<resp.length-1;i++,j++)
		{
			asig=resp[j].split("-");
			document.getElementById('sel_asignatura').options[i]= new Option(asig[0]+" - "+asig[1]);
			document.getElementById('sel_asignatura').options[i].value=asig[0]+"-"+asig[2];
		}
		document.getElementById('sel_especialidad').disabled=true;
		document.getElementById('sel_asignatura').disabled=true;
		document.getElementById('sel_seccion').disabled=true;
	}
	else
	{
		alert("No se encontraron asignaturas registradas para el departamento seleccionado");
		document.getElementById('sel_asignatura').length=1;
		document.getElementById('sel_seccion').length=1;
	}
}

function materiasPorCursar() //cambios
{
	var cedEstu=document.getElementById('txt_cedula').value;
	var codEsp=document.getElementById('codEsp').value;
	
	var url="reportes/constancias/ver_asignaturas_por_cursar.php?cedula="+cedEstu+"&esp="+codEsp;
	openMyModal(url);
}

function verPensumConsulta(codEsp)
{
	var cedEstu=document.getElementById('txt_cedula').value;
	//var codEsp=document.getElementById('codEsp').value;
	
	var url="reportes/constancias/ver_pensum.php?cedula="+cedEstu+"&esp="+codEsp;
	openMyModal(url);
}