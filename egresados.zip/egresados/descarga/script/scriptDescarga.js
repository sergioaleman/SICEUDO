function consultaEgresadoPla() {
	var cedula = document.getElementById("cedulaPla").value;
	var nacionalidad = document.getElementById("nacionalidadPla").value;
	var operacion = "buscarEgresadoPla";
	var horaValida = document.getElementById("horaValida").value;

	if (horaValida == '0' || horaValida == 0 || horaValida == '' || horaValida == null || horaValida == 'null') {
		swal({title: '', text: 'Disculpe. Horario no disponible para generar y descargar la planilla de solicitud de documentos', animation: false});
		return;
	}
	
	if (cedula == '') {
		swal({title: '', text: 'Debes ingresar el nÃºmero de cÃ©dula', animation: false});
		return;
	}
	
	AjaxRequest.post
	(
		{
		'parameters':
		 {
			"cedula":cedula,
			"nacionalidad":nacionalidad,
			"operacion":operacion
		 }
		,'onSuccess':respconsultaEgresadoPla
		,'url':'descarga/transaccion/transDescarga.php'
		,'onError':function(req)
			{ 
				swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
			}
		}
	);
}

function respconsultaEgresadoPla(req)
{
	var resp = eval ("("+ req.responseText +")");
	if (resp.length > 0) {
		document.getElementById("nombresPla").value = resp[0]["nombres"];
		document.getElementById("apellidosPla").value = resp[0]["apellidos"];
		document.getElementById("espePla").innerHTML = '<option value="-1">TÃ­tulo obtenido...</option>';
		for(var i=0; i<resp.length; i++) {
			document.getElementById('espePla').options[i] = new Option(resp[i]['titulo']);
			document.getElementById('espePla').options[i].value = resp[i]['codigo_tit']+'||'+resp[i]['titulo']+'||'+resp[i]['tipo'];
		}
		document.getElementById("nucleoPla").value = resp[0]["descripcion"];
		document.getElementById("telefonoPla").value = '';
		document.getElementById("correoPla").value = '';
		document.getElementById("detalle_doc").innerHTML = '';
	} else {
		swal({
			  title: "",
			  text: "El nÃºmero de cÃ©dula no se encuentra registrado como egresado de esta casa de estudios!",
			  animation: false,
			  type: "error",
			  confirmButtonText: "OK"
		});
		document.getElementById("nombresPla").value = '';
		document.getElementById("apellidosPla").value = '';
		document.getElementById("espePla").innerHTML = '<option value="-1">TÃ­tulo obtenido...</option>';
		document.getElementById("nucleoPla").value = '';
		document.getElementById("telefonoPla").value = '';
		document.getElementById("correoPla").value = '';
		document.getElementById("documentoPla").value = '-1';
		document.getElementById("cantidadPla").value = '1';
		document.getElementById("detalle_doc").innerHTML = '';
		document.getElementById("cedulaPla").focus();
	}
}

function cargarNucleo() {
	var cedula = document.getElementById("cedulaPla").value;
	var especialidad = document.getElementById("espePla").value;
	var operacion = 'cargarNucleo';
	
	var tmpEspe = especialidad.split('||');
	var espe = tmpEspe[0];
	
	AjaxRequest.post
	(
		{
		'parameters':
		 {
			"cedula":cedula,
			"especialidad":espe,
			"operacion":operacion
		 }
		,'onSuccess':respCargarNucleo
		,'url':'descarga/transaccion/transDescarga.php'
		,'onError':function(req)
			{ 
				swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
			}
		}
	);
}

function respCargarNucleo(req) {
	var resp = eval ("("+ req.responseText +")");
	if (resp.length > 0) {
		document.getElementById("nucleoPla").value = resp[0]["descripcion"];
	}
}

function cargarUsoDocu(uso) {
	var area = document.getElementById("areaSoli").value;
	var operacion = 'cargarDocu';

	AjaxRequest.post
	(
		{
		'parameters':
		 {
		 	"area":area,
			"uso":uso,
			"operacion":operacion
		 }
		,'onSuccess':respCargarUsoDocu
		,'url':'descarga/transaccion/transDescarga.php'
		,'onError':function(req)
			{ 
				swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
			}
		}
	);
}

function respCargarUsoDocu(req) {
	var resp = eval ("("+ req.responseText +")");
	var descripcion;
	if (resp.length > 0) {
		document.getElementById('documentoPla').options.length=0;
		document.getElementById('documentoPla').options[0]= new Option('Nombre del documento...');
		document.getElementById('documentoPla').options[0].value='-1';
		document.getElementById('documentoPla').options[0].selected = true;

		for(var i=1,j=0; j<resp.length; i++,j++) {
			if (resp[j]['soporte'] == '1')
				descripcion = resp[j]['descripcion']+' '+resp[j]['observacion']+' - (Requiere Soporte)';
			else
				descripcion = resp[j]['descripcion']+' '+resp[j]['observacion'];
			document.getElementById('documentoPla').options[i] = new Option(descripcion);
			document.getElementById('documentoPla').options[i].value = resp[j]['codigo']+'||'+resp[j]['descripcion']+'||'+resp[j]['area']+'||'+resp[j]['costo_bs_pre']+'||'+resp[j]['costo_bs_post'];
		}

		for(var i=0; i<resp.length; i++) {
			
		}
	} else {
		document.getElementById('documentoPla').innerHTML = '<option value="-1">Nombre del documento...</option>';
	}
}

function cargarAreaDocu() {
		document.getElementById('documentoPla').options.length=0;
		document.getElementById('documentoPla').options[0]= new Option('Nombre del documento...');
		document.getElementById('documentoPla').options[0].value='-1';
		document.getElementById('documentoPla').options[0].selected = true;

		document.getElementById('usoSoli').value="-1";
}

function limpiarEgresadoPla() {
	var cedula = document.getElementById("cedulaPla");
	var nacionalidad = document.getElementById("nacionalidadPla");
	var nucleoSoli = document.getElementById("nucleoSoli");
	var nombres = document.getElementById("nombresPla");
	var apellidos = document.getElementById("apellidosPla");
	var especialidad = document.getElementById("espePla");
	var nucleo = document.getElementById("nucleoPla");
	var telefono = document.getElementById("telefonoPla");
	var correo = document.getElementById("correoPla");
	var documento = document.getElementById("documentoPla");
	var cantidad = document.getElementById("cantidadPla");
	var tablaDocu = document.getElementById("detalle_doc");
	var cant_doc = document.getElementById("cant_doc");
	var uso = document.getElementById('usoSoli');
	var area = document.getElementById('areaSoli');
	var fila = document.getElementById("otro_pago");

	nacionalidad.value = 'V';
	cedula.value = '';
	nombres.value = '';
	apellidos.value = '';
	especialidad.innerHTML = '<option value="-1">TÃ­tulo obtenido...</option>';
	nucleo.value = '';
	nucleoSoli.value = '-1';
	telefono.value = '';
	correo.value = '';
	documento.innerHTML = '<option value="-1">Nombre del documento...</option>';
	documento.value = '-1';
	cantidad.value = '1';
	uso.disabled = false;
	uso.value = '-1';
	area.disabled = false;
	area.value = '-1';
	cant_doc.value = 0;
	tablaDocu.innerHTML = '';
	$('#nroReferencia').val('');
	$('#fechaReferencia').text('');
	$('#montoReferencia').text('');
	$('#saldoReferencia').text('');
	$('#nroReferencia2').val('');
	$('#fechaReferencia2').text('');
	$('#montoReferencia2').text('');
	$('#saldoReferencia2').text('');
	$('#totalCancelar').text(accounting.formatMoney(0, "", 2, ".", ","));
	$('#total_cancelar').val(0);
	$('#total_saldo').val(0);
	fila.style = 'visibility: hidden';
	$('#load').hide();
	cedula.focus();
}

function limpiarEgresadoDocu() {
	var cantidad = document.getElementById("cantidadPla");
	var tablaDocu = document.getElementById("detalle_doc");
	var cant_doc = document.getElementById("cant_doc");
	var uso = document.getElementById('usoSoli');
	var area = document.getElementById('areaSoli');
	var fila = document.getElementById("otro_pago");
	var btnDescargar = document.getElementById("btnDescargar");

	document.getElementById('documentoPla').options.length=0;
	document.getElementById('documentoPla').options[0]= new Option('Nombre del documento...');
	document.getElementById('documentoPla').options[0].value='-1';
	document.getElementById('documentoPla').options[0].selected = true;

	cantidad.value = '1';
	uso.disabled = false;
	uso.value = '-1';
	area.disabled = false;
	area.value = '-1';
	cant_doc.value = 0;
	tablaDocu.innerHTML = '';
	btnDescargar.disabled = false;
	//$("#iconLoading").removeClass('preloader');

	$('#totalCancelar').text(accounting.formatMoney(0, "", 2, ".", ","));
	$('#total_cancelar').val(0);
	$('#total_saldo').val(0);

	$('#nroReferencia').val('');
	$('#fechaReferencia').text('');
	$('#montoReferencia').text('');
	$('#saldoReferencia').text('');
	$('#nroReferencia2').val('');
	$('#fechaReferencia2').text('');
	$('#montoReferencia2').text('');
	$('#saldoReferencia2').text('');
	fila.style = 'visibility: hidden';
	$('#load').hide();
}

function agregarDocumento(obj) {
	obj.value = parseInt(obj.value) + 1;
	var oId = obj.value;

	var cedula = document.getElementById("cedulaPla").value;
	var especialidadV = document.getElementById("espePla").value;
	var documento = document.getElementById("documentoPla");
	var especialidad = document.getElementById("espePla");
	var cantidad = document.getElementById("cantidadPla");
	var cant_doc = document.getElementById("cant_doc").value;

	var documentoPla = documento.value;
	var espe = especialidadV.split('||');

	var tipo_espe = espe[2];
	var costo = documentoPla.split('||');
	var costo_pre = costo[3];
	var costo_post = costo[4];
	var costoDocu = 0;
	
	if (cedula == '') {
		swal({title: '', text: 'Debes ingresar el nÃºmero de cÃ©dula', animation: false});
		return;
	} else if (especialidadV == '-1') {
		swal({title: '', text: 'Debes seleccionar el tÃ­tulo obtenido', animation: false});
		return;
	} else if (documento.value == '-1') {
		swal({title: '', text: 'Debes seleccionar el nombre del documento', animation: false});
		return;
	} else if (cantidad.value == '-1') {
		swal({title: '', text: 'Debes seleccionar la cantidad', animation: false});
		return;
	}
	
	var tmpDocu = documento.value.split('||');
	var tmpEspe = especialidad.value.split('||');

	if (tmpDocu[0]=='39' || tmpDocu[0]=='40') {
		if (tmpEspe[0]!='4205' && tmpEspe[0]!='4210' && tmpEspe[0]!='4215') {
			swal({title: '', text: 'Disculpe, documento disponible sÃ³lo para el Ã¡rea de salud', animation: false});
			
			if (tipo_espe == 0)
				costoDocu = parseFloat(costo_pre) * parseFloat(cantidad.value);
			else if (tipo_espe == 1)
				costoDocu = parseFloat(costo_post) * parseFloat(cantidad.value);
			
			var totalCancelar = document.getElementById("total_cancelar").value;
			var total_cancelar_new = 0;
			total_cancelar_new = parseFloat(totalCancelar) - parseFloat(costoDocu);
			
			// Actualiza el total a cancelar
			$('#totalCancelar').text(accounting.formatMoney(total_cancelar_new, "", 2, ".", ","));
			$('#total_cancelar').val(total_cancelar_new);

			return;	
		}
	}

	if (cant_doc > 12) {
		swal({title: '', text: 'Disculpe, no puede realizar una solicitud con mÃ¡s de 12 documentos', animation: false});
		return;
	}

	document.getElementById('usoSoli').disabled = true;
	document.getElementById('areaSoli').disabled = true;

	if (tipo_espe == 0)
		costoDocu = parseFloat(costo_pre) * parseFloat(cantidad.value);
	else if (tipo_espe == 1)
		costoDocu = parseFloat(costo_post) * parseFloat(cantidad.value);

	var strHtml1 = tmpEspe[1] + '<input type="hidden" id="especialidad_' + oId + '" name="especialidad_' + oId + '" value="' + tmpEspe[0] + '"/>' ;
	var strHtml2 = tmpDocu[1] + '<input type="hidden" id="documento_' + oId + '" name="documento_' + oId + '" value="' + tmpDocu[0] + '"/>' ;
    var strHtml3 = cantidad.value + '<input type="hidden" id="cantidad_' + oId + '" name="cantidad_' + oId + '" value="' + cantidad.value + '"/><input type="hidden" id="costoDoc_' + oId + '" name="costoDoc_' + oId + '" value="' + costoDocu + '"/>' ;
	var strHtml4 = '<span class="fa fa-trash-o" title="Eliminar" style="cursor:pointer" onclick="eliminarFilaDocumento(' + oId + ');"></span>';
    strHtml4 += '<input type="hidden" id="hdnIdCampos_' + oId +'" name="hdnIdCampos[]" value="' + oId + '" />';
		
	var objTr = document.createElement("tr");
	objTr.id = "rowDetalle_" + oId;
	objTr.style ='border-bottom-width:1px; border-bottom-style:solid; border-bottom-color: #CCC; background-color: #FFF';
	var objTd1 = document.createElement("td");
	objTd1.id = "tdDetalle_1_" + oId;
	objTd1.innerHTML = strHtml1;
	var objTd2 = document.createElement("td");
	objTd2.id = "tdDetalle_2_" + oId;	
	objTd2.innerHTML = strHtml2;
	var objTd3 = document.createElement("td");
	objTd3.id = "tdDetalle_3_" + oId;	
	objTd3.innerHTML = strHtml3;
	var objTd4 = document.createElement("td");
	objTd4.id = "tdDetalle_4_" + oId;	
	objTd4.innerHTML = strHtml4;
		
	objTr.appendChild(objTd1);
	objTr.appendChild(objTd2);
	objTr.appendChild(objTd3);
	objTr.appendChild(objTd4);

	var objTbody = document.getElementById("detalle_doc");
	objTbody.appendChild(objTr);
	return false;
}

function eliminarFilaDocumento(oId) {
	var objHijo = document.getElementById('rowDetalle_' + oId);
	var objPadre = objHijo.parentNode;
	var costoDoc = document.getElementById("costoDoc_"+ oId).value;
	var totalCancelar = document.getElementById("total_cancelar").value;
	var total_cancelar_new = 0;
	total_cancelar_new = parseFloat(totalCancelar) - parseFloat(costoDoc);
	
	// Actualiza el total a cancelar
	$('#totalCancelar').text(accounting.formatMoney(total_cancelar_new, "", 2, ".", ","));
	$('#total_cancelar').val(total_cancelar_new);

	// Elimina la fila del documento
	objPadre.removeChild(objHijo);
	var fila = document.getElementById('cant_doc').value;
	fila--;
	document.getElementById('cant_doc').value = fila;
	
	if (fila == 0) {
		document.getElementById('usoSoli').disabled = false;
		document.getElementById('areaSoli').disabled = false;
	}
	return false;
}

function descargarPlanilla() {
	var cedula = document.getElementById("cedulaPla").value;
	var telefono = document.getElementById("telefonoPla").value;
	var correo = document.getElementById("correoPla").value;
	var area = document.getElementById("areaSoli").value;
	var uso = document.getElementById("usoSoli").value;
	var nroRef1 = document.getElementById("nroReferencia").value;
	var nroRef2 = document.getElementById("nroReferencia2").value;
	var totalCancelar = document.getElementById("total_cancelar").value;
	var nucleoSoli = document.getElementById("nucleoSoli").value;
	var btnDescargar = document.getElementById("btnDescargar");
	var pago_mer = $('input:radio[name=pMer]:checked').val();
	var nomNucSol = '';

	switch (nucleoSoli) {
		case '20': nomNucSol = 'SUCRE'; break;
		case '30': nomNucSol = 'ANZOÃTEGUI'; break;
		case '40': nomNucSol = 'MONAGAS'; break;
		case '50': nomNucSol = 'BOLÃVAR'; break;
		case '60': nomNucSol = 'NUEVA ESPARTA'; break;
		case '90': nomNucSol = 'RECTORADO (CGCE)'; break;
	}
	
	var mensaje = 'Â¿Confirma que desea generar la Planilla de Solicitud de Documentos?\nDeberÃ¡ ser entregada en el nÃºcleo de\n*** '+nomNucSol+' ***';
	
	var frm = document.getElementById("formSolicitud");
	var titulo = "";
	var tipoDoc = "";
	var cantDoc = "";

	var totalSaldo = $('#total_saldo').val();
	//var totalCancelar = $('#total_cancelar').val();
	
	var i = 15;
	while(i < frm.elements.length) {
		titulo += frm.elements[i].value + "||" ;
		i+=5;
	}
	var i = 16;
	while(i < frm.elements.length) {
		tipoDoc += frm.elements[i].value + "||" ;
		i+=5;
	}
	var i = 17;
	while(i < frm.elements.length) {
		cantDoc += frm.elements[i].value + "||" ;
		i+=5;
	}
	
	if (cedula == '') {
		swal({title: '', text: 'Debes ingresar el nÃºmero de cÃ©dula', animation: false});
		return;
	}
	else if (nucleoSoli == '-1') {
		swal({title: '', text: 'Debes seleccionar el nÃºcleo donde realizarÃ¡ su solicitud', animation: false});
		return;	
	}
	else if (telefono == '') {
		swal({title: '', text: 'Debes ingresar el nÃºmero telefÃ³nico', animation: false});
		return;	
	}
	else if (correo == '') {
		swal({title: '', text: 'Debes ingresar el correo electrÃ³nico', animation: false});
		return;	
	}
	else if (titulo == '') {
		swal({title: '', text: 'Debes agregar por lo menos un documento', animation: false});
		return;
	}
	else if (pago_mer == 'si' && (nroRef1 == '' || nroRef1 == 0)) {
		swal({title: '', text: 'Debes ingresar el nÃºmero de referencia', animation: false});
		return;	
		//SE COMENTA TEMPORALEMTE PARA NO VALIDAR EL SALDO DEL DEPOSITO DE PAGOS MERCANTIL
	/*} else if (parseFloat(totalSaldo) < parseFloat(totalCancelar) || parseFloat(totalSaldo) == 0 || totalSaldo == '' || totalSaldo == null) {
		swal({title: '', text: 'Saldo insuficiente para realizar la solicitud de documentos', animation: false});
		return;*/
	}
	else
	{
		swal({
		  title: "",
		  text: mensaje,
		  type: "warning",
		  animation: false,
		  showCancelButton: true,
		  cancelButtonText: "Cancelar",
		  confirmButtonColor: "#DD6B55",
		  confirmButtonText: "Aceptar",
		  closeOnConfirm: true
		},
		function(){
			btnDescargar.disabled = true;
			$('#load').show();
			AjaxRequest.post
			(
				{
				'parameters':
				 {
				 	"cedula": cedula,
				 	"nucleoSoli": nucleoSoli,
				 	"telefono": telefono,
				 	"correo": correo,
				 	"titulo": titulo,
				 	"tipoDoc": tipoDoc,
				 	"cantDoc": cantDoc,
				 	"area": area,
				 	"uso": uso,
				 	"pago_mer": pago_mer,
				 	"nroRef1": nroRef1,
				 	"nroRef2": nroRef2,
				 	"totalCancelar": totalCancelar,
					"operacion":'registrarSolicitud'
				 }

				,'onSuccess': function(req) {respDescargarPlanilla(req, cedula) }
				,'url':'descarga/transaccion/transDescarga.php'
				,'onError':function(req)
					{ 
						swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
					}
				}
			);
		});
	}
}

function respDescargarPlanilla(req, cedula) {
	var resp = eval ("("+ req.responseText +")");
	var area = document.getElementById("areaSoli").value;
	var uso = document.getElementById("usoSoli").value;
	var btnDescargar = document.getElementById("btnDescargar");
	var url;
	
	if (resp['response']!=false && resp['response']!=null && resp['response']!= '')
	{
		url = 'descarga/planilla_pdf.php?cedula='+cedula+'&numero='+resp['numero']+'&area='+area+'&uso='+uso;
		window.open(url, 'ventanaHija', 'toolbar=0,scrollbars=1,location=0,statusbar=1,menubar=0,resizable=1,width=250,height=150,left=150,top=180');
		window.close('ventanaHija');
		limpiarEgresadoDocu();
	} else {
		swal({title: '', text: 'Disculpe. '+resp['msgError'], animation: false});
		btnDescargar.disabled = false;
		$('#load').hide();
		return;
	}
}

function opcionOtroPago(accion) {
	var fila = document.getElementById("otro_pago");
	var totalSaldo = document.getElementById("total_saldo").value;
	var saldoRef2 = $("#saldoReferencia2").text();
	var nroRef1 = document.getElementById("nroReferencia").value;
	var totSaldo;
	
	if (nroRef1 == '' || nroRef1 == null) {
		return;
	}

	if (accion == 'mostrar') {
		fila.style = 'visibility: visible';
	} else {
		$('#nroReferencia2').val('');
		$('#fechaReferencia2').text('');
		$('#montoReferencia2').text('');
		$('#saldoReferencia2').text('');
		fila.style = 'visibility: hidden';
		if (saldoRef2!="" && saldoRef2!=null && saldoRef2!=NaN) {
			totSaldo = parseFloat(totalSaldo) - parseFloat(saldoRef2);
			$('#total_saldo').val(totSaldo);
		}
	}
}

function validarReferencia(numero, idRef) {
	var operacion = 'validarPago';
	var ref1 = $('#nroReferencia').val();
	var ref2 = $('#nroReferencia2').val();
	var fila = document.getElementById("otro_pago");

	if (idRef == '') {
		swal({title: '', text: 'Debes ingresar el nÃºmero de referencia', animation: false});
		return;
	}
	if (ref1 == ref2) {
		swal({title: '', text: 'No puedes ingresar un nÃºmero de referencia duplicado', animation: false});
		
		$('#nroReferencia').val('');
		$('#fechaReferencia').text('');
		$('#montoReferencia').text('');
		$('#saldoReferencia').text('');

		$('#nroReferencia2').val('');
		$('#fechaReferencia2').text('');
		$('#montoReferencia2').text('');
		$('#saldoReferencia2').text('');

		$('#total_saldo').val(0);

		fila.style = 'visibility: hidden';
		return;
	}

	AjaxRequest.post
	(
		{
		'parameters':
		 {
		 	"numero":numero,
			"operacion":operacion
		 }
		,'onSuccess': function(req) {respValidarReferencia(req, idRef) }
		,'url':'descarga/transaccion/transDescarga.php'
		,'onError':function(req)
			{ 
				swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
			}
		}
	);	
}

function respValidarReferencia(req, idRef) {
	var resp = eval ("("+ req.responseText +")");
	var totalSaldo = document.getElementById("total_saldo").value;
	var saldoRef2 = $("#saldoReferencia2").text();
	var fila = document.getElementById("otro_pago");
	var totSaldo;
	
	if (resp!=false && resp!=null && resp!='') {
		if (idRef == 'nroReferencia') {
			if (resp[0]["saldo"] != 0 && resp[0]["estatus"] != '0') {
				$('#fechaReferencia').text(formatoFecha(resp[0]["fecha"]));
				$('#montoReferencia').text(accounting.formatMoney(resp[0]["monto"], "", 2, ".", ","));
				$('#saldoReferencia').text(accounting.formatMoney(resp[0]["saldo"], "", 2, ".", ","));
				$('#total_saldo').val(resp[0]["saldo"]);
			} else {
				$('#nroReferencia').val('');
				$('#fechaReferencia').text('');
				$('#montoReferencia').text('');
				$('#saldoReferencia').text('');
				$('#nroReferencia2').val('');
				$('#fechaReferencia2').text('');
				$('#montoReferencia2').text('');
				$('#saldoReferencia2').text('');
				$('#total_saldo').val(0);
				fila.style = 'visibility: hidden';
				swal({title: '', text: 'El pago ingresado ya fue registrado', animation: false});
				return;	
			}
		} else if (idRef == 'nroReferencia2') {
			if (resp[0]["saldo"] != 0 && resp[0]["estatus"] != '0') {
				$('#fechaReferencia2').text(formatoFecha(resp[0]["fecha"]));
				$('#montoReferencia2').text(accounting.formatMoney(resp[0]["monto"], "", 2, ".", ","));
				$('#saldoReferencia2').text(accounting.formatMoney(resp[0]["saldo"], "", 2, ".", ","));
				totSaldo = parseFloat(totalSaldo) + parseFloat(resp[0]["saldo"]);
				$('#total_saldo').val(totSaldo);
			} else {
				swal({title: '', text: 'El pago ingresado ya fue registrado', animation: false});
				$('#nroReferencia').val('');
				$('#fechaReferencia').text('');
				$('#montoReferencia').text('');
				$('#saldoReferencia').text('');
				$('#nroReferencia2').val('');
				$('#fechaReferencia2').text('');
				$('#montoReferencia2').text('');
				$('#saldoReferencia2').text('');
				$('#total_saldo').val(0);
				fila.style = 'visibility: hidden';
				return;	
			}
		}
	} else {
		swal({title: '', text: 'Los datos del pago son invÃ¡lidos', animation: false});
		$('#nroReferencia').val('');
		$('#fechaReferencia').text('');
		$('#montoReferencia').text('');
		$('#saldoReferencia').text('');
		$('#nroReferencia2').val('');
		$('#fechaReferencia2').text('');
		$('#montoReferencia2').text('');
		$('#saldoReferencia2').text('');
		$('#total_saldo').val(0);
		fila.style = 'visibility: hidden';
		return;
	}
}

function actualizarTotalCancelar() {
	var especialidad = document.getElementById('espePla').value;
	var total_cancelar_old = document.getElementById('total_cancelar').value;
	var documento = document.getElementById('documentoPla').value;
	var cantidad = document.getElementById('cantidadPla').value;
	var espe = especialidad.split('||');
	var tipo_espe = espe[2];
	var costo = documento.split('||');
	var costo_pre = costo[3];
	var costo_post = costo[4];
	var total_cancelar_new = 0;

	if (tipo_espe == 0)
		total_cancelar_new = parseFloat(total_cancelar_old) + parseFloat(costo_pre*cantidad);
	else if (tipo_espe == 1)
		total_cancelar_new = parseFloat(total_cancelar_old) + parseFloat(costo_post*cantidad);

	$('#totalCancelar').text(accounting.formatMoney(total_cancelar_new, "", 2, ".", ","));
	$('#total_cancelar').val(total_cancelar_new);
}

function activar_pm(activar) {
	if (activar == 'si') {
		document.getElementById('nroReferencia').disabled = false;
	} else {
		$('#nroReferencia').text('');
		document.getElementById('nroReferencia').disabled = true;
	}
}