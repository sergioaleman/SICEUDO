function soloNumeros(e) {
	var code;
	if (!e) var e = window.event;
	if (e.keyCode) code = e.keyCode;// EN CASO QUE EL NAVEGADOR SEA IE
	else if (e.which) code = e.which; //EN CASO QUE EL NAVEGADOR SEA MOZILLA FIREFOX
	//alert(code);
	//var node = (e.target) ? e.target : ((e.srcElement) ? e.srcElement : null);
	//if ((e.keyCode == 13) && (node.type=="text")) {return false;}
	return (code<=13 || code==127 || (code>=48 && code<=57) || code==46 || (code>=35 && code<=39));
}

function validarEmail(valor, id) {
	if ((/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(valor)) || (valor=='')) {
		return (true)
	} else {
	swal({title: '', text: 'La direcciÃ³n de correo electrÃ³nico es incorrecta', animation: false});
	document.getElementById(id).value = '';
	return (false);
	}
}

function validarTelefono(valor, id) {
	if( (/^\d{11}$/.test(valor)) ) {
		return true;
	} else {
		swal({title: '', text: 'El nÃºmero telefÃ³nico es incorrecto', animation: false});
		document.getElementById(id).value = '';
		return (false);
	}
}

function formatoFecha(valor)
{
	//para cambiar el formato de la fecha aaaa-mm-dd por dd/mm/aaaa 
	if(valor!=null && valor!="") {
		var fechaArray= valor.split('-');
		var anio=fechaArray[0];
		var mes=fechaArray[1];
		var dia =fechaArray[2];
		var fecha=dia+'/'+mes+'/'+anio;
		return fecha;
	}
	else
		return null;
}