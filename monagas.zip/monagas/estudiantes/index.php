<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>SICEUDO Monagas - Estudiantes</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<meta name="keywords" content="siceudo"/>
<link rel="icon" type="image/x-icon" href="imagenes/logo.ico">
<link href="include/css/estilos.css" rel="stylesheet" type="text/css"/>
<link href="include/css/estilos_simplemodal.css" rel="stylesheet" type="text/css"/>
<link type="text/css" rel="stylesheet" media="all" href="include/jscalendar/calendar-blue.css" title="win2k-cold-1"/>
<script type="text/javascript" src="include/jquery/jquery.js"></script>
<script type="text/javascript" src="include/jquery/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="include/jquery/jquery-ui-1.8.5.custom.min.js"></script>
<script type="text/javascript" src="include/jscalendar/calendar.js"></script>
<script type="text/javascript" src="include/jscalendar/lang/calendar-es.js"></script>
<script type="text/javascript" src="include/jscalendar/calendar-setup.js"></script>
<script type="text/javascript" src="include/js/AjaxRequest.js"></script>
<script type="text/javascript" src="include/js/funcionesComunes.js"></script>
<script type="text/javascript" src="include/js/funciones.js?v=660969"></script>
<script type="text/javascript" src="include/js/simplemodal.js"></script>
<script type="text/javascript" src="planificacion/script/planificacion.js?v=660969"></script>
<script type="text/javascript" src="admision/script/inscripcion.js?v=660969"></script>
<script type="text/javascript" src="admision/script/scriptInscripcionIntensivos.js?v=660969"></script>
<script type="text/javascript" src="admision/script/scriptEstudiante.js?v=660969"></script>
<script type="text/javascript" src="admision/script/scriptPagosWeb.js?v=660969"></script>
<script type="text/javascript" src="admision/script/scriptInscripcionWeb.js?v=660969"></script>
<script type="text/javascript" src="reportes/script/reportes.js?v=660969"></script>
<script type="text/javascript" src="administracion/script/scriptUsuarios.js?v=660969"></script>
<script type="text/javascript" src="administracion/script/scriptEncuesta.js?v=660969"></script>
<script type="text/javascript" src="solicitudes/script/script_paralelo.js?v=660969"></script>
<script type="text/javascript" src="solicitudes/script/script_excesos.js?v=660969"></script>
<script type="text/javascript" src="solicitudes/script/script_reclamos.js?v=660969"></script>
<script type="text/javascript" src="solicitudes/script/scriptRetiroAsignatura.js?v=660969"></script>
<script type="text/javascript" src="solicitudes/script/scriptRetiroParcial.js?v=660969"></script>
<script type="text/javascript" src="solicitudes/script/scriptAyudantia.js?v=660969"></script>
<script type="text/javascript" src="consultas/script/scriptConsultaPros.js?v=660969"></script>
<script type="text/javascript" src="solicitudes/script/scriptPreinscripcionRegular.js?v=660969"></script>
<script language="Javascript">
	document.oncontextmenu = function(){return false}
</script>
<script language="javascript">
	var timer = 0;
	function set_interval() {
		timer = setInterval("auto_logout()",600000);
	}
	function reset_interval() {
		if (timer != 0) {
			clearInterval(timer);
			timer = 0;
			timer = setInterval("auto_logout()",600000);
		}
	}
	function auto_logout() {
		window.location = "logout.php";
	}
</script>
</head>
<body onload="set_interval()" onmousemove="reset_interval()" onclick="reset_interval()" onkeypress="reset_interval()" onscroll="reset_interval()">
<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr class="titulo">
		<td colspan="4" class="tBlanco">
        	<img src="imagenes/logo_nb.png" style="cursor:pointer;" onclick="javascript: location.href='index.php'" border="0" title="Haga click para ir al inicio"></td>
        <td class="tBlanco" align="left">
        <img border="0"  src="imagenes/logo.png" style="cursor: pointer"></td>
	</tr>
    <tr bgcolor="#005082" class="tBlanco" height="18px">
    	<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;.: Bienvenidos :.</td>
        <td colspan="2">Sistema Integral de Control de Estudios de la Universidad de Oriente</td>
        <td> <?php  echo "La fecha de hoy es " . date("d") . " / " . date("m") . " / " . date("Y");  ?> </td>
    </tr>
	<tr><td colspan="5"><h3></h3></td></tr>
	<tr>
		<td width="10%" valign="top" height="270"> <!-- Columna 1-->
			<h3>Menú Principal</h3>
			<div id="menuP">
	<div id="sidebar">
		<ul class="sidemenu">
			<li><a style="cursor: pointer" onclick="cambiar_cuerpo('inicio.php', 'cuerpo')">Inicio</a></li>
			<!--<li><a style="cursor: pointer" onclick="cambiar_cuerpo('web/administracion.php', 'cuerpo')">Administración</a></li>
			<li><a style="cursor: pointer" onclick="cambiar_cuerpo('web/pagina2.php', 'cuerpo')">Link 2</a></li>
			<li><a style="cursor: pointer" onclick="cambiar_cuerpo('web/pagina3.php', 'cuerpo')">Link 3</a></li>
			<li><a style="cursor: pointer" onclick="cambiar_cuerpo('web/pagina4.php', 'cuerpo')">Link 4</a></li>-->
		</ul>
	</div>
</div>			<BR>
		</td>
		<td rowspan="3" width="25px">&nbsp;&nbsp;&nbsp;</td>
		<td rowspan="3" width="750px" height="430" valign="top" id="cuerpo"> <!-- Columna 2-->




<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2139263390076630"
     crossorigin="anonymous"></script>
<!-- Adsense -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2139263390076630"
     data-ad-slot="8044386606"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

			<h3> Atención Taquilla DACE</h3>
<marquee width="100%" height="15" direction='left' behavior='scroll' onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 1, 0);" truespeed="" scrolldelay="15" scrollamount="1" loop="infinite">
<font><strong style="color: #F00">ATENCIÓN:</strong> <strong style="color: #036">INFORMACIÓN IMPORTANTE...!</strong></font>
</marquee>
<table bgcolor="#FFFF3C" style="border: 1px solid #999;" align="center" width="100%" border="0" cellpadding="2" cellspacing="5" id="tabla">
  <tr>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
    <td width="94%" align="justify" style="line-height : 20px;">Se le recuerda a la Comunidad Estudiantil que el <strong>SERVICIO DE TAQUILLA</strong>      para atender a los Estudiantes es de <strong>LUNES A VIERNES DE 8:00 AM A 
      11:45 AM Y DE 1:00 PM A 3:30 PM</strong> (sin importar el último número de 
    cédula)</td>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td> 
  </tr>
</table>
<!--<BR>
<h3>Nuevas Ayudantias</h3>
<marquee width="100%" height="15" direction='left' behavior='scroll' onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 1, 0);" truespeed="" scrolldelay="15" scrollamount="1" loop="infinite">
<font><strong style="color: #F00">ATENCIÓN:</strong> <strong style="color: #036">INFORMACIÓN IMPORTANTE...!</strong></font>
</marquee>
<table bgcolor="#FFFF3C" style="border: 1px solid #999;" align="center" width="100%" border="0" cellpadding="2" cellspacing="5" id="tabla">
  <tr>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
    <td width="94%" align="justify" style="line-height : 20px;">
	Se le informa a la Comunidad Estudiantil que ya está abierto el proceso de Asignación de Nuevas Ayudantias, <strong>hasta el 09 de Marzo de 2018</strong>. Los requisitos están publicados en la Cartelera de la Oficina de la Delegación de Desarrollo Estudiantil, 1er Piso, Decanato.	</td>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
  </tr>
</table>-->
<!--<BR>
<h3>Renovación de Ayudantias y Becas de Residencia </h3>
<marquee width="100%" height="15" direction='left' behavior='scroll' onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 1, 0);" truespeed="" scrolldelay="15" scrollamount="1" loop="infinite">
<font><strong style="color: #F00">ATENCIÓN:</strong> <strong style="color: #036">INFORMACIÓN IMPORTANTE...!</strong></font>
</marquee>
<table bgcolor="#FFFF3C" style="border: 1px solid #999;" align="center" width="100%" border="0" cellpadding="2" cellspacing="5" id="tabla">
  <tr>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
    <td width="94%" align="justify" style="line-height : 20px;">Se le notifica a la Comunidad Estudiantil que se abre el proceso de 
      recepción de renovaciones para<strong> ayudantias y Becas de Residencia</strong>. A 
      partir del dia <strong>Martes 29 de Mayo   hasta el Viernes 15 de Junio</strong>, en la 
    oficina de Desarrollo Estudiante, Edificio Decanato, Primer Piso. <strong>Consignar</strong>: Planilla de Renovacion, la cual se encuentra en su cuenta SICEUDO, Constancia de Inscripcion o Carga Academica del Semestre I-2018, Record Academico actualizado, Constancia donde va a prestar la colaboracion debidamente firmada y sellada. <strong>(A partir de Abril se estará cancelando estos beneficios por un 
monto de BsF. 400.000,00) </strong></td>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
  </tr>
</table>-->
<!--<br />
<h3>Becas de Honor Dr. Luis Manuel 
Peñalver</h3>
<marquee width="100%" height="15" direction='left' behavior='scroll' onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 1, 0);" truespeed="" scrolldelay="15" scrollamount="1" loop="infinite">
<font><strong style="color: #F00">ATENCIÓN:</strong> <strong style="color: #036">INFORMACIÓN IMPORTANTE...!</strong></font>
</marquee>
<table bgcolor="#FFFF3C" style="border: 1px solid #999;" align="center" width="100%" border="0" cellpadding="2" cellspacing="5" id="tabla">
  <tr>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
    <td width="94%" align="justify" style="line-height : 20px;">Se le informa a la Comunidad Estudiantil que se encuentra abierto 
      <strong>hasta el 30 de marzo del presente</strong> el proceso de recepción de nuevas 
      postulaciones y renovaciones para Becas de Honor Dr. Luis Manuel 
      Peñalver, para estudiantes regulares con alto rendimiento académico 
      <strong>(Promedio mayor o igual a 8 puntos)</strong> y que nunca hayan reprobado ni 
      retirado materias. Para más información dirigirse a la Delegación de 
    Bienestar Estudiantil, Edificio Decanato, Primer Piso.</td>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
  </tr>
</table>-->
<!--<BR>
<h3>Atención Aspirantes a Acto de Grado</h3>
<marquee width="100%" height="15" direction='left' behavior='scroll' onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 1, 0);" truespeed="" scrolldelay="15" scrollamount="1" loop="infinite">
<font><strong style="color: #F00">ATENCIÓN:</strong> <strong style="color: #036">INFORMACIÓN IMPORTANTE...!</strong></font>
</marquee>
<table bgcolor="#FFFF3C" style="border: 1px solid #999;" align="center" width="100%" border="0" cellpadding="2" cellspacing="5" id="tabla">
  <tr>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
    <td width="94%" align="justify" style="line-height : 20px;">La revisión y recepción de documentos para Acto de Grado se hará con 
      cita previa en el Departamento de Admisión y Control de Estudios. 
      Para obtener la cita pasar por el Departamento o solicitarla por el 
    correo: dacegrado.bolivar@udo.edu.ve (Favor enviar datos y número de teléfono)</td>
    <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
  </tr>
</table>-->
<BR>
<h3>Inscripciones de Estudiantes Regulares 1-2020</h3>

	<table bgcolor="#FFFF3C" style="border: 1px solid #999;" align="center" width="100%" border="0" cellpadding="2" cellspacing="5" id="tabla">
      <tr>
        <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
        <td width="94%" align="justify" style="line-height : 20px;">Las inscripciones de estudiantes regulares iniciaran este Martes 01 de Octubre. Para consultar tu cita debes ingresar al sistema y verificar en la opcion consultar cita</td>
        <td width="3%" align="justify" style="line-height : 20px;">&nbsp;</td>
      </tr>
    </table>
	<p align="justify" style="line-height : 20px;">Una vez iniciado el proceso de inscripción del período académico actual, el estudiante podrá inscribirse desde cualquier computador con conexión a internet, inclusive fuera del campus universitario. Para ello, primero debe conocer la fecha y hora asignada en su cita para registrar la inscripción. Si aún desconoce como inscribirse puede descargar el siguiente archivo: <a href="descargas/manuales/instructivo_inscripciones.pdf" target="_blank">Instructivo de Inscripciones</a>.</p>
<BR>
<p align="center" style="color:#06C; font-size:12px"><strong>Pasos a seguir en el proceso de inscripción</strong></p>
<BR>
<TABLE bgcolor="#FAFAFA" style="border: 1px solid #EAEAEA;" align="center" width="100%" border="0" cellpadding="2" cellspacing="2">
	<TR>
    	<TD align="center"><div class="caja1"><strong>(1)</strong><BR><BR>INICIA TU SESIÓN</div></TD>
<!--        <TD align="center"><div class="caja2"><strong>(2)</strong><BR><BR>REGISTRA TU PAGO</div></TD>-->
        <TD align="center"><div class="caja3"><strong>(2)</strong><BR><BR>REGISTRA TU INSCRIPCIÓN</div></TD>
        <TD align="center"><div class="caja2"><strong>(3)</strong><BR><BR>IMPRIME TU CONSTANCIA</div></TD>
        <TD align="center"><div class="caja5"><strong>(4)</strong><BR><BR>CIERRA TU SESIÓN</div></TD>
    </TR>
</TABLE>
<br />
<h3>Recuperar Contraseña</h3>
<table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td width="75"><img src="imagenes/informacion.png" border="0" width="55" height="55"></td>
        <td width="1245"><p align="justify" style="line-height : 20px;">Para recuperar tu contraseña es indispensable tu correo electrónico. Puedes usar la opción <strong>¿Olvidó su contraseña?</strong> en la parte baja del cuadro <strong>Iniciar Sesión. </strong>Si no tienes tu correo electrónico actualizado, te invitamos a pasar por la taquilla del Departamento de Admisión y Control de Estudios para realizar dicha actualización. Se responsable con tu información!!!  </p>
      </td>
	</tr>
</table>
<BR>
<h3>Actualización de Datos </h3>
<table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td width="75"><img src="imagenes/informacion.png" border="0" width="55" height="55"></td>
        <td width="1245"><p align="justify" style="line-height : 20px;">Queremos estar en contacto contigo! Es necesario que tengas tus datos actualizados (correo electrónico, teléfono, entre otros), para que puedas realizar solicitudes como cambio de contraseña de usuario. </p>
      </td>
	</tr>
</table>
<br>
<h3>Punto de Contacto</h3>
<p align="justify" style="line-height : 20px;">Cualquier consulta, inquietud, opinión, reclamo, o crítica constructiva, escríbenos al correo: <span style="font-size:14px; color: #D00"><strong>contacto@infoudo.com.ve</strong></span></p>
<BR><BR><BR><BR>		</td>
		<td rowspan="3" width="25px">&nbsp;&nbsp;&nbsp;</td>
		<td width="15%" valign="top" height="270"> <!-- Columna 3-->
			<h3>Calendario Académico</h3>
			<p class="text_content" align="justify" style="line-height : 20px;">
<marquee width="300" height="200" direction='up' behavior='scroll' onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 1, 0);" truespeed="" scrolldelay="50" scrollamount="1" loop="infinite">
<strong><font color="#0066CC">PUBLICACIÓN DE CITAS DE INSCRIPCIÓN</font><BR>
 <?php  echo "La fecha de hoy es " . date("d") . " / " . date("m") . " / " . date("Y");  ?> </strong><BR>
<BR>
<strong><font color="#0066CC">INSCRIPCIONES REGULARES 1-2020</font><BR>
</strong><strong>A partir del Lunes 16 de Noviembre</strong><BR>
<BR>
<BR>
<strong><font color="#0066CC">INICIO DE ACTIVIDADES ACADÉMICAS</font><BR>
No disponible (Estudiantes Regulares)
<BR>
</strong>
<BR>
<strong><font color="#0066CC">SOLICITUDES DE RETIRO DE ASIGNATURAS</font><BR>
</strong>
<strong>Retiros por la Web (No traer planilla a DACE)<BR>
No disponible<BR>
</strong>
<BR>
<strong><font color="#0066CC">SOLICITUDES DE REINGRESO</font><BR>
</strong>
<strong>No disponible<BR>
</strong>
<BR>
<strong><font color="#0066CC">SOLICITUDES DE TRASLADO DE NÚCLEO</font><BR>
</strong>
<strong>No disponible<BR>
</strong>
<BR>
<strong><font color="#0066CC">SOLICITUDES DE CAMBIO DE ESPECIALIDAD</font><BR>
</strong>
<strong>No disponible<BR>
(Según Resolución CU Nº 061/2016 No se incluye MEDICINA)<BR></strong>
<BR>
<strong><font color="#0066CC">FINALIZACIÓN DE ACTIVIDADES ACADÉMICAS</font><BR>
</strong>
<strong>No disponible<BR>
</strong>			<BR>
		</td>
		<tr>
			<td valign="top" height="210">
				<h3>Iniciar Sesión</h3>
				<div id="identificacion">
	<form name="identificacion">
		<table width="100%" border="0" cellpadding="0" cellspacing="5">
			<tr><td><strong>Nro. de Cédula</strong></td></tr>
			<tr><td><input class="loginInput" type="text" name="usuarioEst" size="30" maxlength="10" id="usuario" onkeypress="validarUsuario(event); return soloNumeros(event);"></td></tr>
			<tr><td><strong>Contraseña</strong></td></tr>
			<tr><td><input class="loginInput" type="password" name="claveEst" size="30" id="clave" onkeypress="javascript: validarUsuario(event);"></td></tr>
			<tr><TD id="error" style="color: #8A2022"></TD></tr>
			<tr><td align="center" colspan="2">
			<input type="button" class="button" onclick="javascript: validar_usuario_regulares();" name="ingresar" value="Ingresar">&nbsp;&nbsp;&nbsp;
			<input type="button" class="button" name="limpiar" value="Limpiar" onclick="limpiarLogin();">
            </td></tr>
			<tr>
			  <td align="center" colspan="2"><script type="text/javascript">
					window.onload=hora;
					fecha = new Date("25 Jul 2021 18:11:04");
					function hora(){
						var hora=fecha.getHours();
						var minutos=fecha.getMinutes();
						var segundos=fecha.getSeconds();
						if(hora<10){ hora='0'+hora;}
						if(minutos<10){minutos='0'+minutos; }
						if(segundos<10){ segundos='0'+segundos; }
						fech=hora+":"+minutos+":"+segundos;
						document.getElementById('hora').innerHTML=fech;
						fecha.setSeconds(fecha.getSeconds()+1);
						setTimeout("hora()",1000);
					}
				</script>
					<strong> Hora servidor </strong> <div style="color:#F00; font-size:12px; font-weight:bold" id="hora"></div></td>
		  </tr>
		</table>
	</form>
    <BR>
	<div align="center"><a onClick="enviarClave()" style="cursor:pointer">¿Olvidó su contraseña?</a></div>
</div>			</td>
			<td valign="top" style="line-height: 20px;">
				<h3>Descargas</h3>
				<DIV id="descargas">
&raquo;&nbsp;<a href="#" target="_blank" style="cursor: pointer;">Instructivo Nuevo Ingreso I-2019</a> <BR>
&raquo;&nbsp;<a href="https://drive.google.com/file/d/0B1TSqy3rC2IkdGZGUUQ0Ym1qekdVS1RwdDNTZS1yank5VVZn/view?usp=sharing" target="_blank" style="cursor: pointer;">Horario Nuevo Ingreso I-2019</a> <BR>
&raquo;&nbsp;<a onclick="cambiar_cuerpo('descargas/horarios.php', 'descargas')" style="cursor: pointer;">Horarios de Clases I- 2019</a><BR>
&raquo;&nbsp;<a onclick="cambiar_cuerpo('descargas/pensum.php', 'descargas')" style="cursor: pointer;">Pensum de Estudios</a><BR>
&raquo;&nbsp;<a onclick="cambiar_cuerpo('descargas/formatos.php', 'descargas')" style="cursor: pointer;">Formatos de Solicitudes</a><BR>
&raquo;&nbsp;<a onclick="cambiar_cuerpo('descargas/gacetas.php', 'descargas')" style="cursor: pointer;">Gacetas</a><BR>
<!--&raquo;&nbsp;<a href="https://drive.google.com/file/d/0B7B3X0luJx7RVWxnMVNXM2sxQVU/view?usp=sharing" target="_blank" style="cursor: pointer;">Reingresos 2-2016</a> <BR>-->
&raquo;&nbsp;<a href="https://drive.google.com/file/d/0B7B3X0luJx7RREEtY0JWdFdDMlh6aFE2LWtyR3dPQmdBa3ZN/view?usp=sharing" target="_blank" style="cursor: pointer;">Planilla Nuevas ayudantias/becas</a> <BR>
&raquo;&nbsp;<A href="https://drive.google.com/file/d/0B7B3X0luJx7RMDhwZ0ZlX1RBT0ZWaHdneWR1YzJycGRYRV9F/view?usp=sharing" target="_blank">Renuncia Cupo OPSU (Nuevo Ingreso)</A><BR />
<br />



<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2139263390076630"
     crossorigin="anonymous"></script>
<!-- Adsense -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2139263390076630"
     data-ad-slot="8044386606"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>


<BR>
Para un mejor funcionamiento Descarga
<br>
<a href="https://download.mozilla.org/?product=firefox-stub&os=win&lang=es-ES" target="_blank"><img src="imagenes/mozillaWeb.jpg" border="0" style="cursor:pointer"/></a>
</DIV>				<BR>
			</td>
		</tr>
		<tr>
			<td></td>
			<td valign="top" style="line-height: 20px;">
				<h3>Enlaces de Interés</h3>
				&raquo;&nbsp;<a href="http://aulavirtual.bolivar.udo.edu.ve/" target="_blank">Aula Virtual Bolívar</a><BR>
&raquo;&nbsp;<a href="http://www.udo.edu.ve" target="_blank">Universidad de Oriente (UDO)</a><BR>
&raquo;&nbsp;<a href="http://www.mppeuct.gob.ve/" target="_blank">Ministerio de Educación Superior (MES)</a><BR>
&raquo;&nbsp;<a href="http://www.opsu.gob.ve" target="_blank">Oficina de Planif. del Sector Universitario (OPSU)</a><BR>
<br><br><br><br>				<BR>
			</td>
		</tr>
	<tr><td colspan="5" height="2px" bgcolor="#666666"></td></tr>
	<tr valign="bottom">
		<td colspan="5" bgcolor="#005082" class="tBlanco">
			<div id="footer">
				<p>&copy;<?php echo date ("Y"); ?> | Universidad de Oriente :: Venezuela<br>
				Rectorado :: Coordinación General de Control de Estudios
				</p>
			</div>
		</td>
	</tr>
</table>
</body>
</html>