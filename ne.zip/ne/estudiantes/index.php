<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>SICEUDO Nueva Esparta - Estudiantes</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<meta name="keywords" content="siceudo"/>
<link rel="icon" type="image/x-icon" href="imagenes/logo.ico">
<link href="include/css/estilos.css" rel="stylesheet" type="text/css"/>
<link href="include/css/estilos_simplemodal.css" rel="stylesheet" type="text/css"/>
<link type="text/css" rel="stylesheet" media="all" href="include/jscalendar/calendar-blue.css" title="win2k-cold-1"/>
<script type="text/javascript" src="include/jquery/jquery.js"></script>
<script type="text/javascript" src="include/jquery/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="include/jquery/jquery-ui-1.8.5.custom.min.js"></script>
<script type="text/javascript" src="include/jscalendar/calendar.js"></script>
<script type="text/javascript" src="include/jscalendar/lang/calendar-es.js"></script>
<script type="text/javascript" src="include/jscalendar/calendar-setup.js"></script>
<script type="text/javascript" src="include/js/AjaxRequest.js"></script>
<script type="text/javascript" src="include/js/funciones.js?v=58148"></script>
<script type="text/javascript" src="include/js/simplemodal.js"></script>
<script type="text/javascript" src="planificacion/script/planificacion.js"></script>
<script type="text/javascript" src="admision/script/inscripcion.js?v=58148"></script>
<script type="text/javascript" src="admision/script/scriptEstudiante.js?v=58148"></script>
<script type="text/javascript" src="admision/script/scriptPagosWeb.js?v=58148"></script>
<script type="text/javascript" src="admision/script/script_inscripcion_web.js?v=58148"></script>
<script type="text/javascript" src="admision/script/scriptInscripcionIntensivos.js"></script>
<script type="text/javascript" src="admision/script/areas.js"></script>
<script type="text/javascript" src="admision/script/sc.js"></script>
<script type="text/javascript" src="reportes/script/reportes.js?v=58148"></script>
<script type="text/javascript" src="administracion/script/usuarios.js?v=58148"></script>  
<script type="text/javascript" src="administracion/script/scriptEncuesta.js"></script>
<script type="text/javascript" src="solicitudes/script/script_paralelo.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/script_excesos.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/script_equivalencias.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/script_transferencia.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/scriptDirigidos.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/script_apelacion.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/script_retiro.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/script_cambio_esp.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/scriptReing.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/scriptTraslado.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/script_carrera_simult.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/script_anula_solicitud.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/script_solicitud_inscripcion.js?v=58148"></script>
<script type="text/javascript" src="solicitudes/script/scriptPlanillaGrado.js?v=58148"></script>
<script type="text/javascript" src="caja/script/script_caja.js?v=58148"></script>
<script type="text/javascript" src="consultas/script/scriptConsultaPros.js?v=58148"></script>
<script type="text/javascript" src="admision/script/demanda.js?v=58148"></script>
<script type="text/javascript" src="carnet/script/scriptCarnet.js?v=58148"></script>


<script language="javascript" > 
<!-- 
 var Tserver="17:33"; 
 var Tssec="36";
 // --End Hiding Here --> 
</script>
<script type="text/javascript" src="cita/tiempo.js"></script>
<script language="Javascript">
	document.oncontextmenu = function(){return false}
</script>
<script language="javascript">
	var timer = 0;
	function set_interval() {
		timer = setInterval("auto_logout()",600000);
	}
	function reset_interval() {
		if (timer != 0) {
			clearInterval(timer);
			timer = 0;
			timer = setInterval("auto_logout()",600000);
		}
	}
	function auto_logout() {
		window.location = "logout.php";
	}
</script>
</head>
<body onload="set_interval()" onmousemove="reset_interval()" onclick="reset_interval()" onkeypress="reset_interval()" onscroll="reset_interval()">
<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr class="titulo">
		<td colspan="4" class="tBlanco">
        	<img src="imagenes/logo_ne.png" style="cursor:pointer;" onclick="javascript: location.reload()" border="0" title="Haga click para ir al inicio">
            </td>
        <td class="tBlanco" align="left">
        <img border="0"  src="imagenes/logo.png" style="cursor: pointer"></td>
	</tr>
    <tr bgcolor="#005082" class="tBlanco" height="18px">
    	<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;.: Bienvenidos :.</td>
        <td colspan="2">Sistema Integral de Control de Estudios de la Universidad de Oriente</td>
        <td> <?php  echo "La fecha de hoy es " . date("d") . " / " . date("m") . " / " . date("Y");  ?></td>
    </tr>
	<tr><td colspan="5"><h3></h3></td></tr>
	<tr>
		<td width="10%" valign="top" height="270"> <!-- Columna 1-->
			<h3>Menú Principal</h3>
			<div id="menuP">
	<div id="sidebar">
		<ul class="sidemenu">
			<li><a style="cursor: pointer" onclick="cambiar_cuerpo('inicio.php', 'cuerpo')">Inicio</a></li>
			<!--<li><a style="cursor: pointer" onclick="cambiar_cuerpo('web/administracion.php', 'cuerpo')">Administración</a></li>
			<li><a style="cursor: pointer" onclick="cambiar_cuerpo('web/pagina2.php', 'cuerpo')">Link 2</a></li>
			<li><a style="cursor: pointer" onclick="cambiar_cuerpo('web/pagina3.php', 'cuerpo')">Link 3</a></li>
			<li><a style="cursor: pointer" onclick="cambiar_cuerpo('web/pagina4.php', 'cuerpo')">Link 4</a></li>-->
		</ul>
	</div>
</div>			<BR>
		</td>
		<td rowspan="3" width="25px">&nbsp;&nbsp;&nbsp;</td>
		<td rowspan="3" width="750px" height="430" valign="top" id="cuerpo"> <!-- Columna 2-->



<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2139263390076630"
     crossorigin="anonymous"></script>
<!-- Adsense -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2139263390076630"
     data-ad-slot="8044386606"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

			<!--<h3>Inscripción de Seminario del Servicio Comunitario</h3>
<marquee width="100%" height="15" direction='left' behavior='scroll' onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 1, 0);" truespeed="" scrolldelay="15" scrollamount="1" loop="infinite">
<font><strong style="color: #F00">ATENCIÓN:</strong> <strong style="color: #036">INFORMACIÓN IMPORTANTE...!</strong></font>
</marquee>
<p align="justify" style="line-height : 20px;">Se le notifica a la Comunidad Estudiantil que se abrirá el proceso de inscripción Web del <strong>Seminario de Servicio Comunitario</strong>, a partir del dia Lunes 17 de Junio.</p>
<BR>
-->
<h3>Inscripción de Estudiantes Regulares</h3>
	<p align="justify" style="line-height : 20px;">Una vez iniciado el proceso de inscripción del período académico actual, el estudiante podrá inscribirse desde cualquier computador con conexión a internet, inclusive fuera del campus universitario. Para ello, primero debe conocer la fecha y hora asignada en su cita para registrar la inscripción. Si aún desconoce como inscribirse puede descargar el siguiente archivo: <a href="descargas/manuales/inscripcion_regulares.pdf" target="_blank">Instructivo de Inscripciones</a>.</p>
<BR>
<p align="center" style="color:#06C; font-size:12px"><strong>Pasos a seguir en el proceso de inscripción</strong></p>
<BR>
<TABLE bgcolor="#FAFAFA" style="border: 1px solid #EAEAEA;" align="center" width="100%" border="0" cellpadding="2" cellspacing="2">
	<TR>
    	<TD align="center"><div class="caja1"><strong>(1)</strong><BR><BR>INICIA TU SESIÓN</div></TD>
<!--        <TD align="center"><div class="caja2"><strong>(2)</strong><BR><BR>REGISTRA TU PAGO</div></TD>-->
        <TD align="center"><div class="caja3"><strong>(2)</strong><BR><BR>REGISTRA TU INSCRIPCIÓN</div></TD>
        <TD align="center"><div class="caja2"><strong>(3)</strong><BR><BR>IMPRIME TU CONSTANCIA</div></TD>
        <TD align="center"><div class="caja5"><strong>(4)</strong><BR><BR>CIERRA TU SESIÓN</div></TD>
    </TR>
</TABLE>
<BR>
<h3>Información Importante</h3>
<table bgcolor="#FFFFCC" style="border: 1px solid #999;" align="center" width="100%" border="0" cellpadding="2" cellspacing="5">
  <tr>
    <td height="26" align="center"><p align="center" style="line-height : 20px;"> <span><strong>Desde el día Mi&eacute;rcoles 09 de Octubre estar&aacute; disponible nuevamente el proceso de inscripción del semestre 3-2019</strong></p></td>
  </tr>
  <tr>
    <td height="20px" align="center" bgcolor="#FFDDDD"><p align="center">Usted podrá ingresar al  sistema a partir de la fecha/hora asignada para su cita. <br/>
        <strong>Si usted trata de ingresar al sistema antes de la hora que no le corresponde, será bloqueado hasta las 6pm</strong></p>
    </td>
  </tr>
  
</table>
<TABLE bgcolor="#FFFFCC" style="border: 1px solid #999;" align="center" width="100%" border="0" cellpadding="2" cellspacing="5">    
  	<TR>
    	<TD align="center"> <!--<table width="30%" border="0">
    <tr align="center">
      <th colspan="2"><span class="Estilo1">HORA OFICIAL DEL SERVIDOR PARA INSCRIPCIÓN:</span></th>
    </tr>
    <tr>
      <td align="right"><span class="Estilo1">Fecha:&nbsp;</span></td>
      <td align="left"><span class="Estilo1">25/07/21</span></td>
    </tr>
    <tr>
      <td align="right"><span class="Estilo1">Hora:&nbsp;</span></td>
      <td align="left"><div class="Estilo1" id="HoraServer">&nbsp;Tiempo</div></td>
    </tr>
  </table>-->
    </TD>
  </TR>
</TABLE>
<script language="javascript">    
  Up();
  Display_Titilar();
</script>
<!--TABLE bgcolor="#FFFFCC" style="border: 1px solid #999;" align="center" width="100%" border="0" cellpadding="2" cellspacing="5">
	<TR>
    	<TD align="center"><p align="justify" style="line-height : 20px;">
<span><strong>Si intentas ingresar al sistema antes de la hora de tu cita, serás bloqueado, y no podrás inscribirte hasta que se cumpla la última cita del día (8:00pm), quedando sujeto a la disponibilidad de cupos de esa hora. Si estas conforme con tu inscripción previa, puedes omitir el llamado a este proceso.</strong></span></p></TD>
    </TR>
	<TR>
    	<TD align="center" height="20px"></TD>
    </TR>    
  	<TR>
    	<TD align="center"><strong><span style="font-size:12px">Consulte su cita de inscrpición <a href="http://estudiantes.anz.udo.edu.ve/cita/" target="_blank">AQUÍ</a></span></strong></TD>
    </TR>    
</TABLE-->
<!--1. El proceso de inscripción complementaria le permitirá <strong>AGREGAR NUEVAS ASIGNATURAS </strong>a su carga académica, dando prioridad a aquellos estudiantes con menor número de créditos inscritos.<br />
2. Si esta conforme con su inscripción, no debe acudir al proceso de inscripción complementaria</p>
-->
<BR>
<BR>
<h3>Punto de Contacto</h3>
<p align="justify" style="line-height : 20px;">Cualquier consulta, inquietud, opinión, reclamo, o crítica constructiva, escríbenos al correo: <span style="font-size:14px; color: #D00"><strong>control.estudios@ne.udo.edu.ve</strong></span></p>
<BR><BR><BR><BR>		</td>
		<td rowspan="3" width="25px">&nbsp;&nbsp;&nbsp;</td>
		<td width="15%" valign="top" height="270"> <!-- Columna 3-->
			<h3>Calendario Académico</h3>
			<p class="text_content" align="justify" style="line-height : 20px;">
<marquee width="300" height="200" direction='up' behavior='scroll' onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 1, 0);" truespeed="" scrolldelay="50" scrollamount="1" loop="infinite">
<strong><font color="#0066CC">PUBLICACIÓN CITAS DE INSCRIPCIÓN</font><BR>
Martes 17 de Octubre <BR>
(ESTUDIANTES REGULARES)</strong>
<BR><BR>
<strong><font color="#0066CC">INSCRIPCIONES 3-2019</font><BR>
A partir del Jueves 19 de Noviembre (ESTUDIANTES REGULARES)</strong>
<BR>
<BR>
<strong><font color="#0066CC">INSCRIPCIÓN Y AJUSTE EN LISTA DE ESPERA</font><BR> 
A partir del Lunes 23 de Noviembre </strong><BR>
<BR>
<strong><font color="#0066CC">INICIO DE ACTIVIDADES ACADÉMICAS</font><BR>
23 de Noviembre (REGULARES)</strong>
<BR>
<BR>
<strong><font color="#0066CC">INSCRIPCIÓN DE TRABAJO DE GRADO</font><BR>
Por ajustar</strong>
<BR>
<BR>
<strong><font color="#0066CC">RETIRO DE ASIGNATURAS</font><BR>
Por ajustar</strong><BR>
<BR>
<strong><font color="#0066CC">SOLICITUDES DE EQUIVALENCIAS INTERNAS</font><BR>
Por ajustar</strong>
<BR>
<BR>
<strong><font color="#0066CC">SOLICITUDES DE REINGRESO</font><BR>
</strong>
<strong>Por ajustar</strong> <BR>
<BR>
<strong><font color="#0066CC">SOLICITUDES DE CARRERAS SIMULTÁNEAS</font><BR>
Por ajustar</strong> <strong></strong><BR><BR>
<strong><font color="#0066CC">SOLICITUDES DE TRANSFERENCIAS DE CRÉDITOS</font><BR>
Por ajustar</strong> <strong></strong><BR><BR>
<strong><font color="#0066CC">SOLICITUDES DE CURSOS PARALELOS Y CARGA DE EXCEPCIÓN</font><BR>
Por ajustar</strong> <strong></strong><BR><BR>
<strong><font color="#0066CC">SOLICITUDES DE CURSO DIRIDOS</font><BR>
Por ajustar</strong> <strong></strong><strong></strong>
<BR><BR>
<strong><font color="#0066CC">SOLICITUDES DE TRASLADO</font><BR>
Por ajustar</strong> <strong></strong><strong></strong>
<BR><BR>
<strong><font color="#0066CC">SOLICITUDES DE CAMBIO DE ESPECIALIDAD</font><BR>
Por ajustar</strong>
<BR><BR>
<strong><font color="#0066CC">FINALIZACIÓN DE ACTIVIDADES DOCENTES</font><BR>
Por ajustar</strong>
<BR><BR>
<strong><font color="#0066CC">PROCESAMIENTO DE ACTA DE NOTAS (3-2019)</font><BR>
Por ajustar</strong>
</marquee>
</p>
			<BR>
		</td>
		<tr>
			<td valign="top" height="210">
				<h3>Iniciar Sesión</h3>
								<div id="identificacion">
	<form name="identificacion">
		<table width="100%" border="0" cellpadding="0" cellspacing="5">
			<tr><td><strong>Nro. de Cédula</strong></td></tr>
			<tr><td><input class="loginInput" type="text" name="usuarioEst" size="30" maxlength="8" id="usuario" onkeypress="validarUsuario(event); return soloNumeros(event);"></td></tr>
			<tr><td><strong>Contraseña</strong></td></tr>
			<tr><td><input class="loginInput" type="password" name="claveEst" size="30" id="clave" onkeypress="javascript: validarUsuario(event);"></td></tr>
			<tr><TD id="error" style="color: #8A2022"></TD></tr>
			<tr><td align="center" colspan="2">
			<input type="button" class="button" onclick="javascript: validar_usuario_regulares();" name="ingresar" value="Ingresar">&nbsp;&nbsp;&nbsp;
			<input type="button" class="button" name="limpiar" value="Limpiar" onclick="limpiarLogin();">
            </td></tr>
			<tr>
			  <td align="center" colspan="2">
			  <script type="text/javascript">
					window.onload=hora;
					fecha = new Date("25 Jul 2021 17:34:36");
					function hora(){
						var hora=fecha.getHours();
						var minutos=fecha.getMinutes();
						var segundos=fecha.getSeconds();
						if(hora<10){ hora='0'+hora;}
						if(minutos<10){minutos='0'+minutos; }
						if(segundos<10){ segundos='0'+segundos; }
						fech=hora+":"+minutos+":"+segundos;
						document.getElementById('hora').innerHTML=fech;
						fecha.setSeconds(fecha.getSeconds()+1);
						setTimeout("hora()",1000);
					}
				</script>
					<strong> Hora servidor </strong> <div style="color:#F00; font-size:12px; font-weight:bold" id="hora"></div>
			  </td>
		  </tr>
		</table>
	</form>
    <BR>
	<div align="center"><a onClick="enviarClave()" style="cursor:pointer">¿Olvidó su contraseña?</a></div>
</div>			</td>
			<td valign="top" style="line-height: 20px;">
				<h3>Descargas</h3>
				<style type="text/css">
<!--
.Estilo2 {color: #FF0000; font-weight: bold; }
-->
</style>
<DIV id="descargas">
<!--&raquo;&nbsp;<A href="https://drive.google.com/file/d/1cpGa4jicY-Rq1sUlQJC0W8MYI1ZBeBgN/view?usp=sharing" target="_blank" class="Estilo2">Horarios Nuevo Ingreso III-2018</A><BR>-->
<!--&raquo;&nbsp;<A href="https://drive.google.com/file/d/0B7B3X0luJx7RUlVPVlZJbU5tb200c0RKZXFHRVFfdWktVWZr/view?usp=sharing" target="_blank" class="Estilo2">Instructivo Nuevo Ingreso III-2018</A><BR>-->
&raquo;&nbsp;<a onclick="cambiar_cuerpo('descargas/horarios.php', 'descargas')" style="cursor: pointer;">Horarios de Clases</a><BR>
&raquo;&nbsp;<a onclick="cambiar_cuerpo('descargas/pensum.php', 'descargas')" style="cursor: pointer;">Pensum de Estudios</a><BR>
&raquo;&nbsp;<a onclick="cambiar_cuerpo('descargas/gacetas.php', 'descargas')" style="cursor: pointer;">Gacetas</a><BR>
&raquo;&nbsp;<a href="https://drive.google.com/file/d/0B7B3X0luJx7RLWJZcmpDUmFJNWs/view?usp=sharing"  target="_blank" style="cursor: pointer;">Planilla Beca Pe&ntilde;alver</a><BR>
&raquo;&nbsp;<A href="https://drive.google.com/file/d/0B7B3X0luJx7RMDhwZ0ZlX1RBT0ZWaHdneWR1YzJycGRYRV9F/view?usp=sharing" target="_blank">Renuncia Cupo OPSU (Nuevo Ingreso)</A><BR/>



<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2139263390076630"
     crossorigin="anonymous"></script>
<!-- Adsense -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2139263390076630"
     data-ad-slot="8044386606"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>


<BR>
Para un mejor funcionamiento Descarga
<a href="https://download.mozilla.org/?product=firefox-stub&os=win&lang=es-ES" target="_blank"><img src="imagenes/mozillaWeb.jpg" border="0" style="cursor:pointer"/></a></DIV>
				<BR>
			</td>
		</tr>
		<tr>
			<td></td>
			<td valign="top" style="line-height: 20px;">
				<h3>Enlaces de Interés</h3>
				&raquo;&nbsp;<a href="http://www.udo.edu.ve" target="_blank">Universidad de Oriente (UDO)</a><BR>
&raquo;&nbsp;<a href="http://www.mppeuct.gob.ve/" target="_blank">Ministerio de Educación Superior (MES)</a><BR>
&raquo;&nbsp;<a href="http://www.opsu.gob.ve" target="_blank">Oficina de Planif. del Sector Universitario (OPSU)</a><BR>
<br><br><br><br>				<BR>
			</td>
		</tr>
	<tr><td colspan="5" height="2px" bgcolor="#666666"></td></tr>
	<tr valign="bottom">
		<td colspan="5" bgcolor="#005082" class="tBlanco">
			<div id="footer">
				<p>&copy;2021 | Universidad de Oriente :: Venezuela<br>
				Rectorado :: Coordinación General de Control de Estudios
				</p>
			</div>
		</td>
	</tr>
</table>
</body>
</html>