function abrirAjax() {
    var xmlhttp = false;
    try {
        xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
        try {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        } catch (E) {
            if (!xmlhttp && typeof XMLHttpRequest != 'undefined') xmlhttp = new XMLHttpRequest();
        }
    }
    return xmlhttp;
}

function cambiar_cuerpo(ruta, id, operacion) {
    var contenido = document.getElementById(id);
    var contenido_modulos = abrirAjax();
    contenido_modulos.open("POST", ruta, true);
    contenido_modulos.onreadystatechange = function() {
        if (contenido_modulos.readyState == 1) {
            contenido.innerHTML = "";
            contenido.innerHTML = "<DIV align=\"center\"><IMG src=\"imagenes/cargando.gif\" align=\"center\" border=\"0\"><BR><p>Cargando</p></DIV>";
        }
        if (contenido_modulos.readyState == 4) {
            contenido.innerHTML = "";
            contenido.innerHTML = contenido_modulos.responseText;
        }
    }
    contenido_modulos.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    contenido_modulos.send("operacion=" + operacion);

}

// VALIDAR LOGUEO DE USUARIOS
function validar_usuario_regulares() {
    var usuario = document.getElementById('usuario');
    var clave = document.getElementById('clave');
    var mensaje = document.getElementById('error');

    if (usuario.value == '') {
        mensaje.innerHTML = 'Debe introducir un usuario';
        usuario.focus();
        return;
    } else if (clave.value == '') {
        mensaje.innerHTML = 'Debe introducir una contraseÃ±a';
        clave.focus();
        return;
    }

    AjaxRequest.post({
        'parameters': {
            'usuario': usuario.value,
            'clave': clave.value,
            'accion': 'validarUsuario'
        },
        'onSuccess': respValidarUsuario,
        'url': 'administracion/transConsultas.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respValidarUsuario(req) {
    var usuario = document.getElementById('usuario');
    var clave = document.getElementById('clave');
    var mensaje = document.getElementById('error');

    var resp = eval("(" + req.responseText + ")");
    if (resp == false) {
        mensaje.innerHTML = 'El usuario o contraseÃ±a son incorrectos. Intente de nuevo';
        clave.value = '';
        usuario.focus();
    } else if (resp == true) {
        //validarCitaInscrip(usuario.value);
        cambiar_cuerpo('menuEst.php', 'menuP');
        cambiar_cuerpo('loginEst.php', 'identificacion');
        cambiar_cuerpo('inicio.php', 'cuerpo');
    }
}

function validarCitaInscrip(usuario) {
    AjaxRequest.post({
        'parameters': {
            'usuario': usuario,
            'accion': 'validarCita'
        },
        'onSuccess': respValidarCitaInscrip,
        'url': 'administracion/transConsultas.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respValidarCitaInscrip(req) {
    var usuario = document.getElementById('usuario');
    var clave = document.getElementById('clave');

    var resp = eval("(" + req.responseText + ")");

    if (resp[0] == 0) {
        var fecha = resp[1];
        var hora = resp[2];
        if (fecha != null) {
            if (hora == '20:00:00')
                alert("Usted fue Bloqueado por intentar ingresar repetidamente antes de la hora de su cita \n\n USTED PUEDE INGRESAR A PARTIR DEL DÃA " + fecha + " A LAS " + hora + "\n EN EL GRUPO DE LOS REZAGADOS");
            else
                alert("La fecha/hora asignada para su ingreso no corresponde con la fecha/hora actual\n\nUSTED PUEDE INGRESAR A PARTIR DEL DÃA " + fecha + " A LAS " + hora + "\nRECUERDE QUE AL PRÃ“MIXO INTENTO ANTES DE LA FECHA INDICADA SERÃ BLOQUEADO,\nY PRODRÃ INGRESAR AL FINALIZAR LA JORNADA EN EL GRUPO DE LOS REZAGADOS");
        } else if (fecha == null)
            alert("El estudiante no puede ingresar al proceso de inscripciÃ³n en curso. Debe esperar el horario asignado para su ingreso");
        usuario.value = '';
        clave.value = '';
        usuario.focus();
        return;
    } else if (resp[0] == 1) {
        //openMyModal('admision/info.php');
        cambiar_cuerpo('menuEst.php', 'menuP');
        cambiar_cuerpo('loginEst.php', 'identificacion');
        cambiar_cuerpo('inicio.php', 'cuerpo');
    }
}

function enviarImpresora(nombre) {
    var ficha = document.getElementById(nombre);
    var ventimp = window.open(' ', 'popimpr', 'width=10, height=10, TOOLBAR=NO, LOCATION=NO, MENUBAR=NO, SCROLLBARS=NO, RESIZABLE=NO');
    var estilo = "<link href=\"../../include/css/estilos.css\" rel=\"stylesheet\" type=\"text/css\">";
    ventimp.document.write(estilo);
    ventimp.document.write(ficha.innerHTML);
    ventimp.document.close();
    ventimp.print();
    ventimp.close();
}

function emitirPDF(ruta) {
    window.open(ruta, 'PDF');
}

function soloFecha(fecha, id) {
    var fec = document.getElementById(id);
    if (fecha != undefined && fec.value != "") {
        if (!/^\d{2}\/\d{2}\/\d{4}$/.test(fec.value)) {
            //alert(fecha);
            alert("El formato de la fecha no es vÃ¡lido (dd/mm/aaaa)");
            fec.value = '';
            fec.focus();
            return false;
        }
        var dia = parseInt(fec.value.substring(0, 2), 10);
        var mes = parseInt(fec.value.substring(3, 5), 10);
        var anio = parseInt(fec.value.substring(6), 10);
        switch (mes) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                numDias = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                numDias = 30;
                break;
            case 2:
                if (comprobarSiBisisesto(anio)) { numDias = 29 } else { numDias = 28 };
                break;
            default:
                alert("La fecha introducida es errÃ³nea");
                fec.value = '';
                fec.focus();
                return false;
        }
        if (dia > numDias || dia == 0) {
            alert("La fecha introducida es errÃ³nea");
            fec.value = '';
            fec.focus();
            return false;
        }
        return true;
    }
}

function comprobarSiBisisesto(anio) {
    if ((anio % 100 != 0) && ((anio % 4 == 0) || (anio % 400 == 0))) {
        return true;
    } else {
        return false;
    }
}

function soloNumeros(e) {
    var code;
    if (!e) var e = window.event;
    if (e.keyCode) code = e.keyCode; // EN CASO QUE EL NAVEGADOR SEA IE
    else if (e.which) code = e.which; //EN CASO QUE EL NAVEGADOR SEA MOZILLA FIREFOX
    //alert(code);
    return (code <= 13 || code == 127 || (code >= 46 && code <= 57) || (code >= 35 && code <= 40));
}

function numeroDecimal(evt) {
    var nav4 = window.Event ? true : false;
    var key = nav4 ? evt.which : evt.keyCode;
    return (key <= 13 || key == 127 || (key >= 48 && key <= 57) || (key == 46) || (key == 44));
}

function soloCodigo(e) {
    var code;
    if (!e) var e = window.event;
    if (e.keyCode) code = e.keyCode; // EN CASO QUE EL NAVEGADOR SEA IE
    else if (e.which) code = e.which; //EN CASO QUE EL NAVEGADOR SEA MOZILLA FIREFOX
    //alert(code);
    return (code <= 13 || code == 127 || (code >= 46 && code <= 57) || (code == 45) || (code >= 35 && code <= 40));
}

function validarEmail(valor, id) {
    if ((/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(valor)) || (valor == '')) {
        return (true)
    } else {
        alert("La direcciÃ³n de email es incorrecta.");
        document.getElementById(id).value = '';
        return (false);
    }
}

function soloMayuscula(cadena, id) // FUNCION ENCARGADA DE COLOCAR LAS LETRAS PRESIONADAS EN MAYUSCULAS
{
    //alert(id);
    var txt = document.getElementById(id).value.toUpperCase(cadena);
    document.getElementById(id).value = txt;
}

window.onload = function() {
    document.onkeydown = validarUsuario;
    if (document.all) document.capatureEvents(Event.KEYDOWN);
}

function validarUsuario(e) {
    var tecla = 0;
    tecla = e ? e.keyCode : event.keyCode;
    if (tecla == 13) {
        validar_usuario_regulares();
    }
}

function popup(url, w, h) {
    ventanaHija = window.open(url, 'ventanaHija', 'toolbar=0,scrollbars=1,location=0,statusbar=1,menubar=0,resizable=1,width=' + w + ',height=' + h + ',left = 120,top = 180');

}