<table width="100%" border="1" align="center" cellpadding="1" cellspacing="1" bordercolor="#666666" class="tText10" id="tabla">
  <tr id="fila">
    <td bgcolor="#FFFF99"><strong>Error 404!</strong></td>
  </tr>
  <tr id="fila">
    <td align="center" id="columna"><p><strong>DISCULPE!</strong> En este momento no se encuentra disponible el servicio, int&eacute;ntelo m&aacute;s tarde </p>
        <p>Para mayor informaci&oacute;n, comun&iacute;quese con el Departamento de Admisi&oacute;n y Control de Estudios a trav&eacute;s del correo <strong>siceudo@udo.edu.ve </strong></p></td>
  </tr>
</table>