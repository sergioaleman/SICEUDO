<style type="text/css">
<!--
.Estilo1 {color: #FF0000; font-size:9px;}
-->
</style>
<div align="center" class="featured">
	<h4 align="left"><strong>Si eres administrador puedes iniciar sesión en el siguiente formulario</strong></h4>
</div>
<fieldset>
<legend><strong>Datos del usuario</strong></legend>
<table width="100%" border="0" style="color:#333">
	<tr><td colspan="2" height="20"></td></tr>
	<tr>
		<td width="180" align="right"><strong><span class="Estilo1">*</span></strong>Nombre de Usuario</td>
		<td align="left"><input type="text" id="txt_usuario" size="20" maxlength="20" onkeypress="javascript: buscarInfoEnter(event, 'buscarUsuario');"></td>
	</tr>
    <tr><td colspan="2" height="5"></td></tr>
    <tr>
		<td align="right"><strong><span class="Estilo1">*</span></strong>Contraseña</td>
		<td align="left"><input type="password" id="txt_clave" size="20" maxlength="20" onkeypress="javascript: buscarInfoEnter(event, 'buscarUsuario');"></td>
	</tr>
    <tr><td colspan="2" align="center" id="mensaje" style="visibility: hidden; height: 30px; color: #A90000;"></td></tr>
</table>
<BR>
<TABLE align="left" width="100%" border="0" cellpadding="5" cellspacing="5">
	<TR>
		<TD width="50%" align="right"><input name="button" type="button" class="boton" onclick="loguear_usuario();" value="Aceptar" /></TD>
	    <TD width="50%" align="left"><input name="button" type="button" class="boton" onclick="limpiar_login();" value="Limpiar" /></TD>
	</TR>
</TABLE>
</fieldset>