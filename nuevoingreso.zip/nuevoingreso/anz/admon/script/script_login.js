function abrirAjax()
{
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function limpiar_login() {
	var usuario = document.getElementById("txt_usuario");
	var clave = document.getElementById("txt_clave");
	var mensaje = document.getElementById("mensaje");
	
	usuario.value = '';
	clave.value = '';
	mensaje.innerHTML = '';
	usuario.focus();
}

function buscarInfoEnter(e, operacion)
{
	var code;
	if (!e) var e = window.event;
	if (e.keyCode) code = e.keyCode;// EN CASO QUE EL NAVEGADOR SEA IE
	else if (e.which) code = e.which; //EN CASO QUE EL NAVEGADOR SEA MOZILLA FIREFOX
	if (code == 13) {
		if(operacion=='buscarUsuario')
		{
			loguear_usuario();
		}
	}	
}

function loguear_usuario() {
	var usuario = document.getElementById('txt_usuario');
	var clave = document.getElementById('txt_clave');
	var mensaje = document.getElementById('mensaje');
	
	if (usuario.value == '') {
		mensaje.innerHTML = 'Debe introducir un nombre de usuario';
		mensaje.style.visibility = 'visible';
		usuario.focus();
		return;
	} else if (clave.value == '') {
		mensaje.innerHTML = 'Debe introducir una contraseÃ±a';
		mensaje.style.visibility = 'visible';
		clave.focus();
		return;
	} else {
		var contenido_codigo = abrirAjax();
		contenido_codigo.open("GET", "admon/procesos.php?accion=validar&usuario="+usuario.value+"&clave="+clave.value, true);
		contenido_codigo.onreadystatechange=function()
		{
			if (contenido_codigo.readyState==4)
			{
				var arregloDatos;
				arregloDatos = contenido_codigo.responseText;
				if (arregloDatos == 0) {
					mensaje.innerHTML = 'La AutenticaciÃ³n es Incorrecta';
					mensaje.style.visibility = 'visible';
					clave.value = '';
					usuario.focus();
					return;
				} else if (arregloDatos == 1) {
					cambiar_contenido('admon/admin.php?usuario='+usuario.value, 'contenido');
				}
			}
		}
		contenido_codigo.send(null);
	}
}