function cargarEspecialidad() {
	var nucleo = document.getElementById("sel_nucleo").value;

	AjaxRequest.post(
						{
								'parameters': {     'nucleo':nucleo,
													'accion':'buscarEspecialidades'
													}
								,'onSuccess': respCargarEspecialidad
								,'url':'ingreso/transaccion/transIngreso.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
}

function respCargarEspecialidad(req) {
	var nucleo = document.getElementById("sel_nucleo");
	var esp = document.getElementById("sel_especialidad");
	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false)
	{
		esp.length = 0;
		esp.options[0] = new Option('Todas las especialidades');
		esp.options[0].value = '';
		esp.options[0].selected = true;
		
		for(var i=1,j=0; i<=resp.length; i++,j++)
		{
			document.getElementById('sel_especialidad').options[i] = new Option(resp[j]['nombre']);
			document.getElementById('sel_especialidad').options[i].value = resp[j]['codigo'];
		}
	}
	else
	{
		alert('No existen especialidades registrados para el nÃºcleo seleccionado');
		nucleo.value = 0;
		esp1.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
		esp2.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
		esp3.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
		return;
	}
}

function verListado()
{
	var codNucleo=document.getElementById('sel_nucleo').value;
	var esp=document.getElementById('sel_especialidad').value;
	var tipoListado=document.getElementById('sel_tipo_listado').value;
	var doc=document.getElementById('sel_doc').value;
	
	var ancho='50';
	var largo='50';
	
	if(tipoListado!=16)
		var url="consultas/listado_"+doc+".php?tipoListado="+tipoListado+"&codNucleo="+codNucleo+"&esp="+esp;
	else	
		var url="consultas/cuadro_"+doc+".php?tipoListado="+tipoListado+"&codNucleo="+codNucleo+"&esp="+esp;
	
	if(codNucleo!=0)
		popup(url,ancho,largo);
	else
		alert("Debe selecionar el nÃºcleo, el tipo de consulta y la especialidad a consultar");
	
}

function buscarEstatusEstu()
{
	var cedEstu=document.getElementById('txt_cedula').value;
	
	AjaxRequest.post(
						{
								'parameters': {     'cedEstu':cedEstu,
													'op':'buscarInfoEstu'
													}
								,'onSuccess': respBuscarEstatusEstu
								,'url':'consultas/transaccion/transConsultas.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	
}

function respBuscarEstatusEstu(req) {
	
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		document.getElementById('txt_nombres').value=resp[0]['nombres']+" "+resp[0]['apellidos'];
		document.getElementById('sel_tipo_listado').value = resp[0]['estatus'];
		document.getElementById('sel_datos').value = 1;
		document.getElementById('sel_doc').value = resp[0]['documentos']; 
		document.getElementById('img1').innerHTML= '<a href="recaudos/'+resp[0]['cedula']+'_recaudo1.jpg" target="_blank"><img onerror="this.src=\'../../imagenes/img_no_disponible.png\'" src="recaudos/'+resp[0]['cedula']+'_recaudo1.jpg" width="70"></a>';
		document.getElementById('img2').innerHTML= '<a href="recaudos/'+resp[0]['cedula']+'_recaudo2.jpg" target="_blank"><img onerror="this.src=\'../../imagenes/img_no_disponible.png\'" src="recaudos/'+resp[0]['cedula']+'_recaudo2.jpg" width="70"></a>';
		document.getElementById('img3').innerHTML= '<a href="recaudos/'+resp[0]['cedula']+'_recaudo3.jpg" target="_blank"><img onerror="this.src=\'../../imagenes/img_no_disponible.png\'" src="recaudos/'+resp[0]['cedula']+'_recaudo3.jpg" width="70"></a>';
		
		var esp = document.getElementById("sel_especialidad");
		esp.length = 0;
		var j=0;
		for(var i=0; i<resp.length; i++)
		{
			if(resp[i]['para_mi']==1)
			{
				document.getElementById('sel_especialidad').options[j] = new Option(resp[i]['especialidad']+"   -   Prioridad "+resp[i]['prioridad']+"- ASIGNADA");
				document.getElementById('sel_especialidad').options[j].value = resp[i]['cod_especialidad'];
				document.getElementById('sel_especialidad').options[j].selected = true;
				j++;
			}
			else
			{
				document.getElementById('sel_especialidad').options[j] = new Option(resp[i]['especialidad']+" (SIN ASIGNAR)");
				document.getElementById('sel_especialidad').options[j].value =0;
				j++;
			}
			
		}
		
		//buscar documentos
						cedEstu=resp[0]['cedula'];
						
						AjaxRequest.post(
						{
								'parameters': {     'cedEstu':cedEstu,
													'op':'buscarInfoDoc'
													}
								,'onSuccess': respDocRecibidos
								,'url':'consultas/transaccion/transConsultas.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
		
		
	}
	else
	{
		alert('No existe registro con esta identificaciÃ³n o no pertenece a su nÃºcleo. Verifique sus datos');
		limpiarFormconsultaDoc();
		return;
	}
}

function respDocRecibidos(req)
{
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		var recaudos=resp[0]['documentos'];
		document.getElementById('txt_obs').value=resp[0]['observacion'];
		recaudos=recaudos.split("-");
				
		for(var i=0;i<recaudos.length-1;i++)
		{
			document.getElementById('doc'+recaudos[i]).checked=true;
		}
	}
}

function actualizarDoc()
{
	var cedEstu=document.getElementById('txt_cedula').value;
	var estatus=document.getElementById('sel_doc').value;
	var numDoc=document.getElementById('num_doc').value;
	var obs=document.getElementById('txt_obs').value;
	var documentos="";
	
	for(var i=0;i<numDoc;i++)
	{
		d=document.getElementById("doc"+i);
		
		if(d.checked==true)
		{
			documentos=documentos+document.getElementById("doc"+i).value+"-";
		}
	}
	
	if((documentos=="" && estatus==1) || cedEstu=="") //estatus==1
	{
		alert("Ha dejado campos vacios! Debe indicar los documentos que han sido recibidos y/o consignados");
	}
	else
	{
		if(confirm('Â¿Esta seguro que desea actualizar los datos?'))
		{
			AjaxRequest.post(
								{
										'parameters': {     'cedEstu':cedEstu,
															'estatus':estatus,
															'doc':documentos,
															'obs':obs,
															'op':'actualizarDoc'
															}
										,'onSuccess': respActualizarDoc
										,'url':'consultas/transaccion/transConsultas.php'
										,'onError': function(req)
										{
											alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
										}
								}
								);
		}
		else
		{
			alert("OperaciÃ³n descartada");
		}
	}
}

function respActualizarDoc(req) {
	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false)
	{
		alert("Registro guardado con Ã©xito");
		limpiarFormconsultaDoc();
	}
	else
	{
		alert('Error! \nEl registro no ha podido ser guardado. Intente nuevamente');
	}
}

function limpiarFormconsultaDoc()
{
	cambiar_contenido('consultas/revision.php', 'contenido');
}

function buscarInfoAsignar()
{
	var cedEstu=document.getElementById('txt_cedula').value;
	
	AjaxRequest.post(
						{
								'parameters': {     'cedEstu':cedEstu,
													'op':'buscarInfoEstu'
													}
								,'onSuccess': respBuscarInfoAsignar
								,'url':'consultas/transaccion/transConsultas.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
}

function respBuscarInfoAsignar(req) {
	
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		var nuevaEsp=document.getElementById("nuevaEsp");
		nuevaEsp.innerHTML="<a onClick=javascrip:openMyModal('consultas/form_esp_nueva.php?c="+resp[0]['cedula']+'-'+resp[0]['cod_nucleo']+"') class='enlace'>Agregar una nueva especialidad</a>";
		document.getElementById('txt_nombres').value=resp[0]['nombres']+" "+resp[0]['apellidos'];
		document.getElementById('sel_tipo_listado').value = resp[0]['estatus'];
		document.getElementById('sel_nucleo').value = resp[0]['cod_nucleo'];
		
		var esp = document.getElementById("sel_especialidad");
		esp.length = 0;
		var msj='';
		var pos=0;
		for(var i=0,j=0; i<resp.length; i++,j++)
		{
			if(resp[i]['para_mi']==1)
			{
				msj='ASIGNADA'; pos=i;
			}
			else
				msj='NO ASIGNADA';
				
			if(resp[i]['estatus']==5)
				msj+='(COLA SELECCIÃ“N INTERNA)';

			document.getElementById('sel_especialidad').options[j] = new Option("["+resp[i]['cod_especialidad']+"] "+resp[i]['especialidad']+"   -   OPCIÃ“N "+resp[i]['prioridad']+" - "+msj);
			document.getElementById('sel_especialidad').options[j].value = resp[i]['cod_especialidad']+'-'+resp[i]['prioridad'];
		}
		
		document.getElementById('txt_obs').value=resp[0]['observacion'];
		document.getElementById('sel_especialidad').options[pos].selected = true;
	}
	else
	{
		alert('No existe registro con esta identificaciÃ³n o no pertenece a su nÃºcleo. Verifique sus datos');
		limpiarInfoAsignar(0);
		return;
	}
}

function buscarInfoReasignarNucleo()
{
	var cedEstu=document.getElementById('txt_cedula').value;
	
	AjaxRequest.post(
						{
								'parameters': {     'cedEstu':cedEstu,
													'op':'buscarInfoEstu'
													}
								,'onSuccess': respBuscarInfoReasignarNucleo
								,'url':'consultas/transaccion/transConsultas.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
}

function respBuscarInfoReasignarNucleo(req) {
	
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		document.getElementById('txt_nombres').value=resp[0]['nombres']+" "+resp[0]['apellidos'];
		document.getElementById('sel_tipo_listado').value = resp[0]['estatus'];
		document.getElementById('sel_nucleo').value = resp[0]['cod_nucleo'];
		document.getElementById('txt_obs').value=resp[0]['observacion'];
		
		var esp = document.getElementById("sel_especialidad");
		esp.length = 0;
		var msj='';
		var pos=-1;
		for(var i=0,j=0; i<resp.length; i++,j++)
		{
			if(resp[i]['para_mi']==1)
			{
				msj='ASIGNADA'; pos=i;
			}
			else
				msj='NO ASIGNADA';
				
			if(resp[i]['estatus']==4)
				msj+='(COLA SELECCIÃ“N INTERNA)';

			document.getElementById('sel_especialidad').options[j] = new Option("["+resp[i]['cod_especialidad']+"] "+resp[i]['especialidad']+"   -   OPCIÃ“N "+resp[i]['prioridad']+" - "+msj);
			document.getElementById('sel_especialidad').options[j].value = resp[i]['cod_especialidad']+'-'+resp[i]['prioridad'];
		}
	}
	else
	{
		alert('No existe registro con esta identificaciÃ³n o no pertenece a su nÃºcleo. Verifique sus datos');
		limpiarInfoRezagados();
		return;
	}
}

function asignarEspecialidad()
{
	var cedEstu=document.getElementById('txt_cedula').value;
	var codEsp=document.getElementById('sel_especialidad').value;
	var oficio=document.getElementById('txt_oficio').value;
	
	if(codEsp==0 || cedEstu=="" || oficio=="") 
	{
		alert("Ha dejado campos vacios! Debe indicar la especialidad a ser asignada");
	}
	else
	{
	
		if(confirm('Â¿Esta seguro que desea actualizar los datos?'))
		{
			AjaxRequest.post(
								{
										'parameters': {     'cedEstu':cedEstu,
															'codEsp':codEsp,
															'oficio':oficio,
															'op':'asignarEspecialidad'
															}
										,'onSuccess': respAsignarEspecialidad
										,'url':'consultas/transaccion/transConsultas.php'
										,'onError': function(req)
										{
											alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
										}
								}
								);
		}
		else
		{
			alert("OperaciÃ³n descartada");
		}
	}
}

function respAsignarEspecialidad(req) {
	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false)
	{
		alert("Registro guardado con Ã©xito");
		limpiarInfoAsignar(0);
	}
	else
	{
		alert('Error! \nEl registro no ha podido ser guardado. Intente nuevamente');
	}
}

function agregarNuevaEsp()
{
	var cedEstu=document.getElementById('cedula').value;
	var codEsp=document.getElementById('sel_especialidad').value;
	var codNuc=document.getElementById('sel_nucleo').value;
	
	if(codEsp==0 || cedEstu=="") 
	{
		alert("Ha dejado campos vacios! Debe indicar la especialidad a ser agregada");
	}
	else
	{
	
		if(confirm('Â¿Esta seguro que desea agregar la nueva especialidad?'))
		{
			AjaxRequest.post(
								{
										'parameters': {     'cedEstu':cedEstu,
															'codEsp':codEsp,
															'codNuc':codNuc,
															'accion':'agregarNuevaOpcion'
															}
										,'onSuccess': respAgregarNuevaEsp
										,'url':'../ingreso/transaccion/transIngreso.php'
										,'onError': function(req)
										{
											alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
										}
								}
								);
		}
		else
		{
			alert("OperaciÃ³n descartada");
		}
	}
}

function respAgregarNuevaEsp(req) {
	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false)
	{
		alert("Registro guardado con Ã©xito");
		//buscarInfoAsignar();
	}
	else
	{
		alert('Error! \nEl registro no ha podido ser guardado. Intente nuevamente');
	}
}

function asignarFormaIngreso()
{
	var cedEstu=document.getElementById('txt_cedula').value;
	var codFormIng=document.getElementById('sel_tipo_listado2').value;
	var cedAgr='';var gremio='';
	
	if(codFormIng==-1 || cedEstu=="") 
	{
		alert("Ha dejado campos vacios! Debe indicar la especialidad a ser asignada");
	}
	else
	{
	
		if(confirm('Â¿Esta seguro que desea actualizar los datos?'))
		{
			if(codFormIng==3)
			{
				oficio=document.getElementById('txt_oficio').value;
				cedAgr=document.getElementById('txt_ced_agremiado').value;
				gremio=document.getElementById('sel_gremio').value;
			}
			
			AjaxRequest.post(
								{
										'parameters': {     'cedEstu':cedEstu,
															'codFormIng':codFormIng,
															'cedAgr':cedAgr,
															'gremio':gremio,
															'oficio':oficio,
															'op':'asignarFormaIngreso'
															}
										,'onSuccess': respAsignarFormaIngreso
										,'url':'consultas/transaccion/transConsultas.php'
										,'onError': function(req)
										{
											alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
										}
								}
								);
		}
		else
		{
			alert("OperaciÃ³n descartada");
		}
	}
}

function respAsignarFormaIngreso(req) {
	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false)
	{
		alert("Registro guardado con Ã©xito");
		limpiarInfoAsignar(1);
	}
	else
	{
		alert('Error! \nEl registro no ha podido ser guardado. Intente nuevamente');
	}
}

function infoConvformIng()
{
	if(document.getElementById('sel_tipo_listado2').value==3)	
		document.getElementById('infoConvFormIng').style.display='block';
	else
		document.getElementById('infoConvFormIng').style.display='none';
}

function buscarInfoEstuRezagado()
{
	var cedEstu=document.getElementById('txt_cedula').value;
	
	AjaxRequest.post(
						{
								'parameters': {     'cedEstu':cedEstu,
													'op':'buscarInfoEstuRezagado'
													}
								,'onSuccess': respBuscarInfoEstuRezagado
								,'url':'consultas/transaccion/transConsultas.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	
}

function respBuscarInfoEstuRezagado(req)
{   
	var resp = eval ("("+ req.responseText +")");
	
	if(resp!=false)
	{
		var aux=resp.split('||');
		if(aux[0]==1)
		{
			document.getElementById("txt_nombres").value=aux[1];
			document.getElementById("sel_nucleo").value=aux[2];
			document.getElementById('sel_esp_uno').length=0;
			document.getElementById('sel_esp_uno').options[0] = new Option(aux[5]);
			document.getElementById('sel_esp_uno').options[0].value =aux[4];
			document.getElementById("sel_tipo_listado").value=aux[6];
			document.getElementById("txt_obs").value=aux[7];
			document.getElementById("sel_nucleo").disabled=true;
			document.getElementById('sel_esp_uno').disabled=true;
		}
		else if(aux[0]==2)
		{
			document.getElementById("txt_nombres").value=aux[1];
			document.getElementById("sel_tipo_listado").value=aux[4];
			document.getElementById("txt_obs").value=aux[5];
			document.getElementById("sel_nucleo").disabled=false;
			document.getElementById('sel_esp_uno').disabled=false;
			
			alert("El bachiller "+aux[1]+", es asignado OPSU para otro nucleo como sigue: \n\n"+aux[2]+" - "+aux[3]);
			
		}
		
	}
	else
	{
		alert("Este estudiante se encuentra ya registrado o no es asignado CNU-OPSU de este nucleo/periodo. Verifique sus datos");
		limpiarInfoRezagados();
	}
}


function guardarRezagado()
{
	var cedEstu=document.getElementById('txt_cedula').value;
	var codNucleo=document.getElementById('sel_nucleo').value;
	var codEsp=document.getElementById('sel_esp_uno').value;
	var oficio=document.getElementById('txt_oficio').value;
	var obs=document.getElementById('txt_obs').value;
	
	if(cedEstu=='') alert("Ingrese la cÃ©dula del estudiante a consultar");
	else
	{
		AjaxRequest.post(
							{
									'parameters': {     'cedEstu':cedEstu,
														'codNucleo':codNucleo,
														'codEsp':codEsp,
														'oficio':oficio,
														'obs':obs,
														'op':'registrarRezagado'
														}
									,'onSuccess': respGuardarRezagado
									,'url':'consultas/transaccion/transConsultas.php'
									,'onError': function(req)
									{
										alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
									}
							}
							);
	}
	
}

function respGuardarRezagado(req)
{   
	var resp = eval ("("+ req.responseText +")");
	
	if(resp!=false)
	{
		alert("Sus datos fueron guardados guardados con Ã©xito");
		limpiarInfoRezagados();
	}
	else
	{
		alert("Error! Sus datos no pudieron ser guardados. Verifique sus datos");
		limpiarInfoRezagados();
	}
}

function reasignarNucleo()
{
	var cedEstu=document.getElementById('txt_cedula').value;
	var codNucleoActual=document.getElementById('sel_nucleo').value;
	var codNucleoNuevo=document.getElementById('sel_nucleo_nuevo').value;
	
	if(codNucleoNuevo==0 || cedEstu=="") 
	{
		alert("Ha dejado campos vacios! Debe indicar el nÃºcleo a ser asignada");
	}
	else
	{
	
		if(confirm('Â¿Esta seguro que desea actualizar los datos?'))
		{
			AjaxRequest.post(
								{
										'parameters': {     'cedEstu':cedEstu,
															'codNucleoNuevo':codNucleoNuevo,
															'codNucleoActual':codNucleoActual,
															'op':'reasignarNucleo'
															}
										,'onSuccess': respReasignarNucleo
										,'url':'consultas/transaccion/transConsultas.php'
										,'onError': function(req)
										{
											alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
										}
								}
								);
		}
		else
		{
			alert("OperaciÃ³n descartada");
		}
	}
}

function respReasignarNucleo(req) {
	
	var resp = eval ("("+ req.responseText +")");
	if(resp == 1)
	{
		alert("Registro guardado con Ã©xito. \n\nImportante: es posible que alguna de sus opciones de carrera hayan sido eliminadas por no cursarse en el nuevo nÃºcleo. Revise sus datos");
		limpiarInfoRezagados();
	}
	else if(resp == 2)
	{
		alert("Error! \n\nEste bachiller ha formalizado documentos en su nucleo actual y no puede ser cambiado a otro nÃºcleo. Revise sus datos");
		limpiarInfoRezagados();
	}
	else
	{
		alert('Error! \nEl registro no ha podido ser guardado. Intente nuevamente');
	}
}

function limpiarInfoRezagados()
{
	document.getElementById('txt_cedula').value='';
	document.getElementById('txt_nombres').value='';
	document.getElementById('sel_esp_uno').length=0;
	document.getElementById('sel_esp_uno').options[0] = new Option("..");
	document.getElementById('sel_esp_uno').options[0].value =0;
	document.getElementById('sel_nucleo').value =0;
	document.getElementById('sel_tipo_listado').value =-1;
	document.getElementById('txt_obs').value ='';
	document.getElementById('txt_oficio').value ='';
	document.getElementById('sel_nucleo').disabled=true;
	document.getElementById('sel_esp_uno').disabled=true;
	document.getElementById('txt_cedula').focus();
}

function limpiarInfoAsignar(valor)
{
	document.getElementById('txt_cedula').value='';
	document.getElementById('txt_nombres').value='';
	document.getElementById('sel_especialidad').length=0;
	document.getElementById('sel_especialidad').options[0] = new Option("..");
	document.getElementById('sel_especialidad').options[0].value =0;
	/*document.getElementById('sel_nucleo').length=0;
	document.getElementById('sel_nucleo').options[0] = new Option("..");*/
	document.getElementById('sel_nucleo').value =0;
	document.getElementById('sel_tipo_listado').value =-1;
	document.getElementById('txt_obs').value ='';
	document.getElementById("nuevaEsp").innerHTML='';
	
	if(valor==1)
	{
		document.getElementById('sel_tipo_listado2').value =-1;
		document.getElementById('txt_ced_agremiado').value='';
		document.getElementById('txt_nombre_agremiado').value='';
		document.getElementById("chequearAgremiado").innerHTML='';
		document.getElementById('infoConvFormIng').style.display='none';
	}
	
	document.getElementById('txt_cedula').focus();
}