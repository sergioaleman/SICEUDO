function soloNumeros(e) {
	var code;
	if (!e) var e = window.event;
	if (e.keyCode) code = e.keyCode;// EN CASO QUE EL NAVEGADOR SEA IE
	else if (e.which) code = e.which; //EN CASO QUE EL NAVEGADOR SEA MOZILLA FIREFOX
	return (code<=13 || code==127 || (code>=48 && code<=57)); //|| code==46
}

function soloNumerosLogros(e) {
	var code;
	if (!e) var e = window.event;
	if (e.keyCode) code = e.keyCode;// EN CASO QUE EL NAVEGADOR SEA IE
	else if (e.which) code = e.which; //EN CASO QUE EL NAVEGADOR SEA MOZILLA FIREFOX
	return (code<=13 || code==127 || (code>=48 && code<=57) || code==46 || (code>=35 && code<=39) || code==45);
}

function numeroDecimal(evt) {
	var nav4=window.Event?true:false;
	var key=nav4?evt.which:evt.keyCode;
	return (key<=13 || key==127 || (key>=48 && key<=57) || (key==46));//|| (key==44)
}

function soloMayuscula(cadena,id)// FUNCION ENCARGADA DE COLOCAR LAS LETRAS PRESIONADAS EN MAYUSCULAS
{
	var txt=document.getElementById(id).value.toUpperCase(cadena);
	document.getElementById(id).value=txt;
}

function soloCodigo(e) {
	var code;
	if (!e) var e = window.event;
	if (e.keyCode) code = e.keyCode;// EN CASO QUE EL NAVEGADOR SEA IE
	else if (e.which) code = e.which; //EN CASO QUE EL NAVEGADOR SEA MOZILLA FIREFOX
	return(code<=13 || code==127 || (code>=48 && code<=57) || (code==45 ) || (code>=35 && code<=38));
}

function soloIp(e) {
	var code;
	if (!e) var e = window.event;
	if (e.keyCode) code = e.keyCode;// EN CASO QUE EL NAVEGADOR SEA IE
	else if (e.which) code = e.which; //EN CASO QUE EL NAVEGADOR SEA MOZILLA FIREFOX
	return (code<=13 || code==127 || (code>=48 && code<=57) || code==46 || code==44 || (code>=35 && code<=39));
}

function validarEmail(valor,id) {
	if ((/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(valor)) || (valor=='')) {
		return (true)
	} else {
	alert("La direcciÃ³n de email es incorrecta.");
	document.getElementById(id).value='';
	return (false);
	}
}

function esFecha(fecha) {
	if (fecha != undefined && fecha != "" ) {
		if (!/^\d{2}\/\d{2}\/\d{4}$/.test(fecha)) {
			return false;
		}
		var dia  =  parseInt(fecha.substring(0,2),10);
		var mes  =  parseInt(fecha.substring(3,5),10);
		var anio =  parseInt(fecha.substring(6),10);
		switch(mes) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				numDias=31;
				break;
			case 4: case 6: case 9: case 11:
				numDias=30;
				break;
			case 2:
				if (comprobarSiBisisesto(anio)){ numDias=29 }else{ numDias=28};
				break;
			default:
				return false;
		}
		if (dia>numDias || dia==0) {
			return false;
		}
		return true;
	}
}

function comprobarSiBisisesto(anio) {
	if ( ( anio % 100 != 0) && ((anio % 4 == 0) || (anio % 400 == 0))) {
		return true;
	}
	else {
		return false;
	}
}

function soloFecha(fecha, id) {
	var fec = document.getElementById(id);
	if (fecha != undefined && fec.value != "" ) {
		if (!/^\d{2}\/\d{2}\/\d{4}$/.test(fec.value)) {
			//alert(fecha);
			alert("El formato de la fecha no es vÃ¡lido (Ej: dd/mm/aaaa)");
			fec.value = '';
			fec.focus();
			return false;
		}
		var dia  =  parseInt(fec.value.substring(0,2),10);
		var mes  =  parseInt(fec.value.substring(3,5),10);
		var anio =  parseInt(fec.value.substring(6),10);
		switch(mes) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				numDias=31;
				break;
			case 4: case 6: case 9: case 11:
				numDias=30;
				break;
			case 2:
				if (comprobarSiBisisesto(anio)){ numDias=29 }else{ numDias=28};
				break;
			default:
				alert("La fecha introducida es errÃ³nea");
				fec.value = '';
				fec.focus();
				return false;
		}
		if (dia>numDias || dia==0) {
			alert("La fecha introducida es errÃ³nea");
			fec.value = '';
			fec.focus();
			return false;
		}
		return true;
	}
}

function soloHora(hora, id) {
	var id_hora = document.getElementById(id);
	if ((hora < 1) || (hora > 12)) {
		alert("La hora introducida es errÃ³nea");
		id_hora.value = '';
		id_hora.focus();
		return false;
	}
}

function formatoFecha(valor)
{
	//para cambiar el formato de la fecha aaaa-mm-dd por dd/mm/aaaa 
	if(valor!=null && valor!="")
	{
		var fechaArray= valor.split('-');
		var anio=fechaArray[0];
		var mes=fechaArray[1];
		var dia =fechaArray[2];
		var fecha=dia+'/'+mes+'/'+anio;
		return fecha;
	}
	else
		return null;
}

function marcarTodos(chkbox)
{
	for (var i=0; i<document.forms[0].elements.length; i++)
	{
		var elemento = document.forms[0].elements[i];
		if (elemento.type == "checkbox")
		{
			elemento.checked = chkbox.checked
		}
	}
}

function soloNumeroLetra(evt)
{
	var nav4=window.Event?true:false;
	var key=nav4?evt.which:evt.keyCode;
	//alert(key);
	return(key<=13 || key==127 || (key>=48 && key<=57) || (key==32) || (key==109) || (key>=97 && key<=122) || (key>=65 && key<=92) || key==13 || key==46 || key==35);
}

function campoVacio(q)
{  
         for ( i = 0; i < q.length; i++ ) {  
                 if ( q.charAt(i) != " " ) {  
                        return true;  
                 }  
         }  
       return false;  
}

function calendario(v1,v2)
{
	Calendar.setup(
		{
		  inputField  : v1,         // ID of the input field
		  ifFormat    : "%d/%m/%Y",      // the date format
		  button      : v2        // ID of the button
		}
	  );
}

function popup(url,w,h)
{
	ventanaHija = window.open(url, 'ventanaHija','toolbar=0,scrollbars=1,location=0,statusbar=1,menubar=0,resizable=1,width='+w+',height='+h+',left = 120,top = 180');
}

function estiloSobre(id)//estilo para las filas de las tablas. Aï¿½ade color al pasar sobre las filas
{
	document.getElementById(id).style.background="#FFFF99";	
}

function estiloDeja(id,color)//estilo para las filas de las tablas. devuelve el color original al pasar sobre las filas
{
    document.getElementById(id).style.background=color;	
}

function estiloSeleccion(id,color,idLista,checkVerificar)
{
	//alert(pos+' '+idLista+' '+color+' '+id);
	//color='#FFFF99';
	var checkBox=document.getElementById(checkVerificar).checked;
	
	if(checkBox==true)		
		document.getElementById(id).style.background='#FFFF99';	
	else	
		document.getElementById(id).style.background=color;	
}

function limpiarCampos(campo,tipoDato)// Ernesto Rivas
{
	/*Funcion que permite limpiar los campos del formulario, donde el programador 
	debe enviar por parametro 2 arreglo, el primero tiene que tener los id de los campos y otro arreglo con los 
	tipo de campo*/
	var long=campo.length;
	
	for (var i=0;i<long;i++)
	{
		
		if(tipoDato[i]=='sel')
		{
			document.getElementById(campo[i]).value='0';
		}
		else
			document.getElementById(campo[i]).value='';
	}
	document.getElementById(campo[0]).focus();
}

function soloLetras(e)
{
     key = e.keyCode || e.which;
     tecla = String.fromCharCode(key).toLowerCase();
     letras = " Ã¡Ã©Ã­Ã³ÃºabcdefghijklmnÃ±opqrstuvwxyz";
     especiales = [8,46];

      tecla_especial = false
      for(var i in especiales){
            if(key == especiales[i]){
                tecla_especial = true;
                break;
            }
        }

        if(letras.indexOf(tecla)==-1 && !tecla_especial){
            return false;
        }
}

function calcular_edad(fecha) {
	var dia, mes, ano, edad;
	var fechaAct = obtiene_fecha();
	
	var hoy = fechaAct.split("/");
	var dia = hoy[0];
	var mes = hoy[1];
	var ano = hoy[2];
	
	var fechaNac = fecha.split("/");
	var diaNac = fechaNac[0];
	var mesNac = fechaNac[1];
	var anoNac = fechaNac[2];

	if ((mesNac == mes) && (diaNac > dia)) {
		ano = (ano - 1);
	}

	if (mesNac > mes) {
		ano = (ano - 1);
	}
	edad = (ano - anoNac);
	return edad;
}

function obtiene_fecha() {
    var fecha_actual = new Date();
    var dia = fecha_actual.getDate() - 1;
    var mes = fecha_actual.getMonth() + 1;
    var anio = fecha_actual.getFullYear();
    if (mes < 10)
        mes = '0' + mes;
    if (dia < 10)
        dia = '0' + dia;
    return (dia + "/" + mes + "/" + anio);
}