<style type="text/css">
<!--
.tAzul{ font-family: 'Raleway', sans-serif;  line-height: 43px; font-size: 17px; font-weight:600; color:#00acef;}
-->
</style>
<table width="100%" border="0" align="center" style="color:#333">
  <tr>
    <td colspan="3" valign="top"><div align="left" class="featured"><span class="tAzul"><img src="imagenes/logo3.png" width="50" height="50" />Oferta de Estudios  </span></div></td>
  </tr>
  <tr>
    <td width="4%">&nbsp;</td>
    <td width="92%" align="justify">
	<p>En esta casa de estudios podrás encontrar diferentes especialidades que abarcan diversas áreas de conocimiento como se indican a continuación. Descargar<a href="info/doc/especialidades_sucre.pdf" target="_blank"> Aqui</a></p>
	<br />
	</td>
    <td width="4%" align="justify">&nbsp;</td>
  </tr>
</table>