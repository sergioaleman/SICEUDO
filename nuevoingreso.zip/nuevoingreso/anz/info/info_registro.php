<style type="text/css">
<!--
.tAzul{ font-family: 'Raleway', sans-serif;  line-height: 43px; font-size: 17px; font-weight:600; color:#00acef;}
-->
</style>
<table width="100%" border="0" align="center" style="color:#333">
  <tr>
    <td colspan="3" valign="top"><div align="left" class="featured"><span class="tAzul"><!--<img src="imagenes/logo.gif" width="50" height="50" />-->¿Cómo registrarme?</span></div></td>
  </tr>
  
  <tr>
    <td width="4%">&nbsp;</td>
    <td width="91%" align="justify">
	<p>
	Gracias por elegirnos como tu casa de estudios. Los pasos son:<br /><br />
	1. Presiona la opción <strong>REGISTRAR ASPIRANTE </strong>. Debes llenar toda la información que se te solicita. Es importante que coloques información real. Es indispensable tu correo electrónico, ya que será nuestra forma de comunicarnos.<br />
	<br />
	2. Una vez que hayas ingresado toda la información, presiona el botón <strong>GUARDAR REGISTRO</strong>. El sistema te pedira confirmar la operación y si estas seguro presiona la opción <strong>ACEPTAR</strong><br />
	<br />
    3. Al terminar el registro, puedes imprimir tu <strong>PLANILLA DE REGISTRO</strong> en la opción <strong>CONSULTAR ASPIRANTE</strong>. Introduce tu identificación (cédula o pasaporte) y presiona el ícono de búsqueda. Descarga la planilla y guardala como garantía de tu registro.<br />
    <br />
	Al terminar el proceso de registro, se procede a revisar y/o comprobar toda la información de cada aspirante, para finalmente realizar la selección de acuerdo a los prerrequisitos de cada especialidad (carrera) y a la disponibilidad de cupos. Los resultados y los próximos pasos a seguir, serán informados por esta página. Independientemente de si eres seleccionado o no, se te dará respuesta de tu solicitud.<br /><br />
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabla" bgcolor="#FFFF99">
	  <tr>
		<td>
		<img src="imagenes/informacion.png" width="30" height="30"/><strong> Importante!</strong><br />
    	&nbsp;<strong>1.</strong> Depósito bancario Banco <strong>MERCANTIL Cuenta Corriente N° 0105-0046031046496751 Bs 232.272,00. RIF de la UDO: G-20000052-0</strong> <br />
    	<strong>&nbsp;2.</strong> Correo electrónico activo, de uso personal<br />
    	<strong>&nbsp;3.</strong> Certificado de participación CNU-OPSU<br />
    	&nbsp;**Los asignados CNU-OPSU, no requieren de depósito bancario<br />		</td>
	  </tr>
	</table>
	<br />
	Si tienes problemas con tu registro o no puedes imprimir tu planilla, no dudes en comunicarte con nosotros a través de nuestro correo electrónico.
	</p>
    <br />
    <p>Para cualquier informaci&oacute;n adicional recuerda nuestro punto de contacto <strong>compu.anzoategui@udo.edu.ve</strong>, <strong>nuevoingreso.anz@udo.edu.ve</strong></p>    </td>
    <td width="5%" align="justify">&nbsp;</td>
  </tr>
</table>