<style type="text/css">
<!--
.Estilo1 {color: #FF0000; font-size:9px;}
-->
</style>
<div align="center" class="featured">
	<h4 align="left"><strong>Introduzca su identificación (Cédula o Pasaporte)  en el siguiente formulario</strong></h4>
</div>
<!--<form id="consulta" style="color:#333">-->
<fieldset>
<legend><strong>Datos del Aspirante</strong></legend>
<table width="100%" border="0" style="color:#333">
  <tr>
    <td colspan="4">&nbsp;</td>
  </tr>
  <tr>
    <td width="200" align="right"><strong><span class="Estilo1">**</span></strong>Identificación</td>
    <td width="102"><input name="txt_cedula" type="text" id="txt_cedula" size="15" maxlength="15" onKeyPress="return soloNumeros(event);" onChange="mostrarRegistro()"></td>
    <td width="59" class="tGris9"><img src="imagenes/buscar.png" width="20" height="20" border="0" style="cursor:pointer" onClick="mostrarRegistro()"></td>
    <td width="863" class="tGris9">
	<div id="buscarAspirante" class="tGris11">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td>&nbsp;</td>
		  </tr>
		</table>
	  </div>	</td>
  </tr>
  <tr>
    <td colspan="4">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4">
	<div id="cargarInfoAspirante">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td>&nbsp;</td>
		  </tr>
		</table>
	  </div>
	</td>
  </tr>
  <tr>
    <td colspan="4">
	<div id="cargarInfoResultado">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td>&nbsp;</td>
		  </tr>
		</table>
	  </div>
	</td>
  </tr>
</table>
</fieldset>
<br>
<fieldset>
<legend ><strong>Opciones del Formulario</strong></legend>
<TABLE align="left" width="100%" border="0" cellpadding="5" cellspacing="5">
	<TR>
	  <TD width="79%" align="right">&nbsp;</TD>
		<TD width="10%" align="right"><input name="button2" type="button" class="boton" onclick="imprimirRegistro();" value="Imprimir Planilla" /></TD>
		<TD width="11%" align="right"><input name="button" type="button" class="boton" onclick="limpiarConsultaAspirante();" value="Limpiar Formulario" /></TD>
	</TR>
</TABLE>
</fieldset>
<!--</form>-->