function buscarAspiranteEx()
{
	var cedula=document.getElementById("txt_cedula").value;
	var chequeo=document.getElementById("chequearAspirante");
	
	chequeo.innerHTML= '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';
			
			var cedula=document.getElementById("txt_cedula").value;
			AjaxRequest.post(
			{
				'parameters': {'cedula':cedula,
							   'accion':'buscarEstuUdo'
							  }
							  ,'onSuccess': respEstuUdoEx
							  ,'url':'ingreso/transaccion/transIngresoConv.php'
							  ,'onError': function(req)
							  {
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							  }
			}
			);
}

function respEstuUdoEx(req)
{
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		document.getElementById("txt_cedula").value='';
		var chequeo=document.getElementById("chequearAspirante");
	    chequeo.innerHTML= '';
		alert("Estimado Usuario! \n\nUsted no puede realizar el registro como nuevo ingreso de este estudiante ya que pertenece a nuestra instituciÃ³n. Si es estudiante INACTIVO o es EGRESADO debera solicitar un reingreso. Si es estudiante ACTIVO requerira de una solicitud de traslado. Para mÃ¡s informaciÃ³n dirigirse a las oficinas de DACE de su nÃºcleo");
	}
	else
	{
		//buscar si tiene ya un registro como aspirante
		var cedula=document.getElementById("txt_cedula").value;
		AjaxRequest.post(
		{
			'parameters': {'cedula':cedula,
						   'accion':'buscarAspirante'
						  }
						  ,'onSuccess': respAspiranteEx
						  ,'url':'ingreso/transaccion/transIngresoConv.php'
						  ,'onError': function(req)
						  {
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						  }
		}
		);
	}
}

function respAspiranteEx(req)
{
	    
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		limpiarFormRegistroAspiranteEx(); 
		alert("Estimado Usuario! \n\nEste bachiller se encuentra como aspirante. Para imprimir su registro visite el enlace CONSULTAR ASPIRANTE");
	}
	else
	{
		var chequeo=document.getElementById("chequearAspirante");
	    chequeo.innerHTML= '<p><img src="imagenes/ingresar.png" width="15"> OK!</p>';
		var msj=document.getElementById("mensaje");
	    msj.innerHTML= '';
		document.getElementById("txt_apellidos").focus();	
	}
}

function validarFormEx()
{
    var doc=document.getElementById("tipo_doc").value;
	var cedula=document.getElementById("txt_cedula").value;
	var nombres=document.getElementById("txt_nombres").value;
	var apellidos=document.getElementById("txt_apellidos").value;
	var formIng=document.getElementById("sel_tipo_listado").value;
	
	var especialidad='';
	var nucleo='';
	var msj="";
	
	nucleo=document.getElementById("sel_nucleo").value;
	especialidad=document.getElementById("sel_esp_uno").value;
	
	if(formIng==0 || formIng==2){ nucleo='N/A'; especialidad='N/A';}
	
	var gremio=0;var ced_agremiado=0;var nom_agremiado=0;var parentesco=0;var tlf_agremiado=0;
	if(formIng==3)
	{ 
		var gremio=document.getElementById('sel_gremio').value;
		var ced_agremiado=document.getElementById('txt_ced_agremiado').value;
		var nom_agremiado=document.getElementById('txt_nombre_agremiado').value;
		var parentesco=document.getElementById('sel_parentesco').value;
		var tlf_agremiado=document.getElementById('txt_telefono_agremiado').value;
	}
		
	if(nucleo==0)
	  msj+="NÃºcleo\n";
	if(formIng==-1)
	  msj+="Forma de Ingreso\n";
	if(especialidad==0)
	  msj+="Especialidad\n";
	if(cedula=='')
	  msj+="CÃ©dula\n";
	if(nombres=='')
	  msj+="Nombres\n";
	if(apellidos=='')
	  msj+="Apellidos\n";

	
	if(msj!='')
	{
		alert("Usted ha dejado campos vacios. Por favor verificar su informaciÃ³n\n"+msj);
	}
	else
	{
		
		if(confirm('Â¿Esta seguro que desea registrar sus datos?'))
		{
			AjaxRequest.post(
							{
									'parameters': {		'doc':doc,
														'cedula':cedula,
														'apellidos':apellidos,
														'nombres':nombres,
														'formIng':formIng,
														'especialidad':especialidad,
														'nucleo':nucleo,
														'gremio':gremio,
														'ced_agremiado':ced_agremiado,
														'nom_agremiado':nom_agremiado,
														'parentesco':parentesco,
														'tlf_agremiado':tlf_agremiado,
														'accion':'nuevoEstudianteEx'
														}
									,'onSuccess': respValidarFormEx
									,'url':'ingreso/transaccion/transIngresoConv.php'
									,'onError': function(req)
									{
										alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
									}
							}
							);
		}
	}
}

function respValidarFormEx(req)
{
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		alert("Registro realizado con exito. \n\nPara mÃ¡s detalles ir a CONSULTAR ASPIRANTE\n\n");
		limpiarFormRegistroAspiranteEx();
	}
	else
	    alert("Error! Registro no realizado. Intentelo nuevamente");
	
}

function cargarEspEx() {
	var nucleo = document.getElementById("sel_nucleo").value;

	AjaxRequest.post(
						{
								'parameters': {     'nucleo':nucleo,
													'accion':'buscarEspecialidades'
													}
								,'onSuccess': respCargarEspEx
								,'url':'ingreso/transaccion/transIngresoConv.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
}

function respCargarEspEx(req) {
	var nucleo = document.getElementById("sel_nucleo");
	var especialidad = document.getElementById("sel_esp_uno");
	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false)
	{
		document.getElementById('sel_esp_uno').options.length = 0;
		document.getElementById('sel_esp_uno').options[0] = new Option('Seleccione...');
		document.getElementById('sel_esp_uno').options[0].value = '0';
		document.getElementById('sel_esp_uno').options[0].selected = true;
		
		var disable=false;
		
		for(var i=1,j=0; i<=resp.length; i++,j++) 
		{	
			if(resp[j]['estatus']==0)
			{
				disable=true;
			}
			
			if(resp[j]['condicion']!=null)
				msj="("+resp[j]['condicion']+")";
			else
				msj="";
			
			document.getElementById('sel_esp_uno').options[i] = new Option('['+resp[j]['codigo']+'] '+resp[j]['nombre']+"\t"+msj);
			document.getElementById('sel_esp_uno').options[i].value = resp[j]['codigo'];
			//document.getElementById('sel_esp_uno').options[i].disabled=disable;
			
			disable=false;
			msj='';
		}
	}
	else
	{
		alert('No existen especialidades registrados para el nÃºcleo seleccionado');
		nucleo.value = 0;
		especialidad.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
		return;
	}
}

function bloquearOpcionesEspEx()
{
	var formIng=document.getElementById('sel_tipo_listado').value;
	var div=document.getElementById('convenio');
	
	if(formIng==0 || formIng==2)
	{
		document.getElementById('sel_nucleo').value=0;
		document.getElementById('sel_esp_uno').value=0;
		document.getElementById('sel_nucleo').disabled=true;
		document.getElementById('sel_esp_uno').disabled=true;
		div.style.display='none';
	}
	else if(formIng==3)
	{
		div.style.display='block';
	}
	else
	{
		document.getElementById('sel_nucleo').value=0;
		document.getElementById('sel_esp_uno').value=0;
		document.getElementById('sel_nucleo').disabled=false;
		document.getElementById('sel_esp_uno').disabled=false;
		div.style.display='none';
	}
}

function limpiarFormRegistroAspiranteEx()
{
	cambiar_contenido('ingreso/formAspExt.php', 'contenido');
}