function buscarCaso()
{
	var cedula=document.getElementById("txt_cedula").value;
	var chequeo=document.getElementById("chequearAspirante");
	
	chequeo.innerHTML= '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';
			
			var cedula=document.getElementById("txt_cedula").value;
			AjaxRequest.post(
			{
				'parameters': {'cedula':cedula,
							   'accion':'buscarRegistro'
							  }
							  ,'onSuccess': respBuscarCaso
							  ,'url':'ingreso/transaccion/transIngreso.php'
							  ,'onError': function(req)
							  {
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							  }
			}
			);
}

function respBuscarCaso(req)
{
	var resp = eval ("("+ req.responseText +")");
	var chequeo=document.getElementById("chequearAspirante");
	    chequeo.innerHTML= '';
	var opciones = "";
	
	if(resp.length>0)
	{
		if(resp[0]['cod_nucleo'] != '3')
		{
			document.getElementById("txt_cedula").value="";
			alert("No puede modificar esta cÃ©dula. Bachiller registrado por el nÃºcleo "+resp[0]['nucleo']);
		}
		for(var i=0;i<resp.length;i++)
		{
			opciones = opciones+resp[i]['especialidad']+" - ";
			if(resp[i]['para_mi'] == '1')  
			{
				document.getElementById("txt_cedula").value="";
				alert("No puede modificar esta cÃ©dula. Bachiller asignado a especialidad "+resp[i]['especialidad']);
			}
		}
		if(document.getElementById("txt_cedula").value != "")
			chequeo.innerHTML= '<p><img src="imagenes/info.png" width="15"> Bachiller Registrado en '+opciones+'</p>';
			document.getElementById("txt_apellidos").value=resp[0]['apellidos'];
			document.getElementById("txt_nombres").value=resp[0]['nombres'];
	}
	else
	{
		document.getElementById("txt_cedula").value="";
		alert("No puede modificar esta cÃ©dula. Bachiller no registrado");
	}
}

function validarFormCaso()
{
	var cedula=document.getElementById("txt_cedula").value;
	var nucleo=document.getElementById("sel_nucleo").value;
	var esp=document.getElementById("sel_esp").value;
	var msj="";

	if(cedula=='') msj+="CÃ©dula\n";
	if(nucleo==0) msj+="NÃºcleo\n";
	if(esp==0) msj+="Especialidad\n";
	
	if(msj!='')
	{
		alert("Usted ha dejado campos vacios. Por favor verificar su informaciÃ³n\n"+msj);
	}
	else
	{
		if(confirm('Â¿Esta seguro que desea registrar sus datos?'))
		{
			AjaxRequest.post(
							{
									'parameters': {'cedula':cedula,
														'especialidad':esp,
														'nucleo':nucleo,
														'accion':'actAspiranteCaso'
														}
									,'onSuccess': respValidarFormCaso
									,'url':'ingreso/transaccion/transIngreso.php'
									,'onError': function(req)
									{
										alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
									}
							}
							);
		}
	}
}

function respValidarFormCaso(req)
{
	var resp = eval ("("+ req.responseText +")");
	if(resp != false)
	{
		alert("Registro realizado con exito!");
		limpiarFormCaso();
	}
	else
	    alert("Error! Revise la disponibilidad de cupo en la especialidad");
}

function limpiarFormCaso()
{
	cambiar_contenido('ingreso/formIngresoCaso.php', 'contenido');
}