function validarForm() {
    var doc = document.getElementById("tipo_doc").value;
    var cedula = document.getElementById("txt_cedula").value;
    var nombres = document.getElementById("txt_nombres").value;
    var apellidos = document.getElementById("txt_apellidos").value;
    var sexo = document.getElementById("sel_sexo").value;
    var tipoSangre = document.getElementById("sel_tipo_sangre").value;
    var edoCivil = document.getElementById("sel_edo_civil").value;
    var nacionalidad = document.getElementById("sel_nacionalidad").value;
    var fechaNac = document.getElementById("txt_fecha_nac").value;
    var etnia = document.getElementById("sel_etnia").value;
    var pais = document.getElementById("sel_pais").value;
    var estado = document.getElementById("sel_estado").value;
    var ciudad = document.getElementById("txt_ciudad").value;
    var condicion = document.getElementById("sel_condicion").value;
    var libertad = document.getElementById("sel_libertad").value;
    var discapacidad = document.getElementById("sel_discapacidad").value;
    var direccion = document.getElementById("txt_direccion").value;
    var tlf = document.getElementById("txt_telefono").value;
    var celular = document.getElementById("txt_celular").value;
    var email = document.getElementById("txt_email").value;
    var anioGrad = document.getElementById("sel_graduacion").value;
    var becado = document.getElementById("sel_becado").value;
    var promedio = document.getElementById("txt_promedio").value;
    var titulo = document.getElementById("sel_titulo").value;
    //var plantel=document.getElementById("sel_plantel").value;
    var numDeposito = document.getElementById("txt_num_deposito").value;
    var plantel = document.getElementById("txt_plantel").value;
    var rusnies = document.getElementById("txt_rusnies").value;
    var estatus = document.getElementById("estatus").value;

    var pais_plantel = document.getElementById("sel_pais_plantel").value;
    var estado_plantel = document.getElementById("sel_estado_plantel").value;
    var ciudad_plantel = document.getElementById("txt_ciudad_plantel").value;

    var especialidad = '';
    var nucleo = '';
    var msj = "";

    if (estatus == 1) //poblacion flotante
    {
        nucleo = document.getElementById("sel_nucleo").value;
        var esp1 = document.getElementById("sel_esp_uno").value;
        var esp2 = document.getElementById("sel_esp_dos").value;
        var esp3 = document.getElementById("sel_esp_tres").value;
        especialidad = esp1 + "-" + esp2 + "-" + esp3;

        if ((esp1 == esp2 || esp1 == esp3 || esp2 == esp3) && nucleo == 3)
            msj += "Debes seleccionar tres (3) Especialidades diferentes\n";

        if (nucleo == 0)
            msj += "NÃºcleo\n";
        if (esp1 == 0 || esp2 == 0 || esp3 == 0)
            msj += "Especialidad\n";
        if (numDeposito == '')
            msj += "NÃºmero de DepÃ³sito (voucher)\n";
    } else if (estatus == 0 || estatus == 4) //asignados opsu
    {
        var nucleo = document.getElementById("sel_nuc").value;
        var especialidad = document.getElementById("sel_esp").value;
        numDeposito = 'N/A';
    }

    if (cedula == '')
        msj += "CÃ©dula\n";
    if (nombres == '')
        msj += "Nombres\n";
    if (apellidos == '')
        msj += "Apellidos\n";
    if (sexo == 0)
        msj += "Sexo\n";
    if (tipoSangre == 0)
        msj += "Tipo de Sangre\n";
    if (edoCivil == 0)
        msj += "Estado Civil\n";
    if (nacionalidad == 0)
        msj += "Nacionalidad\n";
    if (fechaNac == '')
        msj += "Fecha de Nacimiento\n";
    if (etnia == '00')
        msj += "Etnia\n";
    if (pais == 0)
        msj += "PaÃ­s\n";
    if (estado == 0)
        msj += "Estado\n";
    if (ciudad == '')
        msj += "Ciudad\n";
    if (condicion == 0)
        msj += "CondiciÃ³n\n";
    if (libertad == 0)
        msj += "Libertad\n";
    if (discapacidad == '00')
        msj += "Discapacidad\n";
    if (direccion == '')
        msj += "DirecciÃ³n\n";
    if (tlf == '' || celular == '')
        msj += "TelÃ©fono o Celular\n";
    if (email == '')
        msj += "Email\n";
    if (anioGrad == 0)
        msj += "AÃ±o de GraduaciÃ³n\n";
    if (becado == 0)
        msj += "Becado\n";
    if (promedio == '' || parseInt(promedio) > 20)
        msj += "Promedio\n";
    if (titulo == '')
        msj += "Titulo\n";
    if (plantel == '')
        msj += "Plantel\n";
    if (pais_plantel == 0)
        msj += "PaÃ­s del plantel\n";
    if (estado_plantel == 0)
        msj += "Estado del plantel\n";
    if (ciudad_plantel == '')
        msj += "Ciudad del plantel\n";
    if (rusnies == '')
        msj += "NÃºmero SNI\n";


    if (msj != '') {
        alert("Usted ha dejado campos vacios. Por favor verificar su informaciÃ³n\n" + msj);
    } else {
        edad = calcular_edad(fechaNac);
        if (edad < 14) {
            alert('La edad del estudiante es de ' + edad + ' aÃ±os, no puede ser inscrito en la instituciÃ³n');
            return;
        }

        msj = "\nCEDULA: " + cedula + "\nNOMBRE: " + nombres + " " + apellidos + "\nCORREO: " + email + "\n\nNota: Si algunos de los datos es incorrecto presionar cancelar para corregir";

        if (confirm('Â¿Esta seguro que desea registrar sus datos?' + msj)) {
            AjaxRequest.post({
                'parameters': {
                    'cedula': cedula,
                    'apellidos': apellidos,
                    'nombres': nombres,
                    'especialidad': especialidad,
                    'nucleo': nucleo,
                    'fechaNac': fechaNac,
                    'sexo': sexo,
                    'edoCivil': edoCivil,
                    'nacionalidad': nacionalidad,
                    'direccion': direccion,
                    'tlf': tlf,
                    'email': email,
                    'titulo': titulo,
                    'anioGrad': anioGrad,
                    'pais': pais,
                    'estado': estado,
                    'ciudad': ciudad,
                    'celular': celular,
                    'promedio': promedio,
                    'plantel': plantel,
                    'numDeposito': numDeposito,
                    'tipoSangre': tipoSangre,
                    'doc': doc,
                    'condicion': condicion,
                    'etnia': etnia,
                    'becado': becado,
                    'libertad': libertad,
                    'rusnies': rusnies,
                    'estatus': estatus,
                    'discapacidad': discapacidad,
                    'pais_plantel': pais_plantel,
                    'estado_plantel': estado_plantel,
                    'ciudad_plantel': ciudad_plantel,
                    'accion': 'nuevoEstudiante'
                },
                'onSuccess': respNuevoEstudiante,
                'url': 'ingreso/transaccion/transIngreso.php',
                'onError': function(req) {
                    alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
                }
            });
        }
    }
}

function respNuevoEstudiante(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp != false) {
        alert("Registro realizado con exito!!\n\n Para imprimir tu planilla de registro debes ir a CONSULTAR ASPIRANTE");
        limpiarFormRegistroAspirante();
    } else
        alert("Error! \n\nRegistro no realizado. Verifique sus datos e intÃ©ntalo nuevamente");

}

function verificarEmail(email) {
    var chequeo = document.getElementById("chequearEmail");
    chequeo.innerHTML = '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';
    AjaxRequest.post({
        'parameters': {
            'email': email,
            'accion': 'buscarEmail'
        },
        'onSuccess': respBuscarEmail,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respBuscarEmail(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        alert("La direcciÃ³n de correo electrÃ³nico que esta registrando, ya se encuentra en uso por otro usuario, por favor indique uno nuevo");
        var chequeo = document.getElementById("chequearEmail");
        chequeo.innerHTML = '<p><img src="imagenes/menos.png" width="15"> Error!</p>';
        document.getElementById("txt_email").value = '';
    } else {
        var chequeo = document.getElementById("chequearEmail");
        chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> OK!</p>';
    }
}

function verificarDeposito(num) {
    var chequeo = document.getElementById("chequearDeposito");
    chequeo.innerHTML = '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';
    AjaxRequest.post({
        'parameters': {
            'num': num,
            'accion': 'buscarDeposito'
        },
        'onSuccess': respBuscarDeposito,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respBuscarDeposito(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        alert("El nÃºmero de depÃ³sito que esta registrando, ya se encuentra en uso por otro usuario, por favor indique uno nuevo");
        var chequeo = document.getElementById("chequearDeposito");
        chequeo.innerHTML = '';
        document.getElementById("txt_num_deposito").value = '';
    } else {
        var chequeo = document.getElementById("chequearDeposito");
        chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> OK!</p>';
    }
}

function cargar_especialidades() {
    var nucleo = document.getElementById("sel_nucleo").value;

    AjaxRequest.post({
        'parameters': {
            'nucleo': nucleo,
            'accion': 'buscarEspecialidades'
        },
        'onSuccess': resp_cargar_especialidades,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function resp_cargar_especialidades(req) {
    var nucleo = document.getElementById("sel_nucleo");
    var esp1 = document.getElementById("sel_esp_uno");
    var esp2 = document.getElementById("sel_esp_dos");
    var esp3 = document.getElementById("sel_esp_tres");

    var resp = eval("(" + req.responseText + ")");
    if (resp != false) {
        document.getElementById('sel_esp_uno').options.length = 0;
        document.getElementById('sel_esp_uno').options[0] = new Option('Seleccione...');
        document.getElementById('sel_esp_uno').options[0].value = '0';
        document.getElementById('sel_esp_uno').options[0].selected = true;

        document.getElementById('sel_esp_dos').options.length = 0;
        document.getElementById('sel_esp_dos').options[0] = new Option('Seleccione...');
        document.getElementById('sel_esp_dos').options[0].value = '0';
        document.getElementById('sel_esp_dos').options[0].selected = true;

        document.getElementById('sel_esp_tres').options.length = 0;
        document.getElementById('sel_esp_tres').options[0] = new Option('Seleccione...');
        document.getElementById('sel_esp_tres').options[0].value = '0';
        document.getElementById('sel_esp_tres').options[0].selected = true;

        var disable = false;

        for (var i = 1, j = 0; i <= resp.length; i++, j++) {
            if (resp[j]['estatus'] == 0) {
                disable = true;
            }

            if (resp[j]['condicion'] != null)
                msj = "(" + resp[j]['condicion'] + ")";
            else
                msj = "";

            document.getElementById('sel_esp_uno').options[i] = new Option(resp[j]['nombre'] + "\t" + msj);
            document.getElementById('sel_esp_uno').options[i].value = resp[j]['codigo'];
            document.getElementById('sel_esp_uno').options[i].disabled = disable;

            document.getElementById('sel_esp_dos').options[i] = new Option(resp[j]['nombre'] + "\t" + msj);
            document.getElementById('sel_esp_dos').options[i].value = resp[j]['codigo'];
            document.getElementById('sel_esp_dos').options[i].disabled = disable;

            document.getElementById('sel_esp_tres').options[i] = new Option(resp[j]['nombre'] + "\t" + msj);
            document.getElementById('sel_esp_tres').options[i].value = resp[j]['codigo'];
            document.getElementById('sel_esp_tres').options[i].disabled = disable;

            disable = false;
            msj = '';
        }
    } else {
        alert('No existen especialidades registradas para el nÃºcleo seleccionado');
        nucleo.value = 0;
        esp1.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
        esp2.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
        esp3.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
        return;
    }
}

function cargar_estados() {
    var pais = document.getElementById("sel_pais").value;

    AjaxRequest.post({
        'parameters': {
            'pais': pais,
            'accion': 'buscarEstados'
        },
        'onSuccess': resp_cargar_estados,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function resp_cargar_estados(req) {
    var pais = document.getElementById("sel_pais");
    var estado = document.getElementById("sel_estado");

    var resp = eval("(" + req.responseText + ")");
    if (resp != false) {
        document.getElementById('sel_estado').options.length = 0;
        document.getElementById('sel_estado').options[0] = new Option('Seleccione...');
        document.getElementById('sel_estado').options[0].value = '0';
        document.getElementById('sel_estado').options[0].selected = true;

        for (var i = 1, j = 0; i <= resp.length; i++, j++) {
            document.getElementById('sel_estado').options[i] = new Option(resp[j]['descripcion']);
            document.getElementById('sel_estado').options[i].value = resp[j]['cod_estado'];
        }
    } else {
        estado.innerHTML = '<OPTION value="999">EXTRANJERO</OPTION>';
        return;
    }
}

function cargar_estados_plantel() {
    var pais = document.getElementById("sel_pais_plantel").value;

    AjaxRequest.post({
        'parameters': {
            'pais': pais,
            'accion': 'buscarEstados'
        },
        'onSuccess': resp_cargar_estados_plantel,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function resp_cargar_estados_plantel(req) {
    var pais = document.getElementById("sel_pais_plantel");
    var estado = document.getElementById("sel_estado_plantel");

    var resp = eval("(" + req.responseText + ")");
    if (resp != false) {
        document.getElementById('sel_estado_plantel').options.length = 0;
        document.getElementById('sel_estado_plantel').options[0] = new Option('Seleccione...');
        document.getElementById('sel_estado_plantel').options[0].value = '0';
        document.getElementById('sel_estado_plantel').options[0].selected = true;

        for (var i = 1, j = 0; i <= resp.length; i++, j++) {
            document.getElementById('sel_estado_plantel').options[i] = new Option(resp[j]['descripcion']);
            document.getElementById('sel_estado_plantel').options[i].value = resp[j]['cod_estado'];
        }
    } else {
        estado.innerHTML = '<OPTION value="999">EXTRANJERO</OPTION>';
        return;
    }
}

function buscarPlantel() {
    var edo = document.getElementById('sel_edo_plantel').value;

    AjaxRequest.post({
        'parameters': {
            'edo': edo,
            'accion': 'buscarPlantelEdo'
        },
        'onSuccess': respBuscarPlantel,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respBuscarPlantel(req) {
    var resp = eval("(" + req.responseText + ")");
    var edo = document.getElementById('sel_edo_plantel');
    var plantel = document.getElementById('sel_plantel');

    if (resp != false) {
        document.getElementById('sel_plantel').options.length = 0;
        document.getElementById('sel_plantel').options[0] = new Option('Seleccione...');
        document.getElementById('sel_plantel').options[0].value = '0';
        document.getElementById('sel_plantel').options[0].selected = true;

        for (var i = 1, j = 0; i <= resp.length; i++, j++) {
            document.getElementById('sel_plantel').options[i] = new Option(resp[j]['nombre_plantel']);
            document.getElementById('sel_plantel').options[i].value = resp[j]['cod_plantel'];
        }
    } else {
        alert('No existen planteles registrados para el estado seleccionado');
        edo.value = 0;
        plantel.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
        return;
    }
}

function buscarAspirante() {
    var cedula = document.getElementById("txt_cedula").value;
    var chequeo = document.getElementById("chequearAspirante");

    chequeo.innerHTML = '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';

    var cedula = document.getElementById("txt_cedula").value;
    AjaxRequest.post({
        'parameters': {
            'cedula': cedula,
            'accion': 'buscarEstuUdo'
        },
        'onSuccess': respEstuUdo,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {

            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respEstuUdo(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        document.getElementById("txt_cedula").value = '';
        var chequeo = document.getElementById("chequearAspirante");
        chequeo.innerHTML = '';
        alert("Estimado Usuario! \n\nUsted no puede realizar el registro como nuevo ingreso ya que pertenece a nuestra instituciÃ³n. \n\n1. Si es estudiante INACTIVO o es EGRESADO debera solicitar un reingreso. \n2. Si es estudiante ACTIVO requerira de una solicitud de traslado. \n\nPara mÃ¡s informaciÃ³n dirigirse a las oficinas de DACE de su nÃºcleo");
    } else {
        //buscar si tiene ya un registro como aspirante
        var cedula = document.getElementById("txt_cedula").value;
        AjaxRequest.post({
            'parameters': {
                'cedula': cedula,
                'accion': 'buscarAspirante'
            },
            'onSuccess': respAspirante,
            'url': 'ingreso/transaccion/transIngreso.php',
            'onError': function(req) {
                alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
            }
        });
    }
}

function respAspirante(req) {

    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        limpiarFormRegistroAspirante();
        alert("Estimado Usuario! \n\nUsted ya posee un registro como aspirante. Para imprimir su registro revise su correo electrÃ³nico o visite el enlace CONSULTAR ASPIRANTE");
    } else {
        //buscarOtrosConvenios();
        //buscar asignado opsu
        var cedula = document.getElementById("txt_cedula").value;
        AjaxRequest.post({
            'parameters': {
                'cedula': cedula,
                'accion': 'buscarAsignadoOpsu'
            },
            'onSuccess': respBuscarAspirante,
            'url': 'ingreso/transaccion/transIngreso.php',
            'onError': function(req) {
                alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
            }
        });
    }
}

function respBuscarAspirante(req) {
    var resp = eval("(" + req.responseText + ")");

    if (resp.length > 0) {
        if ((resp[0]['cod_nucleo'] == '3' || resp[0]['cod_nucleo'] == '31' || resp[0]['cod_nucleo'] == '32') && (resp[0]['semestre'] == 'I-2021')) {
            //alert("Lo sentimos! Ha finalizado el registro para asignados OPSU 2-2019"); //esto incluye ambos nÃºcleos
            //limpiarFormRegistroAspirante();

            alert("Usted se encuentra asignado por CNU-OPSU. A continuaciÃ³n mÃ¡s detalles \n\nCEDULA: " + resp[0]['cedula'] + "\nNOMBRES: " + resp[0]['nombres'] + "\nNUCLEO: " + resp[0]['nucleo'] + "\nESPECIALIDAD: " + resp[0]['especialidad'] + "\nSEMESTRE: " + resp[0]['semestre']);

            var chequeo = document.getElementById("chequearAspirante");
            chequeo.innerHTML = '<p><img src="imagenes/info.png" width="15"> Bachiller Asignado Por Opsu</p>';
            document.getElementById("estatus").value = '0';

            //cargar datos precargados
            document.getElementById("txt_cedula").value = resp[0]['cedula'];
            document.getElementById("txt_nombres").value = resp[0]['nombres'];
            document.getElementById("txt_telefono").value = resp[0]['telefono'];
            document.getElementById("txt_celular").value = resp[0]['telefono'];
            document.getElementById("txt_email").value = resp[0]['correo'];
            document.getElementById("txt_rusnies").value = resp[0]['id_rusnies'];
            document.getElementById("txt_promedio").value = resp[0]['promedio'];

            var msj = document.getElementById("mensaje");
            msj.innerHTML = '<p class="tNegro10" align="center"><img src="imagenes/info.png" width="15"> Esta especialidad ha sido asignada por CNU-OPSU. No requiere depÃ³sito bancario</p>';

            var esp = document.getElementById("especialidades");
            esp.innerHTML = '';

            var esp = document.getElementById("especialidadesAsignadas");
            esp.style.display = 'block';

            document.getElementById('sel_nuc').options[0] = new Option(resp[0]['nucleo']);
            document.getElementById('sel_nuc').options[0].value = resp[0]['cod_nucleo'];
            document.getElementById('sel_nuc').options[0].selected = true;

            document.getElementById('sel_esp').options[0] = new Option(resp[0]['especialidad']);
            document.getElementById('sel_esp').options[0].value = resp[0]['cod_especialidad'];
            document.getElementById('sel_esp').options[0].selected = true;

        } else if (resp[0]['semestre'] != 'I-2021') {
            var chequeo = document.getElementById("chequearAspirante");
            chequeo.innerHTML = '';
            document.getElementById("txt_cedula").value = "";

            alert("Usted se encuentra asignado por CNU-OPSU para un semestre diferente a I-2021, por lo tanto no puede ser preinscrito. A continuaciÃ³n mÃ¡s detalles \n\nCEDULA: " + resp[0]['cedula'] + "\nNOMBRES: " + resp[0]['nombres'] + "\nNUCLEO: " + resp[0]['nucleo'] + "\nESPECIALIDAD: " + resp[0]['especialidad'] + "\nSEMESTRE: " + resp[0]['semestre']);
        } else {
            var chequeo = document.getElementById("chequearAspirante");
            chequeo.innerHTML = '';
            document.getElementById("txt_cedula").value = "";

            alert("Usted se encuentra asignado por CNU-OPSU en un nÃºcleo distinto al NÃšCLEO DE ANZOATEGUI, por lo tanto no puede ser preinscrito. A continuaciÃ³n mÃ¡s detalles \n\nCEDULA: " + resp[0]['cedula'] + "\nNOMBRES: " + resp[0]['nombres'] + "\nNUCLEO: " + resp[0]['nucleo'] + "\nESPECIALIDAD: " + resp[0]['especialidad'] + "\nSEMESTRE: " + resp[0]['semestre']);
        }
    } else {
        //buscarOtrosConvenios();
        //alert("El registro se encuentra disponible solo para ASIGNADOS OPSU I-2021");
        //limpiarFormRegistroAspirante();

        //no hay asignado opsu
        var cedula = document.getElementById("txt_cedula").value;
        AjaxRequest.post({
            'parameters': {
                'cedula': cedula,
                'accion': 'buscarColaOpsu'
            },
            'onSuccess': respBuscarCola,
            'url': 'ingreso/transaccion/transIngreso.php',
            'onError': function(req) {
                alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
            }
        });
    }
}

function respBuscarCola(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        //alert("Lo sentimos! Ha finalizado el registro para la cola OPSU 2-2019"); //esto incluye ambos nÃºcleos
        //limpiarFormRegistroAspirante();

        var msj = '';
        var msj1 = '';
        for (i = 0; i < resp.length; i++) {
            msj += resp[i]["especialidad"] + ".       NÃšCLEO: " + resp[i]["nucleo"] + ".    POSICIÃ“N: " + resp[i]["posicion"] + "\n";
            msj1 += resp[i]["especialidad"] + ".       NÃšCLEO: " + resp[i]["nucleo"] + ".    POSICIÃ“N: " + resp[i]["posicion"] + "<br/>";
        }


        if (confirm("Usted se encuentra asignado a la siguiente LISTA DE COLA, segÃºn informaciÃ³n de la OPSU.\n\n" + msj + " \n\nÂ¿Acepta la especialidad (carrera) asignada en la lista de cola (serÃ¡ asignada la de menor posiciÃ³n)?")) {

            document.getElementById("estatus").value = '2';

            var chequeo = document.getElementById("chequearAspirante");
            chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> Bachiller Asignado A lista de Cola Por Opsu</p>';

            document.getElementById("txt_apellidos").value = resp[0]["apellidos"];
            document.getElementById("txt_nombres").value = resp[0]["nombres"];
            document.getElementById("txt_rusnies").value = resp[0]["sni"];
            document.getElementById("txt_promedio").value = resp[0]["promedio"];

            var opciones = document.getElementById("especialidades");
            opciones.innerHTML = '';

            //crear tabla
            var tabla = document.getElementById('especialidadesAsignadas');

            // creates a <table> element and a <tbody> element
            var tbl = document.createElement("table");
            tbl.width = '100%';
            //tbl.setAttribute("id","tabla");
            var tblBody = document.createElement("tbody");

            //creamos la cabecera
            color = '#DFE4FD';

            // creates a table row
            var row = document.createElement("tr");

            row.setAttribute('bgcolor', color);
            row.setAttribute('id', 'fila' + i);
            row.setAttribute('onMouseOver', 'estiloSobre(id)');
            row.setAttribute('onMouseOut', 'estiloDeja(id,"' + color + '")');
            row.setAttribute('class', 'fila');


            var cell0 = document.createElement("td");
            var cell1 = document.createElement("td");
            var cell2 = document.createElement("td");
            var cell3 = document.createElement("td");


            cell0.width = '4%';
            cell0.align = 'center';

            cell1.width = '20%';
            cell1.align = 'left';

            cell2.width = '4%';
            cell2.align = 'left';

            cell3.width = '10%';
            cell3.align = 'left';

            cell0.setAttribute('id', 'columna');
            cell1.setAttribute('id', 'columna');
            cell2.setAttribute('id', 'columna');
            cell3.setAttribute('id', 'columna');

            var cellText0 = document.createTextNode('NÂ°');
            var cellText1 = document.createTextNode('ESPECIALIDAD');
            var cellText2 = document.createTextNode('POSICIÃ“N');
            var cellText3 = document.createTextNode('NÃšCLEO');

            cell0.appendChild(cellText0);
            cell1.appendChild(cellText1);
            cell2.appendChild(cellText2);
            cell3.appendChild(cellText3);

            row.appendChild(cell0);
            row.appendChild(cell1);
            row.appendChild(cell2);
            row.appendChild(cell3);

            tblBody.appendChild(row);

            tbl.appendChild(tblBody);
            tbl.setAttribute("border", "0");
            tbl.setAttribute('class', 'tabla');

            tabla.innerHTML = '';
            tabla.appendChild(tbl);

            // creating all cells
            for (var i = 0, j = 1; i < resp.length; i++, j++) {


                if (i % 2 == 0) {
                    color = '#F3F3F3';
                } else {
                    color = '#DFE4FD';
                }
                // creates a table row
                var row = document.createElement("tr");

                row.setAttribute('bgcolor', color);
                row.setAttribute('id', 'fila' + i);
                row.setAttribute('onMouseOver', 'estiloSobre(id)');
                row.setAttribute('onMouseOut', 'estiloDeja(id,"' + color + '")');
                row.setAttribute('class', 'fila');


                var cell0 = document.createElement("td");
                var cell1 = document.createElement("td");
                var cell2 = document.createElement("td");
                var cell3 = document.createElement("td");


                cell0.width = '4%';
                cell0.align = 'center';

                cell1.width = '20%';
                cell1.align = 'left';

                cell2.width = '4%';
                cell2.align = 'left';

                cell3.width = '10%';
                cell3.align = 'left';

                cell0.setAttribute('id', 'columna');
                cell1.setAttribute('id', 'columna');
                cell2.setAttribute('id', 'columna');
                cell3.setAttribute('id', 'columna');

                var cellText0 = document.createTextNode(j);
                var cellText1 = document.createTextNode(resp[i]['especialidad']);
                var cellText2 = document.createTextNode(resp[i]['posicion']);
                var cellText3 = document.createTextNode(resp[i]['nucleo']);

                cell0.appendChild(cellText0);
                cell1.appendChild(cellText1);
                cell2.appendChild(cellText2);
                cell3.appendChild(cellText3);

                row.appendChild(cell0);
                row.appendChild(cell1);
                row.appendChild(cell2);
                row.appendChild(cell3);

                tblBody.appendChild(row);

                tbl.appendChild(tblBody);
                tbl.setAttribute("border", "0");
                tbl.setAttribute('class', 'tabla');

                tabla.innerHTML = '';
                tabla.appendChild(tbl);
            }

            var msj2 = document.getElementById("mensaje");
            msj2.innerHTML = '<p class="tNegro10" align="center"><img src="imagenes/info.png" width="15"> Usted ha sido asignado por CNU-OPSU a una lista de cola y esta optando a la siguiente especialidad <br/>(serÃ¡ asignada la de menor posiciÃ³n):<br/>' + msj1 + '</p>';
        } else //renuncia a la cola opsu
        {

            var msj = document.getElementById("chequearAspirante");
            msj.innerHTML = '';
            document.getElementById("estatus").value = '1';
            document.getElementById("txt_cedula").value = '';
            alert("Usted ha renunciado a la cola de opsu asignada. No puede realizar su registro como aspirante");
            return;
        }
    } else {
        //buscar otros convenios
        var cedula = document.getElementById("txt_cedula").value;
        AjaxRequest.post({
            'parameters': {
                'cedula': cedula,
                'accion': 'buscarOtrosConvenios'
            },
            'onSuccess': respBuscarOtrosConvenios,
            'url': 'ingreso/transaccion/transIngreso.php',
            'onError': function(req) {
                alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
            }
        });
    }
}

/*************/
function buscarOtrosConvenios() {
    var cedula = document.getElementById("txt_cedula").value;
    var chequeo = document.getElementById("chequearAspirante");

    chequeo.innerHTML = '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';

    var cedula = document.getElementById("txt_cedula").value;
    AjaxRequest.post({
        'parameters': {
            'cedula': cedula,
            'accion': 'buscarOtrosConvenios'
        },
        'onSuccess': respBuscarOtrosConvenios,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}
/************/
function respBuscarOtrosConvenios(req) {
    var resp = eval("(" + req.responseText + ")");

    if (resp.length > 0) {
        alert("Usted se encuentra registrado por " + resp[0]['convenio'] + ". A continuaciÃ³n mÃ¡s detalles \n\nCEDULA: " + resp[0]['ced_estudiante'] + "\nNOMBRES: " + resp[0]['nombres'] + " " + resp[0]['apellidos'] + "\nNUCLEO: " + resp[0]['nucleo'] + "\nESPECIALIDAD: " + resp[0]['especialidad'] + "\nSEMESTRE: " + resp[0]['semestre']);

        var chequeo = document.getElementById("chequearAspirante");
        chequeo.innerHTML = '<p><img src="imagenes/info.png" width="15"> Pendiente por Actualizar Datos (CONVENIO)</p>';
        document.getElementById("estatus").value = resp[0]['estatus'];

        //cargar datos precargados
        document.getElementById("txt_cedula").value = resp[0]['ced_estudiante'];
        document.getElementById("txt_nombres").value = resp[0]['nombres'];
        document.getElementById("txt_apellidos").value = resp[0]['apellidos'];

        var msj = document.getElementById("mensaje");
        msj.innerHTML = '<p class="tNegro10" align="center"><img src="imagenes/info.png" width="15"> Esta especialidad ha sido previamente asignada</p>';

        var esp = document.getElementById("especialidades");
        esp.innerHTML = '';

        var esp = document.getElementById("especialidadesAsignadas");
        esp.style.display = 'block';

        document.getElementById('sel_nuc').options[0] = new Option(resp[0]['nucleo']);
        document.getElementById('sel_nuc').options[0].value = resp[0]['cod_nucleo'];
        document.getElementById('sel_nuc').options[0].selected = true;

        document.getElementById('sel_esp').options[0] = new Option(resp[0]['especialidad']);
        document.getElementById('sel_esp').options[0].value = resp[0]['cod_especialidad'];
        document.getElementById('sel_esp').options[0].selected = true;
    } else {
        //buscar AO pendientes por actualizar datos
        var cedula = document.getElementById("txt_cedula").value;
        AjaxRequest.post({
            'parameters': {
                'cedula': cedula,
                'accion': 'buscarOtros'
            },
            'onSuccess': respBuscarOtros,
            'url': 'ingreso/transaccion/transIngreso.php',
            'onError': function(req) {
                alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
            }
        });
    }

}

function respBuscarOtros(req) {
    var resp = eval("(" + req.responseText + ")");

    if (resp.length > 0) {
        alert("Usted se encuentra registrado como ASIGNADO OPSU. A continuaciÃ³n mÃ¡s detalles \n\nCEDULA: " + resp[0]['cedula'] + "\nNOMBRES: " + resp[0]['nombres'] + "\nNUCLEO: " + resp[0]['nucleo'] + "\nESPECIALIDAD: " + resp[0]['especialidad'] + "\nSEMESTRE: " + resp[0]['anio'] + '-' + resp[0]['periodo']);

        var chequeo = document.getElementById("chequearAspirante");
        chequeo.innerHTML = '<p><img src="imagenes/info.png" width="15"> Pendiente por Actualizar Datos (ASIGNADO OPSU)</p>';
        document.getElementById("estatus").value = resp[0]['estatus'];

        //cargar datos precargados
        document.getElementById("txt_cedula").value = resp[0]['cedula'];
        document.getElementById("txt_nombres").value = resp[0]['nombres'];
        document.getElementById("txt_apellidos").value = resp[0]['nombres'];

        var msj = document.getElementById("mensaje");
        msj.innerHTML = '<p class="tNegro10" align="center"><img src="imagenes/info.png" width="15"> Esta especialidad ha sido asignada por CNU-OPSU. No requiere depÃ³sito bancario</p>';

        var esp = document.getElementById("especialidades");
        esp.innerHTML = '';

        var esp = document.getElementById("especialidadesAsignadas");
        esp.style.display = 'block';

        document.getElementById('sel_nuc').options[0] = new Option(resp[0]['nucleo']);
        document.getElementById('sel_nuc').options[0].value = resp[0]['cod_nucleo'];
        document.getElementById('sel_nuc').options[0].selected = true;

        document.getElementById('sel_esp').options[0] = new Option(resp[0]['especialidad']);
        document.getElementById('sel_esp').options[0].value = resp[0]['cod_especialidad'];
        document.getElementById('sel_esp').options[0].selected = true;
    } else {
        //poblacion flotante
        //alert("Lo sentimos!! \n\nTu registro no puede ser realizado. (REGISTRO DISPONIBLE SOLO PARA REZAGADOS OPSU Y CONVENIO I-2021)");
        //limpiarFormRegistroAspirante();

        document.getElementById("estatus").value = '1';
        var chequeo = document.getElementById("chequearAspirante");
        chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> OK!</p>';
        var msj = document.getElementById("mensaje");
        msj.innerHTML = '';
        document.getElementById("txt_cedula").focus();
    }
}

function buscarDatosAspirante() {
    var cedula = document.getElementById("txt_cedula_vieja").value;

    AjaxRequest.post({
        'parameters': {
            'cedula': cedula,
            'accion': 'buscarDatosPersonales'
        },
        'onSuccess': respBuscarDatosAspirante,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respBuscarDatosAspirante(req) {
    var resp = eval("(" + req.responseText + ")");

    if (resp.length > 0) {
        var fecha = resp[0]['fecha_nac'].split('-');

        document.getElementById("txt_cedula_nueva").value = resp[0]['cedula'];
        document.getElementById("txt_apellidos").value = resp[0]['apellidos'];
        document.getElementById("txt_nombres").value = resp[0]['nombres'];
        document.getElementById("txt_fecha_nac").value = fecha[2] + '/' + fecha[1] + '/' + fecha[0];
        document.getElementById("sel_pais").value = resp[0]['cod_pais'];
        document.getElementById("sel_estado").value = resp[0]['cod_estado'];

        document.getElementById("txt_ciudad").value = resp[0]['ciudad'];
        document.getElementById("sel_discapacidad").value = resp[0]['discapacidad'];
        document.getElementById("txt_direccion").value = resp[0]['direccion'];
        document.getElementById("txt_telefono").value = resp[0]['telefono'];
        document.getElementById("txt_celular").value = resp[0]['celular'];
        document.getElementById("txt_email").value = resp[0]['email'];

        document.getElementById("sel_graduacion").value = resp[0]['ano_grad'];
        document.getElementById("txt_promedio").value = resp[0]['promedio'];
        document.getElementById("sel_titulo").value = resp[0]['titulo_educ_med'];
        document.getElementById("txt_plantel").value = resp[0]['plantel'];
        document.getElementById("sel_pais_plantel").value = resp[0]['cod_pais_plantel'];
        document.getElementById("sel_estado_plantel").value = resp[0]['cod_estado_plantel'];
        document.getElementById("txt_ciudad_plantel").value = resp[0]['ciudad_plantel'];
        document.getElementById("txt_rusnies").value = resp[0]['cod_rusnies'];
        document.getElementById("txt_num_deposito").value = resp[0]['deposito'];

    } else {
        alert("No existen registros para esta identificaciÃ³n. Verifique sus datos");
        limpiarFormActualizarDatos();
    }
}

function actualizarDatosAspirante() {
    var cedula = document.getElementById("txt_cedula_vieja").value;
    var cedula_nueva = document.getElementById("txt_cedula_nueva").value;
    var nombres = document.getElementById("txt_nombres").value;
    var apellidos = document.getElementById("txt_apellidos").value;
    var fechaNac = document.getElementById("txt_fecha_nac").value;
    var pais = document.getElementById("sel_pais").value;
    var estado = document.getElementById("sel_estado").value;
    var ciudad = document.getElementById("txt_ciudad").value;
    var discapacidad = document.getElementById("sel_discapacidad").value;
    var direccion = document.getElementById("txt_direccion").value;
    var tlf = document.getElementById("txt_telefono").value;
    var celular = document.getElementById("txt_celular").value;
    var email = document.getElementById("txt_email").value;
    var anioGrad = document.getElementById("sel_graduacion").value;
    var promedio = document.getElementById("txt_promedio").value;
    var titulo = document.getElementById("sel_titulo").value;
    var numDeposito = document.getElementById("txt_num_deposito").value;
    var plantel = document.getElementById("txt_plantel").value;
    var rusnies = document.getElementById("txt_rusnies").value;
    var pais_plantel = document.getElementById("sel_pais_plantel").value;
    var estado_plantel = document.getElementById("sel_estado_plantel").value;
    var ciudad_plantel = document.getElementById("txt_ciudad_plantel").value;

    var msj = "";

    if (cedula == '')
        msj += "IdentificaciÃ³n\n";
    if (cedula_nueva == '')
        msj += "IdentificaciÃ³n Nueva\n";
    if (nombres == '')
        msj += "Nombres\n";
    if (apellidos == '')
        msj += "Apellidos\n";
    if (fechaNac == '')
        msj += "Fecha de Nacimiento\n";
    if (pais == 0)
        msj += "PaÃ­s\n";
    if (estado == 0)
        msj += "Estado\n";
    if (ciudad == '')
        msj += "Ciudad\n";
    if (discapacidad == '00')
        msj += "Discapacidad\n";
    if (direccion == '')
        msj += "DirecciÃ³n\n";
    if (tlf == '' || celular == '')
        msj += "TelÃ©fono o Celular\n";
    if (email == '')
        msj += "Email\n";
    if (anioGrad == 0)
        msj += "AÃ±o de GraduaciÃ³n\n";
    if (promedio == '')
        msj += "Promedio\n";
    if (titulo == '')
        msj += "Titulo\n";
    if (plantel == '')
        msj += "Plantel\n";
    if (pais_plantel == 0)
        msj += "PaÃ­s del plantel\n";
    if (estado_plantel == 0)
        msj += "Estado del plantel\n";
    if (ciudad_plantel == '')
        msj += "Ciudad del plantel\n";
    if (rusnies == '')
        msj += "Rusnies\n";
    if (numDeposito == '')
        msj += "NÃºmero de DepÃ³sito (voucher)\n";

    if (msj != '') {
        alert("Usted ha dejado campos vacios. Por favor verificar su informaciÃ³n\n" + msj);
    } else {
        edad = calcular_edad(fechaNac);
        if (edad < 14) {
            alert('La edad del estudiante es de ' + edad + ' aÃ±os, no puede ser inscrito en la instituciÃ³n');
            return;
        }

        if (confirm('Â¿Esta seguro que desea actualizar los datos?')) {
            AjaxRequest.post({
                'parameters': {
                    'cedula': cedula,
                    'cedula_nueva': cedula_nueva,
                    'apellidos': apellidos,
                    'nombres': nombres,
                    'fechaNac': fechaNac,
                    'pais': pais,
                    'estado': estado,
                    'ciudad': ciudad,
                    'discapacidad': discapacidad,
                    'direccion': direccion,
                    'tlf': tlf,
                    'celular': celular,
                    'email': email,
                    'anioGrad': anioGrad,
                    'promedio': promedio,
                    'titulo': titulo,
                    'plantel': plantel,
                    'pais_plantel': pais_plantel,
                    'estado_plantel': estado_plantel,
                    'ciudad_plantel': ciudad_plantel,
                    'rusnies': rusnies,
                    'numDeposito': numDeposito,
                    'accion': 'actDatosPersonales'
                },
                'onSuccess': respActualizarDatosAspirante,
                'url': 'ingreso/transaccion/transIngreso.php',
                'onError': function(req) {
                    alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
                }
            });
        }
    }
}

function respActualizarDatosAspirante(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp != false) {
        alert("Registro realizado con exito");
        limpiarFormActualizarDatos();
    } else
        alert("Error! Registro no realizado. Intentelo nuevamente");

}

function mostrarRegistro() {
    var cedula = document.getElementById("txt_cedula").value;

    AjaxRequest.post({
        'parameters': {
            'cedula': cedula,
            'accion': 'buscarRegistro'
        },
        'onSuccess': respMostrarRegistro,
        'url': 'ingreso/transaccion/transIngreso.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respMostrarRegistro(req) {
    var resp = eval("(" + req.responseText + ")");

    if (resp.length > 0) {
        var chequeo = document.getElementById("buscarAspirante");
        chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> Bachiller Registrado Como Aspirante</p>';
        var infoResultado = document.getElementById("cargarInfoResultado");
        var seleccion;
        var sw = 0;

        //crear tabla
        var tabla = document.getElementById('cargarInfoAspirante');
        // creates a <table> element and a <tbody> element
        var tbl = document.createElement("table");
        tbl.width = '100%';
        //tbl.setAttribute("id","tabla");
        var tblBody = document.createElement("tbody");

        //creamos la cabecera
        color = '#CCC';

        // creates a table row
        var row = document.createElement("tr");

        row.setAttribute('bgcolor', color);
        row.setAttribute('id', 'fila' + i);
        row.setAttribute('onMouseOver', 'estiloSobre(id)');
        row.setAttribute('onMouseOut', 'estiloDeja(id,"' + color + '")');
        row.setAttribute('class', 'fila');


        var cell0 = document.createElement("td");
        var cell1 = document.createElement("td");
        var cell2 = document.createElement("td");
        var cell3 = document.createElement("td");
        var cell4 = document.createElement("td");
        var cell5 = document.createElement("td");

        cell0.width = '4%';
        cell0.align = 'center';

        cell1.width = '40%';
        cell1.align = 'left';

        cell2.width = '4%';
        cell2.align = 'left';

        cell3.width = '10%';
        cell3.align = 'left';

        cell4.width = '10%';
        cell4.align = 'left';

        cell5.width = '10%';
        cell5.align = 'left';

        cell0.setAttribute('id', 'columna');
        cell1.setAttribute('id', 'columna');
        cell2.setAttribute('id', 'columna');
        cell3.setAttribute('id', 'columna');
        cell4.setAttribute('id', 'columna');
        cell5.setAttribute('id', 'columna');

        var cellText0 = document.createTextNode('NÂ°');
        var cellText1 = document.createTextNode('ESPECIALIDAD');
        var cellText2 = document.createTextNode('NÃšCLEO');
        var cellText3 = document.createTextNode('CIUDAD');
        var cellText4 = document.createTextNode('PERIODO');
        var cellText5 = document.createTextNode('SELECCIONADO');

        cell0.appendChild(cellText0);
        cell1.appendChild(cellText1);
        cell2.appendChild(cellText2);
        cell3.appendChild(cellText3);
        cell4.appendChild(cellText4);
        cell5.appendChild(cellText5);

        row.appendChild(cell0);
        row.appendChild(cell1);
        row.appendChild(cell2);
        row.appendChild(cell3);
        row.appendChild(cell4);
        row.appendChild(cell5);

        tblBody.appendChild(row);

        tbl.appendChild(tblBody);
        tbl.setAttribute("border", "0");
        tbl.setAttribute('class', 'tabla');

        tabla.innerHTML = '';
        tabla.appendChild(tbl);

        var pos = -1;
        for (var i = 0; i < resp.length; i++) {
            if (resp[i]['para_mi'] == 1)
                pos = i;
        }

        if (pos == -1) {
            // creating all cells
            for (var i = 0, j = 1; i < resp.length; i++, j++) {

                if (i % 2 == 0) {
                    color = '#F3F3F3';
                } else {
                    color = '#DFE4FD';
                }


                if (resp[i]['para_mi'] == 1) color = '#F5EA5F';

                // creates a table row
                var row = document.createElement("tr");

                row.setAttribute('bgcolor', color);
                row.setAttribute('id', 'fila' + i);
                row.setAttribute('onMouseOver', 'estiloSobre(id)');
                row.setAttribute('onMouseOut', 'estiloDeja(id,"' + color + '")');
                row.setAttribute('class', 'fila');


                var cell0 = document.createElement("td");
                var cell1 = document.createElement("td");
                var cell2 = document.createElement("td");
                var cell3 = document.createElement("td");
                var cell4 = document.createElement("td");
                var cell5 = document.createElement("td");

                cell0.width = '4%';
                cell0.align = 'center';

                cell1.width = '40%';
                cell1.align = 'left';

                cell2.width = '15%';
                cell2.align = 'left';

                cell3.width = '10%';
                cell3.align = 'left';

                cell4.width = '6%';
                cell4.align = 'left';

                cell5.width = '10%';
                cell5.align = 'left';

                cell0.setAttribute('id', 'columna');
                cell1.setAttribute('id', 'columna');
                cell2.setAttribute('id', 'columna');
                cell3.setAttribute('id', 'columna');
                cell4.setAttribute('id', 'columna');
                cell5.setAttribute('id', 'columna');

                var cellText0 = document.createTextNode(j);
                var cellText1 = document.createTextNode(resp[i]['especialidad']);
                var cellText2 = document.createTextNode(resp[i]['nucleo']);
                var cellText3 = document.createTextNode(resp[i]['ciudad']);
                var cellText4 = document.createTextNode(resp[i]['periodo_ing'] + "-" + resp[i]['ano_ing']);

                seleccion = '';
                if (resp[i]['para_mi'] == 1) {
                    var horario = resp[i]['horario'];
                    seleccion = 'SI';
                    sw = 1;
                    chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> Usted ha sido seleccionado como nuevo ingreso. A continuaciÃ³n mÃ¡s detalles</p>';
                    infoResultado.innerHTML = '<p><img src="imagenes/info.png" width="15"> Para ver tu cronograma, tienes disponible la opciÃ³n CRONOGRAMA en el menu</p>';
                } else {
                    seleccion = 'EN ESPERA';

                }
                var cellText5 = document.createTextNode(seleccion);

                cell0.appendChild(cellText0);
                cell1.appendChild(cellText1);
                cell2.appendChild(cellText2);
                cell3.appendChild(cellText3);
                cell4.appendChild(cellText4);
                cell5.appendChild(cellText5);

                row.appendChild(cell0);
                row.appendChild(cell1);
                row.appendChild(cell2);
                row.appendChild(cell3);
                row.appendChild(cell4);
                row.appendChild(cell5);

                tblBody.appendChild(row);

                tbl.appendChild(tblBody);
                tbl.setAttribute("border", "0");
                tbl.setAttribute('class', 'tabla');

                tabla.innerHTML = '';
                tabla.appendChild(tbl);
            }

            if (sw == 0)
                infoResultado.innerHTML = '<p><br/><img src="imagenes/info.png" width="15"> Debes estar atento a el resultado de la selecciÃ³n</p>';
        } else if (pos != -1) {
            if (resp[pos]['para_mi'] == 1) color = '#F5EA5F';

            // creates a table row
            var row = document.createElement("tr");

            row.setAttribute('bgcolor', color);
            row.setAttribute('id', 'fila' + pos);
            row.setAttribute('onMouseOver', 'estiloSobre(id)');
            row.setAttribute('onMouseOut', 'estiloDeja(id,"' + color + '")');
            row.setAttribute('class', 'fila');


            var cell0 = document.createElement("td");
            var cell1 = document.createElement("td");
            var cell2 = document.createElement("td");
            var cell3 = document.createElement("td");
            var cell4 = document.createElement("td");
            var cell5 = document.createElement("td");

            cell0.width = '4%';
            cell0.align = 'center';

            cell1.width = '40%';
            cell1.align = 'left';

            cell2.width = '15%';
            cell2.align = 'left';

            cell3.width = '10%';
            cell3.align = 'left';

            cell4.width = '6%';
            cell4.align = 'left';

            cell5.width = '10%';
            cell5.align = 'left';

            cell0.setAttribute('id', 'columna');
            cell1.setAttribute('id', 'columna');
            cell2.setAttribute('id', 'columna');
            cell3.setAttribute('id', 'columna');
            cell4.setAttribute('id', 'columna');
            cell5.setAttribute('id', 'columna');

            var cellText0 = document.createTextNode(1);
            var cellText1 = document.createTextNode(resp[pos]['especialidad']);
            var cellText2 = document.createTextNode(resp[pos]['nucleo']);
            var cellText3 = document.createTextNode(resp[pos]['ciudad']);
            var cellText4 = document.createTextNode(resp[pos]['periodo_ing'] + "-" + resp[pos]['ano_ing']);

            seleccion = '';
            if (resp[pos]['para_mi'] == 1) {
                var horario = resp[pos]['horario'];
                seleccion = 'SI';
                sw = 1;
                var ruta = "'info/info_cronograma.php', 'contenido'";
                chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> Usted ha sido seleccionado como nuevo ingreso. A continuaciÃ³n mÃ¡s detalles</p>';
                infoResultado.innerHTML = '<p><img src="imagenes/info.png" width="15"> Para ver el cronograma, pulsa <a onclick="cambiar_contenido(' + ruta + ')">AQUI</a></p>';
            } else {
                seleccion = 'EN ESPERA';

            }
            var cellText5 = document.createTextNode(seleccion);

            cell0.appendChild(cellText0);
            cell1.appendChild(cellText1);
            cell2.appendChild(cellText2);
            cell3.appendChild(cellText3);
            cell4.appendChild(cellText4);
            cell5.appendChild(cellText5);

            row.appendChild(cell0);
            row.appendChild(cell1);
            row.appendChild(cell2);
            row.appendChild(cell3);
            row.appendChild(cell4);
            row.appendChild(cell5);

            tblBody.appendChild(row);

            tbl.appendChild(tblBody);
            tbl.setAttribute("border", "0");
            tbl.setAttribute('class', 'tabla');

            tabla.innerHTML = '';
            tabla.appendChild(tbl);
        }

    } else {
        var chequeo = document.getElementById("buscarAspirante");
        chequeo.innerHTML = '<p><img src="imagenes/menos.png" width="15"> No existen registros para esta identificaciÃ³n</p>';
        var chequeo = document.getElementById("cargarInfoAspirante");
        chequeo.innerHTML = '';
        var infoResultado = document.getElementById("cargarInfoResultado");
        infoResultado.innerHTML = '';
    }
}

function imprimirHorario() {
    var identificacion = document.getElementById('txt_cedula').value;

    if (identificacion != '') {
        var url = "ingreso/horario.php?identificacion=" + identificacion;
        var ancho = 800;
        var largo = 400;
        popup(url, ancho, largo);
    } else {
        alert("Introduzca la identificaciÃ³n que desea consultar");
    }
}

function imprimirRegistro() {
    var identificacion = document.getElementById('txt_cedula').value;

    if (identificacion != '') {
        var url = "ingreso/constancia.php?identificacion=" + identificacion;
        var ancho = 100;
        var largo = 100;
        popup(url, ancho, largo);
    } else {
        alert("Introduzca la identificaciÃ³n que desea consultar");
    }
}

function consultarRegistroHorario() {
    var identificacion = document.getElementById('txt_cedula').value;

    if (identificacion != '') {
        var url = "ingreso/horario.php?identificacion=" + identificacion;
        var ancho = 100;
        var largo = 100;
        popup(url, ancho, largo);
    } else {
        alert("Introduzca la identificaciÃ³n que desea consultar");
    }
}

function limpiarFormRegistroAspirante() {
    document.getElementById("estatus").value = 0;
    cambiar_contenido('ingreso/formIngreso.php', 'contenido');
}

function limpiarFormActualizarDatos() {
    document.getElementById("estatus").value = 0;
    cambiar_contenido('ingreso/formActIngreso.php', 'contenido');
}

function limpiarConsultaAspirante() {
    var chequeo = document.getElementById("buscarAspirante");
    chequeo.innerHTML = '';
    var chequeo = document.getElementById("cargarInfoAspirante");
    chequeo.innerHTML = '';
    var infoResultado = document.getElementById("cargarInfoResultado");
    infoResultado.innerHTML = '';

    cambiar_contenido('ingreso/consultar.php', 'contenido');
}