function buscarAspiranteColaOpsu()
{
	var cedula=document.getElementById("txt_cedula").value;
	var chequeo=document.getElementById("chequearAspirante");
	
	chequeo.innerHTML= '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';
			
			var cedula=document.getElementById("txt_cedula").value;
			AjaxRequest.post(
			{
				'parameters': {'cedula':cedula,
							   'accion':'buscarEstuUdo'
							  }
							  ,'onSuccess': respEstuUdoV2
							  ,'url':'ingreso/transaccion/transIngreso.php'
							  ,'onError': function(req)
							  {
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							  }
			}
			);
}

function respEstuUdoV2(req)
{
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		document.getElementById("txt_cedula").value='';
		var chequeo=document.getElementById("chequearAspirante");
	    chequeo.innerHTML= '';
		alert("Estimado Usuario! \n\nUsted no puede realizar el registro como nuevo ingreso ya que pertenece a nuestra instituciÃ³n. Si es estudiante INACTIVO o es EGRESADO debera solicitar un reingreso. Si es estudiante ACTIVO requerira de una solicitud de traslado. Para mÃ¡s informaciÃ³n dirigirse a las oficinas de DACE de su nÃºcleo");
	}
	else
	{
		//buscar si tiene ya un registro como aspirante
		var cedula=document.getElementById("txt_cedula").value;
		AjaxRequest.post(
		{
			'parameters': {'cedula':cedula,
						   'accion':'buscarAspirante'
						  }
						  ,'onSuccess': respAspiranteV2
						  ,'url':'ingreso/transaccion/transIngreso.php'
						  ,'onError': function(req)
						  {
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						  }
		}
		);
	}
}

function respAspiranteV2(req)
{
	    
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		limpiarFormRegistroAspirante();
		alert("Estimado Usuario! \n\nUsted ya posee un registro como aspirante. Para imprimir su registro revise su correo electrÃ³nico o visite el enlace CONSULTAR ASPIRANTE");
	}
	else
	{
		//buscar asignado opsu
		var cedula=document.getElementById("txt_cedula").value;
		AjaxRequest.post(
		{
			'parameters': {'cedula':cedula,
						   'accion':'buscarColaOpsu'
						  }
						  ,'onSuccess': respBuscarColaV2
						  ,'url':'ingreso/transaccion/transIngreso.php'
						  ,'onError': function(req)
						  {
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						  }
		}
		);
	}
}



function respBuscarColaV2(req)
{
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		var msj='';var msj1='';
		 for(i=0;i<resp.length;i++)
		 {
			 msj+=resp[i]["especialidad"]+".       NÃšCLEO: "+resp[i]["nucleo"]+"\n";
			 msj1+=resp[i]["especialidad"]+".       NÃšCLEO: "+resp[i]["nucleo"]+"<br/>";
		 }
		 
		 alert("Usted se encuentra asignado a la siguiente LISTA DE COLA, segÃºn informaciÃ³n de la OPSU.\n\n"+msj);
		 if(true)
		 {
		 
			 document.getElementById("estatus").value='2';
			 
			 var chequeo=document.getElementById("chequearAspirante");
			 chequeo.innerHTML= '<p><img src="imagenes/ingresar.png" width="15"> Bachiller Asignado A lista de Cola Por Opsu</p>';
			 
			 document.getElementById("txt_apellidos").value=resp[0]["apellidos"];
			 document.getElementById("txt_nombres").value=resp[0]["nombres"];
			 document.getElementById("txt_rusnies").value=resp[0]["sni"];
			 document.getElementById("txt_promedio").value=resp[0]["promedio"];
			 
			 var opciones=document.getElementById("especialidades");
			 opciones.innerHTML='';
			 
			 //crear tabla
			 var tabla = document.getElementById('especialidadesAsignadas');
			
			 // creates a <table> element and a <tbody> element
			 var tbl     = document.createElement("table");
			 tbl.width='100%';
			 //tbl.setAttribute("id","tabla");
			 var tblBody = document.createElement("tbody");
			 
			 //creamos la cabecera
			  color='#DFE4FD';
		
							// creates a table row
							var row = document.createElement("tr");
							
							row.setAttribute('bgcolor',color);						
							row.setAttribute('id','fila'+i);
							row.setAttribute('onMouseOver','estiloSobre(id)');
							row.setAttribute('onMouseOut','estiloDeja(id,"'+color+'")');
							row.setAttribute('class','fila');
													
						
							var cell0 = document.createElement("td");
							var cell1 = document.createElement("td");
							var cell2 = document.createElement("td");
							var cell3 = document.createElement("td");
							
															
							cell0.width='4%';
							cell0.align='center';
							
							cell1.width='20%';
							cell1.align='left';
							
							cell2.width='4%';
							cell2.align='left';	
							
							cell3.width='10%';
							cell3.align='left';	
							
							cell0.setAttribute('id','columna');
							cell1.setAttribute('id','columna');
							cell2.setAttribute('id','columna');
							cell3.setAttribute('id','columna');
							
							var cellText0 = document.createTextNode('NÂ°');
							var cellText1 = document.createTextNode('ESPECIALIDAD');
							var cellText2 = document.createTextNode('POSICIÃ“N');
							var cellText3 = document.createTextNode('NÃšCLEO');
							
							cell0.appendChild(cellText0);
							cell1.appendChild(cellText1);
							cell2.appendChild(cellText2);
							cell3.appendChild(cellText3);
						
							row.appendChild(cell0);
							row.appendChild(cell1);
							row.appendChild(cell2);	
							row.appendChild(cell3);	
							
							tblBody.appendChild(row);
							
							tbl.appendChild(tblBody);
							tbl.setAttribute("border", "0");
							tbl.setAttribute('class','tabla');
							
							tabla.innerHTML='';
							tabla.appendChild(tbl);
				
				// creating all cells
				for(var i=0,j=1;i<resp.length;i++,j++)
				{												
							
							
							if(i%2==0)
							{
								color='#F3F3F3';
							}
							else
							{
								color='#DFE4FD';
							}
							// creates a table row
							var row = document.createElement("tr");
							
							row.setAttribute('bgcolor',color);						
							row.setAttribute('id','fila'+i);
							row.setAttribute('onMouseOver','estiloSobre(id)');
							row.setAttribute('onMouseOut','estiloDeja(id,"'+color+'")');
							row.setAttribute('class','fila');
													
						
							var cell0 = document.createElement("td");
							var cell1 = document.createElement("td");
							var cell2 = document.createElement("td");
							var cell3 = document.createElement("td");
							
															
							cell0.width='4%';
							cell0.align='center';
							
							cell1.width='20%';
							cell1.align='left';
							
							cell2.width='4%';
							cell2.align='left';	
							
							cell3.width='10%';
							cell3.align='left';	
							
							cell0.setAttribute('id','columna');
							cell1.setAttribute('id','columna');
							cell2.setAttribute('id','columna');
							cell3.setAttribute('id','columna');
							
							var cellText0 = document.createTextNode(j);
							var cellText1 = document.createTextNode(resp[i]['especialidad']);
							var cellText2 = document.createTextNode(resp[i]['posicion']);
							var cellText3 = document.createTextNode(resp[i]['nucleo']);
							
							cell0.appendChild(cellText0);
							cell1.appendChild(cellText1);
							cell2.appendChild(cellText2);
							cell3.appendChild(cellText3);
						
							row.appendChild(cell0);
							row.appendChild(cell1);
							row.appendChild(cell2);	
							row.appendChild(cell3);	
							
							tblBody.appendChild(row);
							
							tbl.appendChild(tblBody);
							tbl.setAttribute("border", "0");
							tbl.setAttribute('class','tabla');
							
							tabla.innerHTML='';
							tabla.appendChild(tbl);
				}
			 
			  var msj2=document.getElementById("mensaje");
			  msj2.innerHTML= '<p class="tNegro10" align="center"><img src="imagenes/info.png" width="15"> Usted ha sido asignado por CNU-OPSU a una lista de cola y esta optando a la siguientes especialidades:<br/>'+msj1+'</p>';
		 }
		 else //renuncia a la cola opsu
		 {
			  
			  var msj=document.getElementById("chequearAspirante");
			  msj.innerHTML= '';
			  document.getElementById("estatus").value='1';
			  document.getElementById("txt_cedula").value='';
			  alert("Usted ha renunciado a la cola de opsu asignada. No puede realizar su registro como aspirante");
			  return;
		 }
	}
	else {
		limpiarFormRegistroAspirante();
		alert("Usted no aparece asignado por cola de opsu. No puede realizar su registro como aspirante");
	}
}