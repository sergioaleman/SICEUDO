function buscarAspiranteConv()
{
	var cedula=document.getElementById("txt_cedula").value;
	var chequeo=document.getElementById("chequearAspirante");
	
	chequeo.innerHTML= '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';
			AjaxRequest.post(
			{
				'parameters': {'cedula':cedula,
							   'accion':'buscarEstuUdo'
							  }
							  ,'onSuccess': respEstuUdoConv
							  ,'url':'ingreso/transaccion/transIngresoConv.php'
							  ,'onError': function(req)
							  {
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							  }
			}
			);
}

function respEstuUdoConv(req)
{
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		document.getElementById("txt_cedula").value='';
		var chequeo=document.getElementById("chequearAspirante");
	    chequeo.innerHTML= '';
		alert("Estimado Usuario! \n\nEl bachiller no puede realizar el registro como nuevo ingreso ya que pertenece a nuestra instituciÃ³n. Si es estudiante INACTIVO o es EGRESADO debera solicitar un reingreso. Si es estudiante ACTIVO requerira de una solicitud de traslado");
	}
	else
	{
		//buscar si tiene ya un registro como aspirante
		var cedula=document.getElementById("txt_cedula").value;
		AjaxRequest.post(
		{
			'parameters': {'cedula':cedula,
						   'accion':'buscarAspirante'
						  }
						  ,'onSuccess': respAspiranteConv
						  ,'url':'ingreso/transaccion/transIngresoConv.php'
						  ,'onError': function(req)
						  {
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						  }
		}
		);
	}
}

function respAspiranteConv(req)
{
	    
	var resp = eval ("("+ req.responseText +")");
	if(resp.length>0)
	{
		limpiarFormRegistroAspiranteConv();
		alert("Estimado Usuario! \n\nEste bachiller ya posee un registro como aspirante. Para imprimir su registro clic en el enlace CONSULTAR ASPIRANTE");
	}
	else
	{	
		var cedula=document.getElementById("txt_cedula").value;
		var chequeo=document.getElementById("chequearAspirante");
		chequeo.innerHTML= '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando..</p>';
		
		AjaxRequest.post(
					{
						'parameters': {'cedula':cedula,
									   'accion':'buscarOtrosConvenios'
									  }
									  ,'onSuccess': respBuscarAspiranteOtrosConvenios
									  ,'url':'ingreso/transaccion/transIngreso.php'
									  ,'onError': function(req)
									  {
											alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
									  }
					}
					);
	}
}

function respBuscarAspiranteOtrosConvenios(req)
{
	var resp = eval ("("+ req.responseText +")");

	if(resp.length>0)  
	{	
		if(resp[0]['actualizo']==1)
		  msj="Estimado Usuario! \n\nEste bachiller ya posee un registro como aspirante. Para imprimir su registro clic en el enlace CONSULTAR ASPIRANTE";
		else
		  msj="Estimado Usuario! \n\nEste bachiller ya se encuentra registrado como CONVENIO. Debe actualizar sus datos para formalizar el registro";
		 
		msj+="\n\nBachiller: "+resp[0]['apellidos']+" "+resp[0]['nombres']+"\nConvenio: "+resp[0]['convenio']+"\nOficio: "+resp[0]['oficio']+"\nAgremiado: "+resp[0]['nombre_agremiado'];
		  
		limpiarFormRegistroAspiranteConv();
		alert(msj);
	}
	else
	{
		var chequeo=document.getElementById("chequearAspirante");
	    chequeo.innerHTML= '<p><img src="imagenes/ingresar.png" width="15"> OK!</p>';
		var msj=document.getElementById("mensaje");
	    msj.innerHTML= '';
		document.getElementById("txt_cedula").focus();	
	}
	
}

function validarAgremiado()
{
	var cedula=document.getElementById("txt_ced_agremiado").value;
	var chequeo=document.getElementById("chequearAgremiado");
	
	chequeo.innerHTML= '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';
			AjaxRequest.post(
			{
				'parameters': {'cedula':cedula,
							   'accion':'buscarAgremiado'
							  }
							  ,'onSuccess': respValidarAgremiado
							  ,'url':'ingreso/transaccion/transIngresoConv.php'
							  ,'onError': function(req)
							  {
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							  }
			}
			);
}

function respValidarAgremiado(req)
{
	    
	var resp = eval ("("+ req.responseText +")");
	if(resp.length==0)
	{
		var chequeo=document.getElementById("chequearAgremiado");
	    chequeo.innerHTML= '<p><img src="imagenes/menos.png" width="15"> ERROR! Verifique la cÃ©dula del agremiado</p>';
		document.getElementById("txt_ced_agremiado").focus();
		document.getElementById("txt_ced_agremiado").value='';
		document.getElementById("txt_nombre_agremiado").value='';
		alert("El nÃºmero de cÃ©dula ingresado, no pertenece a ningÃºn empleado de esta instituciÃ³n. Verifique sus datos");
	}
	else
	{
		var chequeo=document.getElementById("chequearAgremiado");
	    chequeo.innerHTML= '<p><img src="imagenes/ingresar.png" width="15"> OK!</p>';
		document.getElementById("txt_ced_agremiado").focus();
		document.getElementById("txt_nombre_agremiado").value=resp[0]['nombres'];
	}
}

function validarFormConv()
{
    var doc=document.getElementById("tipo_doc").value;
	var cedula=document.getElementById("txt_cedula").value;
	var nombres=document.getElementById("txt_nombres").value;
	var apellidos=document.getElementById("txt_apellidos").value;
	var estatus=document.getElementById("estatus").value;
	
	var oficio=document.getElementById("txt_oficio").value;
	var gremio=document.getElementById('sel_gremio').value;
	var ced_agremiado=document.getElementById('txt_ced_agremiado').value;
	var nom_agremiado=document.getElementById('txt_nombre_agremiado').value;
	
	var nucleo=document.getElementById("sel_nucleo").value;
	var especialidad=document.getElementById("sel_esp_uno").value;
	var msj="";
		
	if(nucleo==0) 	  		msj+="NÃºcleo\n";
	if(especialidad==0)	  	msj+="Especialidad\n";
	if(cedula=='')			msj+="CÃ©dula\n";
	if(nombres=='')			msj+="Nombres\n";
	if(apellidos=='')	  	msj+="Apellidos\n";
	if(oficio=='')	  		msj+="Oficio\n";
	if(gremio=='')	  		msj+="Gremio\n";
	if(ced_agremiado=='')	msj+="CÃ©dula del agremiado\n";
	if(nom_agremiado=='')	msj+="Nombre del agremiado\n";
	
	if(msj!='') alert("Usted ha dejado campos vacios. Por favor verificar su informaciÃ³n\n"+msj);
	else
	{
		if(confirm('Â¿Esta seguro que desea registrar sus datos?'))
		{
			AjaxRequest.post(
							{
									'parameters': {'cedula':cedula,
														'apellidos':apellidos,
														'nombres':nombres,
														'especialidad':especialidad,
														'nucleo':nucleo,
														'doc':doc,
														'estatus':estatus,
														'oficio':oficio,
														'gremio':gremio,
														'ced_agremiado':ced_agremiado,
														'nom_agremiado':nom_agremiado,
														'accion':'nuevoEstudiante'
														}
									,'onSuccess': respNuevoEstudianteConv
									,'url':'ingreso/transaccion/transIngresoConv.php'
									,'onError': function(req)
									{
										alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
									}
							}
							);
		}
	}
}

function respNuevoEstudianteConv(req)
{
	var resp = eval ("("+ req.responseText +")");
	if(resp==true)
	{
		alert("Registro realizado con Ã©xito! \n\nEl bachiller ahora puede ingresar su informaciÃ³n por REGISTRAR ASPIRANTE\n");
		limpiarFormRegistroAspiranteConv();
	}
	else
	    alert("Error! \nRegistro no realizado \n\nNOTA: "+resp+"\n");
	
}

function cargar_especialidades_conv() {
	var nucleo = document.getElementById("sel_nucleo").value;

	AjaxRequest.post(
						{
								'parameters': {     'nucleo':nucleo,
													'accion':'buscarEspecialidades'
													}
								,'onSuccess': resp_cargar_especialidades_conv
								,'url':'ingreso/transaccion/transIngreso.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
}

function resp_cargar_especialidades_conv(req) {
	var nucleo = document.getElementById("sel_nucleo");
	var especialidad = document.getElementById("sel_esp_uno");
	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false)
	{
		document.getElementById('sel_esp_uno').options.length = 0;
		document.getElementById('sel_esp_uno').options[0] = new Option('Seleccione...');
		document.getElementById('sel_esp_uno').options[0].value = '0';
		document.getElementById('sel_esp_uno').options[0].selected = true;
		
		var disable=false;
		var msj="";
		
		for(var i=1,j=0; i<=resp.length; i++,j++) 
		{	
			if(resp[j]['estatus']==0) { /*disable=true;*/ }
			else
			{
				if(resp[j]['condicion']!=null) msj="("+resp[j]['condicion']+")";
				else msj="";
			}
			
			document.getElementById('sel_esp_uno').options[i] = new Option(resp[j]['nombre']+"\t"+msj);
			document.getElementById('sel_esp_uno').options[i].value = resp[j]['codigo'];
			document.getElementById('sel_esp_uno').options[i].disabled=disable;
			
			disable=false;
			msj='';
		}
	}
	else
	{
		alert('No existen especialidades registrados para el nÃºcleo seleccionado');
		nucleo.value = 0;
		especialidad.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
		return;
	}
}

function imprimirRegistroConv()
{
	var identificacion=document.getElementById('txt_cedula').value;

	if(identificacion!='')
	{
		var url="ingreso/constancia.php?identificacion="+identificacion;
		var ancho=100;
		var largo=100;
		popup(url,ancho,largo);
	}
	else
	{
		alert("Introduzca la identificaciÃ³n que desea consultar");
	}
}

function limpiarFormRegistroAspiranteConv()
{
	//document.getElementById("estatus").value=3;
	cambiar_contenido('ingreso/acta_convenio.php', 'contenido');
}