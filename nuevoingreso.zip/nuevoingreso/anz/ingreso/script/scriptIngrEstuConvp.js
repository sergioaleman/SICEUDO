function buscarAspiranteConvp() {
    var cedula = document.getElementById("txt_cedula").value;
    var chequeo = document.getElementById("chequearAspirante");

    chequeo.innerHTML = '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';

    var cedula = document.getElementById("txt_cedula").value;
    AjaxRequest.post({
        'parameters': {
            'cedula': cedula,
            'accion': 'buscarEstuUdo'
        },
        'onSuccess': respEstuUdoConvp,
        'url': 'ingreso/transaccion/transIngresoConvEstu.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respEstuUdoConvp(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        document.getElementById("txt_cedula").value = '';
        var chequeo = document.getElementById("chequearAspirante");
        chequeo.innerHTML = '';
        alert("Estimado Usuario! \n\nUsted no puede realizar el registro como nuevo ingreso ya que pertenece a nuestra instituciÃ³n. Si es estudiante INACTIVO o es EGRESADO debera solicitar un reingreso. Si es estudiante ACTIVO requerira de una solicitud de traslado. Para mÃ¡s informaciÃ³n dirigirse a las oficinas de DACE de su nÃºcleo");
    } else {
        //buscar si tiene ya un registro como aspirante
        var cedula = document.getElementById("txt_cedula").value;
        AjaxRequest.post({
            'parameters': {
                'cedula': cedula,
                'accion': 'buscarAspirante'
            },
            'onSuccess': respAspiranteConvp,
            'url': 'ingreso/transaccion/transIngresoConvEstu.php',
            'onError': function(req) {
                alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
            }
        });
    }
}

function respAspiranteConvp(req) {

    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        limpiarFormRegistroAspiranteConvp();
        alert("Estimado Usuario! \n\nUsted ya posee un registro como aspirante. Para imprimir su registro revise su correo electrÃ³nico o visite el enlace CONSULTAR ASPIRANTE");
    } else {
        var chequeo = document.getElementById("chequearAspirante");
        chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> OK!</p>';
        var msj = document.getElementById("mensaje");
        msj.innerHTML = '';
        document.getElementById("txt_cedula").focus();
    }
}

function validarAgremiadop() {
    var cedula = document.getElementById("txt_ced_agremiado").value;
    var chequeo = document.getElementById("chequearAgremiado");

    chequeo.innerHTML = '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';
    AjaxRequest.post({
        'parameters': {
            'cedula': cedula,
            'accion': 'buscarAgremiado'
        },
        'onSuccess': respValidarAgremiadop,
        'url': 'ingreso/transaccion/transIngresoConvEstu.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respValidarAgremiadop(req) {

    var resp = eval("(" + req.responseText + ")");
    if (resp.length == 0) {
        var chequeo = document.getElementById("chequearAgremiado");
        chequeo.innerHTML = '<p><img src="imagenes/menos.png" width="15"> ERROR! Verifique la cÃ©dula del agremiado</p>';
        document.getElementById("txt_ced_agremiado").focus();
        document.getElementById("txt_ced_agremiado").value = '';
        document.getElementById("txt_nombre_agremiado").value = '';
        alert("El nÃºmero de cÃ©dula ingresado, no pertenece a ningÃºn empleado de esta instituciÃ³n. Verifique sus datos");
    } else {
        var chequeo = document.getElementById("chequearAgremiado");
        chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> OK!</p>';
        document.getElementById("txt_ced_agremiado").focus();
        document.getElementById("txt_nombre_agremiado").value = resp[0]['nombres'];
    }
}

function validarFormConvp() {
    var doc = document.getElementById("tipo_doc").value;
    var cedula = document.getElementById("txt_cedula").value;
    var nombres = document.getElementById("txt_nombres").value;
    var apellidos = document.getElementById("txt_apellidos").value;
    var sexo = document.getElementById("sel_sexo").value;
    var tipoSangre = document.getElementById("sel_tipo_sangre").value;
    var edoCivil = document.getElementById("sel_edo_civil").value;
    var nacionalidad = document.getElementById("sel_nacionalidad").value;
    var fechaNac = document.getElementById("txt_fecha_nac").value;
    var etnia = document.getElementById("sel_etnia").value;
    var pais = document.getElementById("sel_pais").value;
    var estado = document.getElementById("sel_estado").value;
    var ciudad = document.getElementById("txt_ciudad").value;
    var condicion = document.getElementById("sel_condicion").value;
    var libertad = document.getElementById("sel_libertad").value;
    var discapacidad = document.getElementById("sel_discapacidad").value;
    var direccion = document.getElementById("txt_direccion").value;
    var tlf = document.getElementById("txt_telefono").value;
    var celular = document.getElementById("txt_celular").value;
    var email = document.getElementById("txt_email").value;
    var anioGrad = document.getElementById("sel_graduacion").value;
    var becado = document.getElementById("sel_becado").value;
    var promedio = document.getElementById("txt_promedio").value;
    var titulo = document.getElementById("sel_titulo").value;
    var numDeposito = document.getElementById("txt_num_deposito").value;
    var plantel = document.getElementById("txt_plantel").value;
    var rusnies = document.getElementById("txt_rusnies").value;
    var estatus = document.getElementById("estatus").value;

    var pais_plantel = document.getElementById("sel_pais_plantel").value;
    var estado_plantel = document.getElementById("sel_estado_plantel").value;
    var ciudad_plantel = document.getElementById("txt_ciudad_plantel").value;

    var gremio = document.getElementById('sel_gremio').value;
    var ced_agremiado = document.getElementById('txt_ced_agremiado').value;
    var nom_agremiado = document.getElementById('txt_nombre_agremiado').value;
    var parentesco = document.getElementById('sel_parentesco').value;
    var tlf_agremiado = document.getElementById('txt_telefono_agremiado').value;

    var especialidad = '';
    var nucleo = '';
    var msj = "";

    nucleo = document.getElementById("sel_nucleo").value;
    var especialidad = document.getElementById("sel_esp_uno").value;

    if (nucleo == 0)
        msj += "NÃºcleo\n";
    if (especialidad == 0)
        msj += "Especialidad\n";
    if (cedula == '')
        msj += "CÃ©dula\n";
    if (nombres == '')
        msj += "Nombres\n";
    if (apellidos == '')
        msj += "Apellidos\n";
    if (sexo == 0)
        msj += "Sexo\n";
    if (tipoSangre == 0)
        msj += "Tipo de Sangre\n";
    if (edoCivil == 0)
        msj += "Estado Civil\n";
    if (nacionalidad == 0)
        msj += "Nacionalidad\n";
    if (fechaNac == '')
        msj += "Fecha de Nacimiento\n";
    if (etnia == '00')
        msj += "Etnia\n";
    if (pais == 0)
        msj += "PaÃ­s\n";
    if (estado == 0)
        msj += "Estado\n";
    if (ciudad == '')
        msj += "Ciudad\n";
    if (condicion == 0)
        msj += "CondiciÃ³n\n";
    if (libertad == 0)
        msj += "Libertad\n";
    if (discapacidad == '00')
        msj += "Discapacidad\n";
    if (direccion == '')
        msj += "DirecciÃ³n\n";
    if (tlf == '' || celular == '')
        msj += "TelÃ©fono o Celular\n";
    if (email == '')
        msj += "Email\n";
    if (anioGrad == 0)
        msj += "AÃ±o de GraduaciÃ³n\n";
    if (becado == 0)
        msj += "Becado\n";
    if (promedio == '')
        msj += "Promedio\n";
    if (titulo == '')
        msj += "Titulo\n";
    if (plantel == '')
        msj += "Plantel\n";
    if (pais_plantel == 0)
        msj += "PaÃ­s del plantel\n";
    if (estado_plantel == 0)
        msj += "Estado del plantel\n";
    if (ciudad_plantel == '')
        msj += "Ciudad del plantel\n";
    if (gremio == '')
        msj += "Gremio\n";
    if (ced_agremiado == '')
        msj += "CÃ©dula del agremiado\n";
    if (nom_agremiado == '')
        msj += "Nombre del agremiado\n";
    if (tlf_agremiado == '')
        msj += "TelÃ©fono de agremiado\n";


    if (msj != '') {
        alert("Usted ha dejado campos vacios. Por favor verificar su informaciÃ³n\n" + msj);
    } else {
        edad = calcular_edad(fechaNac);
        if (edad < 14) {
            alert('La edad del estudiante es de ' + edad + ' aÃ±os, no puede ser inscrito en la instituciÃ³n');
            return;
        }
        msj = "\nCEDULA: " + cedula + "\nNOMBRE: " + nombres + " " + apellidos + "\nCORREO: " + email + "\n\nNota: Si algunos de los datos es incorrecto presionar cancelar para corregir";
        if (confirm('Â¿Esta seguro que desea registrar sus datos?')) {
            AjaxRequest.post({
                'parameters': {
                    'cedula': cedula,
                    'apellidos': apellidos,
                    'nombres': nombres,
                    'especialidad': especialidad,
                    'nucleo': nucleo,
                    'fechaNac': fechaNac,
                    'sexo': sexo,
                    'edoCivil': edoCivil,
                    'nacionalidad': nacionalidad,
                    'direccion': direccion,
                    'tlf': tlf,
                    'email': email,
                    'titulo': titulo,
                    'anioGrad': anioGrad,
                    'pais': pais,
                    'estado': estado,
                    'ciudad': ciudad,
                    'celular': celular,
                    'promedio': promedio,
                    'plantel': plantel,
                    'numDeposito': numDeposito,
                    'tipoSangre': tipoSangre,
                    'doc': doc,
                    'condicion': condicion,
                    'etnia': etnia,
                    'becado': becado,
                    'libertad': libertad,
                    'rusnies': rusnies,
                    'estatus': estatus,
                    'discapacidad': discapacidad,
                    'pais_plantel': pais_plantel,
                    'estado_plantel': estado_plantel,
                    'ciudad_plantel': ciudad_plantel,
                    'gremio': gremio,
                    'ced_agremiado': ced_agremiado,
                    'nom_agremiado': nom_agremiado,
                    'parentesco': parentesco,
                    'tlf_agremiado': tlf_agremiado,
                    'accion': 'nuevoEstudiante'
                },
                'onSuccess': respNuevoEstudianteConvp,
                'url': 'ingreso/transaccion/transIngresoConvEstu.php',
                'onError': function(req) {
                    alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
                }
            });
        }
    }
}

function respNuevoEstudianteConvp(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        alert("Registro realizado con exito. \n\nSe ha enviado un correo electrÃ³nico con la informaciÃ³n de su solicitud. Para mÃ¡s detalles ir a CONSULTAR ASPIRANTE\n\n");
        limpiarFormRegistroAspiranteConvp();
    } else
        alert("Error! Registro no realizado. Intentelo nuevamente");

}

function cargarEspConvEstup() {
    var nucleo = document.getElementById("sel_nucleo").value;

    AjaxRequest.post({
        'parameters': {
            'nucleo': nucleo,
            'accion': 'buscarEspecialidades'
        },
        'onSuccess': respCargarEspConvEstup,
        'url': 'ingreso/transaccion/transIngresoConvEstu.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respCargarEspConvEstup(req) {
    var nucleo = document.getElementById("sel_nucleo");
    var especialidad = document.getElementById("sel_esp_uno");

    var resp = eval("(" + req.responseText + ")");
    if (resp != false) {
        document.getElementById('sel_esp_uno').options.length = 0;
        document.getElementById('sel_esp_uno').options[0] = new Option('Seleccione...');
        document.getElementById('sel_esp_uno').options[0].value = '0';
        document.getElementById('sel_esp_uno').options[0].selected = true;

        var disable = false;

        for (var i = 1, j = 0; i <= resp.length; i++, j++) {
            if (resp[j]['estatus'] == 0) {
                disable = true;
            }

            if (resp[j]['condicion'] != null)
                msj = "(" + resp[j]['condicion'] + ")";
            else
                msj = "";

            document.getElementById('sel_esp_uno').options[i] = new Option(resp[j]['nombre'] + "\t" + msj);
            document.getElementById('sel_esp_uno').options[i].value = resp[j]['codigo'];
            document.getElementById('sel_esp_uno').options[i].disabled = disable;

            disable = false;
            msj = '';
        }
    } else {
        alert('No existen especialidades registrados para el nÃºcleo seleccionado');
        nucleo.value = 0;
        especialidad.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
        return;
    }
}

function cargarEstadosEstuConvp() {
    var pais = document.getElementById("sel_pais").value;

    AjaxRequest.post({
        'parameters': {
            'pais': pais,
            'accion': 'buscarEstados'
        },
        'onSuccess': respCargarEstadosEstuConvp,
        'url': 'ingreso/transaccion/transIngresoConvEstu.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respCargarEstadosEstuConvp(req) {
    var pais = document.getElementById("sel_pais");
    var estado = document.getElementById("sel_estado");
    var resp = eval("(" + req.responseText + ")");

    if (resp != false) {
        document.getElementById('sel_estado').options.length = 0;
        document.getElementById('sel_estado').options[0] = new Option('Seleccione...');
        document.getElementById('sel_estado').options[0].value = '0';
        document.getElementById('sel_estado').options[0].selected = true;

        for (var i = 1, j = 0; i <= resp.length; i++, j++) {
            document.getElementById('sel_estado').options[i] = new Option(resp[j]['descripcion']);
            document.getElementById('sel_estado').options[i].value = resp[j]['cod_estado'];
        }
    } else {
        estado.innerHTML = '<OPTION value="999">EXTRANJERO</OPTION>';
        return;
    }
}

function cargarEstadosEstuConvPlantelp() {
    var pais = document.getElementById("sel_pais_plantel").value;

    AjaxRequest.post({
        'parameters': {
            'pais': pais,
            'accion': 'buscarEstados'
        },
        'onSuccess': respCargarEstadosEstuConvPlantelp,
        'url': 'ingreso/transaccion/transIngresoConvEstu.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respCargarEstadosEstuConvPlantelp(req) {
    var pais = document.getElementById("sel_pais_plantel");
    var estado = document.getElementById("sel_estado_plantel");

    var resp = eval("(" + req.responseText + ")");
    if (resp != false) {
        document.getElementById('sel_estado_plantel').options.length = 0;
        document.getElementById('sel_estado_plantel').options[0] = new Option('Seleccione...');
        document.getElementById('sel_estado_plantel').options[0].value = '0';
        document.getElementById('sel_estado_plantel').options[0].selected = true;

        for (var i = 1, j = 0; i <= resp.length; i++, j++) {
            document.getElementById('sel_estado_plantel').options[i] = new Option(resp[j]['descripcion']);
            document.getElementById('sel_estado_plantel').options[i].value = resp[j]['cod_estado'];
        }
    } else {
        estado.innerHTML = '<OPTION value="999">EXTRANJERO</OPTION>';
        return;
    }
}

function verificarDepositoEstuConvp(num) {
    var chequeo = document.getElementById("chequearDeposito");
    chequeo.innerHTML = '<p><img src="imagenes/cargando3.gif" width="15"> Chequeando</p>';
    AjaxRequest.post({
        'parameters': {
            'num': num,
            'accion': 'buscarDeposito'
        },
        'onSuccess': respVerificarDepositoEstuConvp,
        'url': 'ingreso/transaccion/transIngresoConvEstu.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respVerificarDepositoEstuConvp(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        alert("El nÃºmero de depÃ³sito que esta registrando, ya se encuentra en uso por otro usuario, por favor indique uno nuevo");
        var chequeo = document.getElementById("chequearDeposito");
        chequeo.innerHTML = '';
        document.getElementById("txt_num_deposito").value = '';
    } else {
        var chequeo = document.getElementById("chequearDeposito");
        chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> OK!</p>';
    }
}

function mostrarRegistroEstuConvp() {
    var cedula = document.getElementById("txt_cedula").value;

    AjaxRequest.post({
        'parameters': {
            'cedula': cedula,
            'accion': 'buscarRegistro'
        },
        'onSuccess': respMostrarRegistroEstuConvp,
        'url': 'ingreso/transaccion/transIngresoConvEstu.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respMostrarRegistroEstuConvp(req) {
    var resp = eval("(" + req.responseText + ")");
    if (resp.length > 0) {
        var chequeo = document.getElementById("buscarAspirante");
        chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> Bachiller Registrado Como Aspirante</p>';
        var infoResultado = document.getElementById("cargarInfoResultado");
        var infoHorario = document.getElementById("cargarInfoHorario");
        var seleccion;
        var sw = 0;

        //crear tabla
        var tabla = document.getElementById('cargarInfoAspirante');
        // creates a <table> element and a <tbody> element
        var tbl = document.createElement("table");
        tbl.width = '100%';
        //tbl.setAttribute("id","tabla");
        var tblBody = document.createElement("tbody");

        //creamos la cabecera
        color = '#DFE4FD';

        // creates a table row
        var row = document.createElement("tr");

        row.setAttribute('bgcolor', color);
        row.setAttribute('id', 'fila' + i);
        row.setAttribute('onMouseOver', 'estiloSobre(id)');
        row.setAttribute('onMouseOut', 'estiloDeja(id,"' + color + '")');
        row.setAttribute('class', 'fila');


        var cell0 = document.createElement("td");
        var cell1 = document.createElement("td");
        var cell2 = document.createElement("td");
        var cell3 = document.createElement("td");
        var cell4 = document.createElement("td");
        var cell5 = document.createElement("td");
        var cell6 = document.createElement("td");

        cell0.width = '4%';
        cell0.align = 'center';

        cell1.width = '40%';
        cell1.align = 'left';

        cell2.width = '4%';
        cell2.align = 'left';

        cell3.width = '10%';
        cell3.align = 'left';

        cell4.width = '10%';
        cell4.align = 'left';

        cell5.width = '10%';
        cell5.align = 'left';

        cell0.setAttribute('id', 'columna');
        cell1.setAttribute('id', 'columna');
        cell2.setAttribute('id', 'columna');
        cell3.setAttribute('id', 'columna');
        cell4.setAttribute('id', 'columna');
        cell5.setAttribute('id', 'columna');
        cell6.setAttribute('id', 'columna');

        var cellText0 = document.createTextNode('NÂ°');
        var cellText1 = document.createTextNode('ESPECIALIDAD');
        var cellText2 = document.createTextNode('NÃšCLEO');
        var cellText3 = document.createTextNode('CIUDAD');
        var cellText4 = document.createTextNode('PERIODO');
        var cellText5 = document.createTextNode('SELECCIONADO');
        var cellText6 = document.createTextNode('OBSERVACIÃ“N');

        cell0.appendChild(cellText0);
        cell1.appendChild(cellText1);
        cell2.appendChild(cellText2);
        cell3.appendChild(cellText3);
        cell4.appendChild(cellText4);
        cell5.appendChild(cellText5);
        cell6.appendChild(cellText6);

        row.appendChild(cell0);
        row.appendChild(cell1);
        row.appendChild(cell2);
        row.appendChild(cell3);
        row.appendChild(cell4);
        row.appendChild(cell5);
        row.appendChild(cell6);

        tblBody.appendChild(row);

        tbl.appendChild(tblBody);
        tbl.setAttribute("border", "0");
        tbl.setAttribute('class', 'tabla');

        tabla.innerHTML = '';
        tabla.appendChild(tbl);

        bandera = -1;
        for (var i = 0, j = 1; i < resp.length; i++, j++) {
            if (resp[i]['para_mi'] == 1) {
                bandera = i;
                i = resp.length;
            }
        }

        if (bandera != -1) {
            // creating all cells
            var i = bandera;
            var j = 1;
            color = '#F3F3F3';
            var row = document.createElement("tr");

            row.setAttribute('bgcolor', color);
            row.setAttribute('id', 'fila' + i);
            row.setAttribute('onMouseOver', 'estiloSobre(id)');
            row.setAttribute('onMouseOut', 'estiloDeja(id,"' + color + '")');
            row.setAttribute('class', 'fila');


            var cell0 = document.createElement("td");
            var cell1 = document.createElement("td");
            var cell2 = document.createElement("td");
            var cell3 = document.createElement("td");
            var cell4 = document.createElement("td");
            var cell5 = document.createElement("td");
            var cell6 = document.createElement("td");

            cell0.width = '4%';
            cell0.align = 'center';

            cell1.width = '40%';
            cell1.align = 'left';

            cell2.width = '15%';
            cell2.align = 'left';

            cell3.width = '10%';
            cell3.align = 'left';

            cell4.width = '6%';
            cell4.align = 'left';

            cell5.width = '10%';
            cell5.align = 'left';

            cell6.width = '10%';
            cell6.align = 'left';

            cell0.setAttribute('id', 'columna');
            cell1.setAttribute('id', 'columna');
            cell2.setAttribute('id', 'columna');
            cell3.setAttribute('id', 'columna');
            cell4.setAttribute('id', 'columna');
            cell5.setAttribute('id', 'columna');
            cell6.setAttribute('id', 'columna');

            var cellText0 = document.createTextNode(j);
            var cellText1 = document.createTextNode(resp[i]['especialidad']);
            var cellText2 = document.createTextNode(resp[i]['nucleo']);
            var cellText3 = document.createTextNode(resp[i]['ciudad']);
            var cellText4 = document.createTextNode(resp[i]['periodo_ing'] + "-" + resp[i]['ano_ing']);

            var horario = resp[i]['horario'];
            var documentos = resp[i]['documentos'];
            var instructivo = 'N/A';
            seleccion = 'PRESELECCIONADO';
            prioridad = 'N/A';

            var cellText5 = document.createTextNode(seleccion);
            var cellText6 = document.createTextNode(prioridad);

            sw = 1;
            chequeo.innerHTML = '<p><img src="imagenes/ingresar.png" width="15"> Usted ha sido seleccionado como nuevo ingreso. A continuaciÃ³n mÃ¡s detalles</p>';

            if (resp[i]['estatus'] == 1) {
                //infoResultado.innerHTML= '<p><img src="imagenes/info.png" width="15"> Si fuiste SELECCIONADO (POBLACIÃ“N FLOTANTE), imprime tu planilla de ENVIO DE DOCUMENTOS la cual es necesaria para ser presentada en las oficinas de Control de Estudios de acuerdo al cronograma<br/><a href="https://drive.google.com/file/d/0B7B3X0luJx7RR2lkNGJRTTBQU1E/view?usp=sharing" target="blank"> Descarga tu Planilla Aqui</a></p>';
                infoResultado.innerHTML = '<p><img src="imagenes/info.png" width="15"><a onclick="imprimirRegistroEstu()" target="blank"> Descarga tu Planilla de registro aqui</a></p>';
            } else if (resp[i]['estatus'] == 0) {
                //infoResultado.innerHTML= '<p><img src="imagenes/info.png" width="15"><a href="https://drive.google.com/file/d/0B7B3X0luJx7RWldvZ0ZlR05TdjROVU1fcVNDMndDWDFZTUpn/view?usp=sharing" target="blank"> Descarga tu Planilla Aqui</a></p>';
                infoResultado.innerHTML = '<p><img src="imagenes/info.png" width="15"><a onclick="imprimirRegistroEstu()" target="blank"> Descarga tu Planilla de registro aqui</a></p>';
            }


            if (horario != '' && documentos != 0) {
                infoHorario.innerHTML = '<p><img src="imagenes/check.jpg" width="15"><a href="' + horario + '" target="blank"> Tus documentos han sido registrados. Debes estar atento a la publicacion del horario</a></p>';
            }
            //else
            //infoHorario.innerHTML= '<p><img src="imagenes/info.png" width="15"><a href="'+instructivo+'" target="blank"> Descarga tu Planilla Aqui</a></p>';

            cell0.appendChild(cellText0);
            cell1.appendChild(cellText1);
            cell2.appendChild(cellText2);
            cell3.appendChild(cellText3);
            cell4.appendChild(cellText4);
            cell5.appendChild(cellText5);
            cell6.appendChild(cellText6);

            row.appendChild(cell0);
            row.appendChild(cell1);
            row.appendChild(cell2);
            row.appendChild(cell3);
            row.appendChild(cell4);
            row.appendChild(cell5);
            row.appendChild(cell6);

            tblBody.appendChild(row);

            tbl.appendChild(tblBody);
            tbl.setAttribute("border", "0");
            tbl.setAttribute('class', 'tabla');

            tabla.innerHTML = '';
            tabla.appendChild(tbl);
        } else {
            // creating all cells
            for (var i = 0, j = 1; i < resp.length; i++, j++) {

                if (i % 2 == 0) {
                    color = '#F3F3F3';
                } else {
                    color = '#DFE4FD';
                }
                // creates a table row
                var row = document.createElement("tr");

                row.setAttribute('bgcolor', color);
                row.setAttribute('id', 'fila' + i);
                row.setAttribute('onMouseOver', 'estiloSobre(id)');
                row.setAttribute('onMouseOut', 'estiloDeja(id,"' + color + '")');
                row.setAttribute('class', 'fila');


                var cell0 = document.createElement("td");
                var cell1 = document.createElement("td");
                var cell2 = document.createElement("td");
                var cell3 = document.createElement("td");
                var cell4 = document.createElement("td");
                var cell5 = document.createElement("td");
                var cell6 = document.createElement("td");

                cell0.width = '4%';
                cell0.align = 'center';

                cell1.width = '40%';
                cell1.align = 'left';

                cell2.width = '10%';
                cell2.align = 'left';

                cell3.width = '12%';
                cell3.align = 'left';

                cell4.width = '4%';
                cell4.align = 'left';

                cell5.width = '12%';
                cell5.align = 'left';

                cell6.width = '15%';
                cell6.align = 'left';

                cell0.setAttribute('id', 'columna');
                cell1.setAttribute('id', 'columna');
                cell2.setAttribute('id', 'columna');
                cell3.setAttribute('id', 'columna');
                cell4.setAttribute('id', 'columna');
                cell5.setAttribute('id', 'columna');
                cell6.setAttribute('id', 'columna');

                var cellText0 = document.createTextNode(j);
                var cellText1 = document.createTextNode(resp[i]['especialidad']);
                var cellText2 = document.createTextNode(resp[i]['nucleo']);
                var cellText3 = document.createTextNode(resp[i]['ciudad']);
                var cellText4 = document.createTextNode(resp[i]['periodo_ing'] + "-" + resp[i]['ano_ing']);

                seleccion = 'EN ESPERA';
                infoResultado.innerHTML = '<p><img src="imagenes/info.png" width="15"><a onclick="imprimirRegistroEstu()" target="blank"> Descarga tu Planilla de registro aqui</a></p>';

                //if(resp[i]['fecha_ing']>='2017-03-21')
                //seleccion='EN ESPERA';

                var cellText5 = document.createTextNode(seleccion);
                var cellText6 = document.createTextNode(resp[i]['observacion']);

                cell0.appendChild(cellText0);
                cell1.appendChild(cellText1);
                cell2.appendChild(cellText2);
                cell3.appendChild(cellText3);
                cell4.appendChild(cellText4);
                cell5.appendChild(cellText5);
                cell6.appendChild(cellText6);

                row.appendChild(cell0);
                row.appendChild(cell1);
                row.appendChild(cell2);
                row.appendChild(cell3);
                row.appendChild(cell4);
                row.appendChild(cell5);
                row.appendChild(cell6);

                tblBody.appendChild(row);

                tbl.appendChild(tblBody);
                tbl.setAttribute("border", "0");
                tbl.setAttribute('class', 'tabla');

                tabla.innerHTML = '';
                tabla.appendChild(tbl);
            }

            //if(sw==0)
            //infoResultado.innerHTML= '<p><br/><img src="imagenes/info.png" width="15"> Puedes imprimir la planilla de registro. Debe esperar el resultado del proceso de selecciÃ³n</p>';	
        }
    } else {
        var chequeo = document.getElementById("buscarAspirante");
        chequeo.innerHTML = '<p><img src="imagenes/menos.png" width="15"> No existen registros para esta identificaciÃ³n</p>';
        var chequeo = document.getElementById("cargarInfoAspirante");
        chequeo.innerHTML = '';
        var infoResultado = document.getElementById("cargarInfoResultado");
        infoResultado.innerHTML = '';
    }
}

function cargarEspEstup() {
    var nucleo = document.getElementById("sel_nucleo").value;

    AjaxRequest.post({
        'parameters': {
            'nucleo': nucleo,
            'accion': 'buscarEspecialidades'
        },
        'onSuccess': respCargarEspEstup,
        'url': 'ingreso/transaccion/transIngresoConvEstu.php',
        'onError': function(req) {
            alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
        }
    });
}

function respCargarEspEstup(req) {
    var nucleo = document.getElementById("sel_nucleo");
    var esp1 = document.getElementById("sel_esp_uno");

    var resp = eval("(" + req.responseText + ")");
    if (resp != false) {
        document.getElementById('sel_esp_uno').options.length = 0;
        document.getElementById('sel_esp_uno').options[0] = new Option('Seleccione...');
        document.getElementById('sel_esp_uno').options[0].value = '0';
        document.getElementById('sel_esp_uno').options[0].selected = true;

        var disable = false;

        for (var i = 1, j = 0; i <= resp.length; i++, j++) {
            if (resp[j]['estatus'] == 0) {
                disable = true;
            }

            if (resp[j]['condicion'] != null)
                msj = "(" + resp[j]['condicion'] + ")";
            else
                msj = "";

            document.getElementById('sel_esp_uno').options[i] = new Option(resp[j]['nombre'] + "\t" + msj);
            document.getElementById('sel_esp_uno').options[i].value = resp[j]['codigo'];
            document.getElementById('sel_esp_uno').options[i].disabled = disable;

            disable = false;
            msj = '';
        }
    } else {
        alert('No existen especialidades registrados para el nÃºcleo seleccionado');
        nucleo.value = 0;
        esp1.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
        esp2.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
        esp3.innerHTML = '<OPTION value="0">Seleccione...</OPTION>';
        return;
    }
}

function imprimirRegistroEstup() {
    var identificacion = document.getElementById('txt_cedula').value;

    if (identificacion != '') {
        var url = "ingreso/constancia_estu.php?identificacion=" + identificacion;
        var ancho = 100;
        var largo = 100;
        popup(url, ancho, largo);
    } else {
        alert("Introduzca la identificaciÃ³n que desea consultar");
    }
}

function limpiarFormRegistroAspiranteConvp() {
    cambiar_contenido('ingreso/formActaConv.php', 'contenido');
}