function mostrarRegistroRecaudos()
{ 
	var cedula=document.getElementById("txt_cedula").value;
	AjaxRequest.post(
		{
			'parameters': {'cedula':cedula,
						   'accion':'buscarRecaudos'
						  }
						  ,'onSuccess': respMostrarRegistroRecaudos
						  ,'url':'ingreso/transaccion/transIngresoRecaudos.php'
						  ,'onError': function(req)
						  {
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						  }
		}
		);
}

function respMostrarRegistroRecaudos(req)
{
	
	var aspirante=document.getElementById("buscarAspirante");
	var infoAspirante = document.getElementById('cargarInfoAspirante');
	var infoResultado=document.getElementById("cargarInfoResultado");
	var resp = eval ("("+ req.responseText +")");
	if(resp.length<=0) {
		 aspirante.innerHTML= '<p><img src="imagenes/menos.png" width="15"> No existen registros para esta identificaciÃ³n</p>';
		 infoAspirante.innerHTML= '';		 
	}
	else
	{
		var sw=0;
	    for(var i=0;i<resp.length;i++) {
			if(resp[i]['para_mi']==1 || resp[i]['gremio']!='NO') {
				sw=1;
				aspirante.innerHTML= '<p><img src="imagenes/ingresar.png" width="15"> Usted ha sido seleccionado como nuevo ingreso.<br>Debe enviar los siguientes recaudos:</p>';
			}
		}
		if(sw==0) {
			aspirante.innerHTML= '<p><img src="imagenes/info.png" width="15"> Usted no ha sido seleccionado aÃºn.</p>';
		    infoAspirante.innerHTML= '';
		}
		 else {
			 var tbl     = document.createElement("table");
			 tbl.width='100%';
			 var tblBody = document.createElement("tbody");
			 
			 // fila 1
				for(var i=0,j=1;i<resp.length;i++,j++)
				{												
							
					if(i%2==0)
						color='#F3F3F3';
					else
						color='#DFE4FD';

					// creates a table row
					var row = document.createElement("tr");		
					row.setAttribute('bgcolor',color);						
					row.setAttribute('id','fila'+i);
					row.setAttribute('onMouseOver','estiloSobre(id)');
					row.setAttribute('onMouseOut','estiloDeja(id,"'+color+'")');
					row.setAttribute('class','fila');
																
					var cell0 = document.createElement("td");
					var cell1 = document.createElement("td");
															
					cell0.width='50%';
					cell0.align='left';
							
					cell1.width='50%';
					cell1.align='left';
														
					cell0.setAttribute('id','columna');
					cell1.setAttribute('id','columna');
							
					var cellText0 = document.createTextNode(resp[i]['descrip']);
					var cellFile1=document.createElement('input');
					cellFile1.type="file";
					cellFile1.name="recaudo"+resp[i]['codigo'];
					switch (resp[i]['enviado']) {
					case "1": var cellText1 = document.createTextNode("recaudo enviado."); break;	
					case "2": var cellText1 = document.createTextNode("error: hubo un error durante el envio"); break;						
					case "3": var cellText1 = document.createTextNode("error: el archivo debe tener menos de 100Kb"); break;						
					case "4": var cellText1 = document.createTextNode("error: solo se aceptan archivos .JPG"); break;						
					default:  var cellText1 = document.createTextNode(""); break;
					}
							
					cell0.appendChild(cellText0);
					cell1.appendChild(cellText1);
					if(resp[i]['enviado']!="1")
						cell1.appendChild(cellFile1);
					row.appendChild(cell0);
					row.appendChild(cell1);
							
					tblBody.appendChild(row);
							
					tbl.appendChild(tblBody);
					tbl.setAttribute("border", "0");
					tbl.setAttribute('class','tabla');
							
					infoAspirante.innerHTML='';
					infoAspirante.appendChild(tbl);
				}
		 }
	}
}

function enviarRecaudos()
{
	document.frmrecaudos.submit();
}

function limpiarRecaudos()
{
	var aspirante=document.getElementById("buscarAspirante");
    aspirante.innerHTML= '';
	var infoAspirante=document.getElementById("cargarInfoAspirante");
	infoAspirante.innerHTML= '';
	var infoResultado=document.getElementById("cargarInfoResultado");
	infoResultado.innerHTML= '';
	
	cambiar_contenido('ingreso/recaudos.php', 'contenido');
}