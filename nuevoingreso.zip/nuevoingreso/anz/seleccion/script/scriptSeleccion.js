function listado_proceso_seleccion(nuc,id_proc)
{
	var url="seleccion/listado_seleccion.php?tipoListado="+id_proc+"&codNucleo="+nuc;
	popup(url,50,50);
}

function listado_revision_seleccion(nuc)
{
	var url="seleccion/listado_revision.php?codNucleo="+nuc;
	popup(url,50,50);
}

function proceso_seleccion(nuc,id_proc)
{
	var mensaje=document.getElementById("mensaje"+id_proc);
	mensaje.innerHTML = "...";
	
	if(confirm('Seguro que desea ejecutar este proceso?'))
	{
			AjaxRequest.post(
						{
							'parameters': {	'nuc':nuc,
											'id_proc':id_proc
										  }
							,'onSuccess': function(req){resp_proceso_seleccion(req,id_proc)}
							,'url':'seleccion/transaccion/transSeleccion.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							}
						}
						);
	}
}

function proceso_seleccion14(nuc,esp,id_item)
{
	var mensaje=document.getElementById("mensaje14");
	mensaje.innerHTML = "...";
	var val=document.getElementById(id_item).value;
	var id_proc=14;
	if(confirm('Seguro que desea actualizar este cupo?'))
	{
		AjaxRequest.post(
						{
							'parameters': {	'nuc':nuc,
											'esp':esp,
											'val':val,
											'id_proc':id_proc
										  }
							,'onSuccess': function(req){resp_proceso_seleccion(req,id_proc)}
							,'url':'seleccion/transaccion/transSeleccion.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							}
						}
						);
	}
}


function proceso_seleccion24(nuc)
{
	var mensaje=document.getElementById("mensaje24");
	mensaje.innerHTML = "...";
	var ced=document.getElementById("cedula24").value;
	var obs=document.getElementById("observ24").value;
	var id_proc=24;
	
	if(confirm('Seguro que desea registrar esta objecion?'))
	{
			AjaxRequest.post(
						{
							'parameters': {	'nuc':nuc,
											'ced':ced,
											'obs':obs,
											'id_proc':id_proc
										  }
							,'onSuccess': function(req){resp_proceso_seleccion(req,id_proc)}
							,'url':'seleccion/transaccion/transSeleccion.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							}
						}
						);
	}
}

function proceso_seleccion25(nuc)
{
	var mensaje=document.getElementById("mensaje25");
	mensaje.innerHTML = "...";
	var ced=document.getElementById("cedula25").value;
	var prm=document.getElementById("promedio25").value;
	var id_proc=25;
	
	if(confirm('Seguro que desea registrar esta objecion?'))
	{
			AjaxRequest.post(
						{
							'parameters': {	'nuc':nuc,
											'ced':ced,
											'prm':prm,
											'id_proc':id_proc
										  }
							,'onSuccess': function(req){resp_proceso_seleccion(req,id_proc)}
							,'url':'seleccion/transaccion/transSeleccion.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
							}
						}
						);
	}
}

function resp_proceso_seleccion(req,id_proc)
{ 
	var mensaje=document.getElementById("mensaje"+id_proc);
	var resp = eval ("("+ req.responseText +")");
	if(resp[0].estatus=="OK") mensaje.innerHTML = resp[0].mensaje;
	else mensaje.innerHTML = "<font color=red>"+resp[0].mensaje+"</font>";
}