function consultaEgresado() {
	var cedula = document.getElementById("cedula").value;
	var nacionalidad = document.getElementById("nacionalidad").value;
	var operacion = "buscarEgresado";
	
	if (cedula == '') {
		swal({title: '', text: 'Debes ingresar el nÃºmero de cÃ©dula', animation: false});
		return;
	}
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"cedula":cedula,
			"nacionalidad":nacionalidad,
			"operacion":operacion
		 }
		,'onSuccess':respconsultaEgresado
		,'url':'consulta/transaccion/transConsulta.php'
		,'onError':function(req)
			{
				swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
			}
		}
	);
}

function respconsultaEgresado(req)
{
	var resp = eval ("("+ req.responseText +")");
	
	if (resp.length > 0) {
		document.getElementById("nombres").value = resp[0]["nombres"];
		document.getElementById("apellidos").value = resp[0]["apellidos"];
		consultaTitulos(resp[0]["cedula"]);
	}
	else {
		swal({
			  title: "",
			  animation: false,
			  text: "El nÃºmero de cÃ©dula no se encuentra registrado como egresado de esta casa de estudios!",
			  type: "error",
			  confirmButtonText: "OK"
		});
		document.getElementById("nombres").value = '';
		document.getElementById("apellidos").value = '';
		document.getElementById("titulos").innerHTML = '';
		document.getElementById("cedula").focus();
	}
}

function consultaTitulos(cedula)
{	
	AjaxRequest.post({
						'parameters': { "cedula":cedula },
						'onSuccess': respConsultaTitulos,
						'url': 'consulta/titulos.php',
						'onError': function(req){
							swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
						}
	});
}

function respConsultaTitulos(req)
{
	var titulos = document.getElementById('titulos');
	titulos.innerHTML = '';
	titulos.innerHTML = req.responseText;
}

function limpiarEgresado() {
	var cedula = document.getElementById("cedula");
	var nacionalidad = document.getElementById("nacionalidad");
	var nombres = document.getElementById("nombres");
	var apellidos = document.getElementById("apellidos");
	var titulos = document.getElementById("titulos");
	
	nacionalidad.value = 'V';
	cedula.value = '';
	nombres.value = '';
	apellidos.value = '';
	titulos.innerHTML = '';
	cedula.focus();
}

function reimprimirPlanilla() {
	var numero = document.getElementById("nroSoli").value;
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"numero":numero,
			"operacion": 'datosSolicitud'
		 }
		,'onSuccess': function(req) {respReimprimirPlanilla(req, numero) }
		,'url':'consulta/transaccion/transConsulta.php'
		,'onError':function(req)
			{
				swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
			}
		}
	);
}

function respReimprimirPlanilla(req, numero) {
	var resp = eval ("("+ req.responseText +")");
	var cedula = resp[0]['cedula'];
	var area = resp[0]['area'];
	var uso = resp[0]['uso'];
	
	var url;
	
	if (resp!=false && resp!=null && resp!='')
	{
		url = 'descarga/planilla_pdf.php?cedula='+cedula+'&numero='+numero+'&area='+area+'&uso='+uso;
		window.open(url, 'ventanaHija', 'toolbar=0,scrollbars=1,location=0,statusbar=1,menubar=0,resizable=1,width=250,height=150,left=150,top=180');
		window.close('ventanaHija');
	} else {
		swal({title: '', text: 'Disculpe, error al validar los datos de la planilla', animation: false});
		btnDescargar.disabled = false;
		return;
	}
}