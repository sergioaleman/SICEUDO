function consultaSolicitudDocu() {
	var nroSoli = document.getElementById("nroSoli").value;
	var operacion = "buscarSolicitud";
	
	if (nroSoli == '') {
		swal({title: '', text: 'Debes ingresar el nÃºmero de solicitud', animation: false});
		return;
	}
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"nroSoli":nroSoli,
			"operacion":operacion
		 }
		,'onSuccess':function(req){respConsultaSolicitudDocu(req, nroSoli)}
		,'url':'consulta/transaccion/transSolicitud.php'
		,'onError':function(req)
			{
				swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
			}
		}
	);
}

function respConsultaSolicitudDocu(req, nroSoli)
{
	var resp = eval ("("+ req.responseText +")");
	
	if (resp[0]['valida'] > 0) {
		consultaSolicitud(nroSoli);
	}
	else {
		swal({
			  title: "",
			  animation: false,
			  text: "El nÃºmero de solicitud no se encuentra registrado",
			  type: "error",
			  confirmButtonText: "OK"
		});
		document.getElementById("nroSoli").innerHTML = '';
		document.getElementById("solicitudDocu").innerHTML = '';
		document.getElementById("nroSoli").focus();
	}
}

function consultaSolicitud(nroSoli)
{	
	AjaxRequest.post({
						'parameters': { "nroSoli":nroSoli },
						'onSuccess': respConsultaSolicitud,
						'url': 'consulta/estatus_solicitud.php',
						'onError': function(req){
							swal({title: '', text: 'Error!\nStatusText='+req.statusText+'\nContents='+req.responseText, animation: false});
						}
	});
}

function respConsultaSolicitud(req)
{
	var solicitud = document.getElementById('solicitudDocu');
	solicitud.innerHTML = '';
	solicitud.innerHTML = req.responseText;
}

function limpiarSolicitudDocu() {
	var nroSoli = document.getElementById("nroSoli");
	var solicitud = document.getElementById("solicitudDocu");
	
	nroSoli.value = '';
	solicitud.innerHTML = '';
	nroSoli.focus();
}