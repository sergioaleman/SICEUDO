<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>.: SICEUDO | Nuevo Ingreso :.</title>
<link rel="stylesheet" href="estilos/estilos.css" type="text/css" media="all">
<link rel="stylesheet" href="estilos/jquery.validity.css" type="text/css" media="all">
<link href='http://fonts.googleapis.com/css?family=Raleway:400,900,800,700,600,500,300,200,100' rel='stylesheet' type='text/css'>
<link type="text/css" rel="stylesheet" media="all" href="include/js/jscalendar/calendar-blue.css" title="win2k-cold-1"/>
<link href="estilos/estilos_simplemodal.css" rel="stylesheet" type="text/css"/>
<script src="include/js/jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="include/js/AjaxRequest.js"  type="text/javascript"></script>
<script src="ingreso/script/scriptIngrEs.js?v=700607" type="text/javascript"></script>
<script src="ingreso/script/scriptIngrEstu.js?v=700607" type="text/javascript"></script>
<script src="ingresop/script/scriptIngEstup.js?v=700607" type="text/javascript"></script>
<script src="ingreso/script/scriptIngrEstuRezagado.js?v=700607" type="text/javascript"></script>
<script src="ingresop/script/scriptIngrEstuConv.js?v=700607" type="text/javascript"></script> 
<script src="ingreso/script/scriptIngrEstuConv.js?v=700607" type="text/javascript"></script>
<script src="include/js/jquery.carouFredSel-5.5.0-packed.js" type="text/javascript"></script>
<script src="include/js/jscalendar/calendar.js" type="text/javascript"></script>
<script src="include/js/jscalendar/lang/calendar-es.js" type="text/javascript"></script>
<script src="include/js/jscalendar/calendar-setup.js" type="text/javascript"></script>
<script src="include/js/functions.js" type="text/javascript"></script>
<script src="include/js/interface.js" type="text/javascript"></script>
<script src="include/js/funciones.js" type="text/javascript"></script>
<script src="include/js/validity.js" type="text/javascript"></script>
<script src="include/js/simplemodal.js" type="text/javascript"></script></head>
</head>
<script src="admon/script/scriptLogin.js?v=700607" type="text/javascript"></script>
<script src="consultas/script/scriptConsulta.js?v=700607" type="text/javascript"></script>
<body onload="javascript:openMyModal('__index.php')">
<!-- wrapper -->
<div id="wrapper">
	<!-- shell -->
	<div class="shell">
		<!-- container -->
		<div class="container">
			<!-- header -->
			<header id="header">
				<!-- login -->
                       <div align="center" class="tituloP"><strong>UNIVERSIDAD DE ORIENTE - NÚCLEO DE MONAGAS </strong> | REGISTRO DE ESTUDIANTES DE NUEVO INGRESO</div>
                       <!-- Login Ends Here -->
				<div class="cl">&nbsp;</div>
			</header>
			<!-- end of header -->
			<!-- navigaation -->
			<nav id="navigation">
				<a href="#" class="nav-btn">INICIO<span></span></a>
				<ul>
					<li><a onclick="javascript:location.reload()">inicio</a></li>
					<!--<li><a onclick="javascript:cambiar_contenido('admon/iniciar.php', 'contenido')" style="cursor: pointer">ingresar</a></li>-->
					<li><a onclick="javascript:cambiar_contenido('ingresop/formIngresop.php', 'contenido')">registrar aspirante</a></li>
					<li><a onclick="javascript:cambiar_contenido('ingresop/formActaConv.php', 'contenido')">acta convenio</a></li>
					<li><a onclick="javascript:cambiar_contenido('ingresop/consultar.php', 'contenido')">consultar aspirante</a></li>
					<li><a onclick="javascript:cambiar_contenido('ingreso/formIngresoRezagado.php', 'contenido')" style="cursor: pointer">actualizar datos</a></li>
					<!--<li><a style="cursor: pointer" onclick="javascript:cambiar_contenido('info/info_horario.php', 'contenido')"><strong>horarios</strong></a></li>-->
					<!--<li><a style="cursor: pointer" onclick="javascript:cambiar_contenido('info/info_cronograma.php', 'contenido')"><strong>cronograma</strong></a></li> -->
					<!--<li><a onclick="javascript:cambiar_contenido('info/info_registro.php', 'contenido')" style="cursor: pointer">¿cómo registrarme?</a></li>-->
				</ul>
				<div class="cl">&nbsp;</div>
			</nav>
			<!-- end of navigation -->
<div id="contenido">
			<!-- slider-holder -->
			<div class="slider-holder">
				<!-- slider -->
				<marquee behavior="alternate" onMouseOver="this.setAttribute('scrollamount', 0, 0);" OnMouseOut="this.setAttribute('scrollamount', 1, 0);" truespeed="" scrolldelay="15" scrollamount="1" loop="infinite">
				<span class="tituloP">
				<strong><span class="tRojo11">Atención--></span></strong> Ya se encuentra disponible el registro de aspirantes 1-2021 . </span> <!--Ha iniciado el registro de aspirantes <strong> </strong>para el período <strong>II-2018-->
                </marquee>
				<div class="slider">
                  <div class="socials"> <a href="https://www.facebook.com/inscripcionesenlinea.udone?fref=ts" class="facebook-ico" target="_blank">facebook-ico</a> <!--<a href="#" class="twitter-ico">twitter-ico</a>-->
                      <div class="cl">&nbsp;</div>
                  </div>
				  <div class="arrs"> <a href="#" class="prev-arr"></a> <a href="#" class="next-arr"></a> </div>
				  <ul>
                    <li id="img1">
                      <div class="slide-cnt">
                       <h4>UNIVERSIDAD DE ORIENTE - NÚCLEO DE MONAGAS </h4>
                        <h2>Nuevo Ingreso I-2021</h2>
                        <p>Te damos la oportunidad de formar parte... <a onclick="javascript:cambiar_contenido('info/info_nvo_ingreso.php', 'contenido')" style="cursor: pointer" class="next-arr">ver más</a> </p>
                      </div>
                      <img src="imagenes/logo3.png" alt="" width="350" /> </li>
				    <li id="img2">
                      <div class="slide-cnt">
                        <h4>UNIVERSIDAD DE ORIENTE</h4>
                        <h2>¿Asignado por CNU-OPSU?</h2>
                        <p>Si te encuentras asignado por CNU-OPSU sólo tendrás que actualizar tus datos y asi podrás confirmar tu cupo en nuestra institución... <a onclick="javascript:cambiar_contenido('info/info_asignado_opsu.php', 'contenido')" style="cursor: pointer" class="next-arr">ver más</a></p>
                      </div>
				      <img src="imagenes/logo3.png" alt="" width="350" /> </li>
				    <li id="img3">
                      <div class="slide-cnt">
                        <h4>UNIVERSIDAD DE ORIENTE</h4>
                        <h2>Poblaci&oacute;n Flotante</h2>
                        <p>Tendr&aacute;s la oportunidad de registrarte en nuestro sistema y seleccionar tres especialidades o carreras para aumentar tus posibilidades de ingreso de acuerdo a los requisitos establecidos... <a onclick="javascript:cambiar_contenido('info/info_poblacion_flot.php', 'contenido')" style="cursor: pointer" class="next-arr">ver más</a></p>
                      </div>
				      <img src="imagenes/logo3.png" alt="" width="350" /> </li>
					  <!--<li id="img4">
                      <div class="slide-cnt">
                        <h4>UNIVERSIDAD DE ORIENTE</h4>
                        <h2>Acta Convenio</h2>
                        <p>Si tienes algún familiar, funcionario de la universidad tal como... <a onclick="javascript:cambiar_contenido('info/info_acta_convenio.php', 'contenido')" style="cursor: pointer" class="next-arr">ver más</a></p>
                      </div>
				      <img src="imagenes/logo3.png" alt="" width="350" /> </li>-->
			      </ul>
			  </div>
				<!-- end of slider -->
                <!-- thumbs -->
<div id="thumbs-wrapper">
					<div id="thumbs">
						<a href="#img1" class="selected"><img src="estilos/images/tb1.png"/></a>
						<a href="#img2"><img src="estilos/images/tb2.png" /></a>
						<a href="#img3"><img src="estilos/images/tb3.png" /></a>
						<a href="#img4"><img src="estilos/images/tb4.png" /></a>
					</div>
					<a id="prev" href="#"></a>
					<a id="next" href="#"></a>
			  </div>
				<!-- end of thumbs -->
		</div>

			<!-- main -->
			<div class="main">

				<!--<div class="featured">
					<h4>Bienvenido a la <strong>Universidad de Oriente.</strong> A continuación puedes realizar tu solicitud...</strong></h4>
					<a onclick="javascript:cambiar_contenido('admon/iniciar.php', 'contenido')" class="blue-btn">INGRESAR</a>
				</div>-->

				<section class="cols">
					<div class="col">
						<h3>La UDO</h3>
						<p>Comprometida a dedicar sus esfuerzos a la formación de recursos humanos competitivos para el mercado laboral, prestando servicio de calidad en las áreas del conocimiento científico, humanístico y tecnológico mediante la realización de funciones de investigación, docencia y extensión. Para más información visita nuestra página principal en el siguiente enlace<br/></p>
                     <ul>
				      	<li><a href="http://www.udo.edu.ve" target="_blank" class="more">Universidad de Oriente</a></li>
                     </ul>
					 <br />
						<h3>Oferta de Estudios</h3>
						<p>En esta casa de estudios usted podrá encontrar distintas especialidades que abarcan diversas áreas de conocimiento como se indican a continuación. <br />
						<a onclick="javascript:cambiar_contenido('info/info_ofertas_estu.php', 'contenido')" class="more">ver más</a></p>
					</div>

					<div class="col">
						<h3>Núcleos</h3>
						<p>La Universidad de Oriente (UDO) se encuentra conformada por cinco núcleos y tres extensiones, las cuales se encuentran ubicadas a lo largo y ancho del oriente venezolano. Para más información visita al<br/><br/>
                        <ul>
						  <li><a href="http://www.anz.udo.edu.ve" target="_blank" class="more">Núcleo de Anzoátegui</a></li>
                          <li><a href="http://www.bolivar.udo.edu.ve" target="_blank" class="more">Núcleo de Bolívar</a></li>
                          <li><a href="http://www.monagas.udo.edu.ve" target="_blank" class="more">Núcleo de Monagas</a></li>
                          <li><a href="http://www.ne.udo.edu.ve" target="_blank" class="more">Núcleo de Nueva Esparta</a></li>
                          <li><a href="http://www.sucre.udo.edu.ve" target="_blank" class="more">Núcleo de Sucre</a></li>
                        </ul>  
                          </p>
					</div>

					<div class="col">
						<h3>Datos Bancarios</h3>
						<p>Información necesaria para realizar tu preinscripción de forma satisfactoria, a nombre de <strong>UDO-Ingreso Monagas RIF de la UDO: G-20000052-0</strong>:<br />
						  <br />
						<ul>
						   <li>Depósito bancario y transferencias del mismo banco, Banco Mercantil Cuenta Corriente N° 0105-0054-1810-5425-0324  Bs 464.512,00 </li>
						   <li>Correo electrónico activo, de uso personal</li>
						   <li>Certificado de participación CNU-OPSU</li>
						   <li>Los asignados CNU-OPSU, no requieren de depósito bancario</li>
						</ul> 
						<br />
						<a onclick="javascript:cambiar_contenido('info/info_nvo_ingreso.php', 'contenido')" class="more">ver más</a></p>
					</div>
					<div class="cl">&nbsp;</div>
				</section>

				<section class="entries">
					<div class="entry">
						<h3>Noticias</h3>
						<div class="entry-inner">
							<div class="date"><strong>21</strong><span>2021</span><em>Julio</em></div>
							<div class="cnt">
								<p><a onclick="javascript: void(0)">Inicio del proceso de registro. </a></p>
								<p class="meta">&nbsp;</p>
							</div>
						</div>
						<!--<div class="entry-inner">
							<div class="date"><strong>S/D</strong><span>2015</span><em>Ene</em></div>
							<div class="cnt">
								<p><a onclick="javascript: void(0)">Finalización del proceso de preinscripci&oacute;n. Posteriormente se iniciar&aacute; el proceso de selecci&oacute;n y publicaci&oacute;n del cronograma para entrega de documentos.</a></p>
								<p class="meta">&nbsp;</p>
							</div>
						</div>-->
					</div>
					<div class="entry">
						<h3>Puntos de Contacto </h3>
						<h5>Queremos saber tu opinión! </h5>
						<!--<a href="#"><img src="css/images/col-img2.png" alt="" /></a>-->
						<p>Puedes contactarnos a través de nuestro correo <strong>contacto@infoudo.com.ve</strong> y <strong>info@boludo.com.ve</strong><br />
						<a href="#" class="more">ver más </a></p>
					</div>
					<div class="cl">&nbsp;</div>
				</section>
			</div>
			<!-- end of main -->
			<div class="cl">&nbsp;</div>
</div>			
			<!-- footer -->
			<div id="footer">
				<div class="footer-nav">
					<ul>
						<li><a href="index.php">inicio</a></li>
						<li><a onclick="javascript:cambiar_contenido('info/info_registro.php', 'contenido')">¿cómo registrarme?</a></li>
						<li><a onclick="javascript:cambiar_contenido('admon/admin.php', 'contenido')">administración</a></li>
						<li><a onclick="javascript:cambiar_contenido('admon/iniciar.php', 'contenido')">ingresar</a></li>
					</ul>
					<div class="cl">&nbsp;</div>
				</div>
				<p class="copy"><span> &copy; <?php echo date ("Y"); ?>. Universidad de Oriente</span></p>
				<div class="cl">&nbsp;</div>
			</div>
			<!-- end of footer -->
		</div>
		<!-- end of container -->
	</div>
	<!-- end of shell -->
</div>
<!-- end of wrapper -->	
</body>
</html>