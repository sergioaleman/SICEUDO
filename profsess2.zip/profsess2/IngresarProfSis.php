<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="stylesheet" type="text/css" href="cid:css-22a289e8-e7dc-4693-8b5a-5cfeddc92dec@mhtml.blink" />

<title>Formulario ingresaro Profesor a D.A.C.E.</title>

</head>


<body align="center">
  <table width="500" border="0" cellpadding="0" cellspacing="1" bgcolor="#FBFBFB" align="center">
    <tbody><tr> 
      <td valign="top" width="500" align="center"> 
<table width="500" border="0" cellpadding="0" cellspacing="0" bgcolor="#003366">
    <tbody><tr>
				<td width="500" height="50" valign="top" align="right">
				<img border="0" src="/images/UDOMonagas.jpg" width="500" height="50"></td>
		</tr>
		</tbody></table>
<form name="form1" method="POST" action="http://dacemonagas.info.ve/profsess/AccesoProfudomon.php">
<table width="500" style="border:1px solid #000000;" align="center">
<tbody><tr>
  <td align="center"><span class="Estilo2">Accesar a IntraDACE - Profesor</span></td>
</tr>
<tr>
<td>
<div align="center">
                    
                     
                      <p><strong>Para Regresar a registrarse </strong>(<a href="/profsess/Registrarprof.html" class="Estilo1"><strong>. . .Click aquí...</strong></a>)</p>
					  <p><strong>Ingresar al Sistema </strong>(<a href="http://dacemonagas.info.ve/profsess/IngresarProfSis.php" class="Estilo1"><strong>. . .Click aquí...</strong></a>)</p>
					  
				    </div>
 </td>
</tr>
</tbody></table>
<table width="500" style="border:1px solid #000000;" align="center">
<tbody><tr>
<td width="250" align="right"></td> 
<td width="250" align="left"> </td>
</tr>
<tr>
<td width="250" align="right"></td> 
<td width="250" align="left"></td>
</tr>
</tbody></table>
<table width="500" style="border:1px solid #000000;" align="center">
<tbody><tr>
<td colspan="2" align="center"><p><span class="Estilo5">Nota: </span><span class="Estilo6">S</span><span class="Estilo6">u usuario será la</span><span class="Estilo5"> letra "m"  seguida de su número de cédula, Ejemp: si su número de Cédula es 9.999.999 el usuario será "m9999999", manteniendo la clave ingresada por usted al momento de registrarse </span> <br>
    <input type="button" value="Ingresar">
</p>
</td>
</tr>
<tr>
<td width="250" align="center"><a href="/profsess/Registrarprof.html" class="Estilo7">Si no ha creado su Clave, *** Click aquí *** </a></td>
<td width="250" align="center"><a href="/profsess/IngresarProfSis.php" class="Estilo7">Si olvidó su Clave *** Click aquí*** </a></td>
</tr>
<tr>
<td height="41" colspan="2" align="center">
 
<!-- <hr aling="center" size="2" width="450" noshade> -->
<!-- <p align="justify" class="Estilo12"><strong>** <font style="text-decoration: underline blink;"><span class="Estilo26">INFORMACI&Oacute;N</span>:</font> Informamos al <span class="Estilo23">Personal Docente</span> que al acceder a su IntraDACE, en Carga Acad&eacute;mica, tendr&aacute;  un enlace que se ha dispuesto para llenar el <span class="Estilo25">formulario de Plan de Avance</span>, el cual servir&aacute; o ser&aacute; el punto de partida, para  evaluar de cuantas semanas se tendr�an que disponer para cubrir con el programa de las asignaturas <span class="Estilo23">lo m�s cercano al 100%</span>, para, una vez finalice el conflicto, poder <span class="Estilo25">realizar de manera afinada la reestructuraci�n o ajustes, a que hubiere lugar, del Calendario Acad�mico del presente semestre</span>.**</strong> </p> -->
  <p align="justify" class="Estilo12"><strong>** <font style="text-decoration: underline blink; visibility: visible;" id="blink"><span class="Estilo29">AVISO</span></font>: Se informa a los Docentes que ya pueden visualizar los e-mail cargados y/o actualizados por los estudiantes inscritos en sus secciones. Igual se informa, que para el momento los estudiantes se encuentran actualizando y/o registranso sus e-mails.**</strong> </p> 
  <!-- <p align="justify" class="Estilo34"><strong>** <font style="text-decoration: underline blink;" id="blink"><span class="Estilo12">AVISO</span></font>: <span class="Estilo38">Se informa al  Personal Docente del N&uacute;cleo que en los pr&oacute;ximos d&iacute;as y de forma progresiva se estar&aacute;n activando todos los servicios que se veni&aacute;n ofreciendo. </span> **</strong> </p> -->
 <hr aling="center" size="2" width="450" noshade="">
 <!--     <div align="center">
        <p><a href="http://www.monagas.udo.edu.ve/referendum/"><img src="../images/referendumBoton.jpg" width="220" height="80" border="0" align="absbottom"/></a><br>
        </p>
        </div> 
 <p><img src="../images/nuevo4.gif" width="20" height="20" border="0" align="absbottom" /><a href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/PlanificacionAcademicaCV_II2016.pdf" target="_blank" class="Estilo9 style1"><span class="Estilo21">*** <span class="Estilo38"><strong>Ver  Calendario Per�odo Acad�mico I-2016</strong></span> ***</span></a><img src="../images/nuevo4.gif" width="20" height="20" border="0" align="absbottom" /></p>  -->
<!-- 
 <p><a href="../CalendAcadNucleo.htm" class="Estilo9" target="_blank">Calendario Acad&eacute;mico Segundo Semestre del A�o 2010</a></p> 
 <p><img src="../images/nuevo4.gif" width="20" height="20" border="0" align="absbottom" /><a href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/NormativaCV2012_Profesores.pdf" target="_blank" class="Estilo9 style1">*** INFORMACI�N IMPORTANTE:<br> NORMATIVA DEL CURSO VACACIONAL 2012 ***</a><img src="../images/nuevo4.gif" width="20" height="20" border="0" align="absbottom" /></p>  
<p>**** <a href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/CalendarioAcademicoI2013R.jpg"  target="_blank"><span class="Estilo28"> Ver Resumen Calendario Acad�mico del I-2013 </span></a> ****</p> 

<div class="Estilo9" id='blink' style="text-align:center;">
<a href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/PlanificacionAcademicaCV2014.pdf" target="_blank"><span style="font-size:16px;">*** Ver Resumen Horarios C.V. 2014 *** </span></a>
</div>
-->
 <span class="Estilo30">
 
 </span>
 
<p><a href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/gaceta53.pdf" target="_blank" class="Estilo31">Revisar información relacionada con Normativas Académicas</a></p>
<p><a href="http://dacemonagas.info.ve/" class="Estilo8">Ir a Control de Estudios ***Click aquí*** </a></p>
</td>
</tr>
</tbody></table>
</form>
</td>
</tr>
</tbody></table>
<table width="495" style="border:0px solid #000000;" align="center" height="50">
<tbody><tr>
  <td height="50" align="center">
  <center><marquee direction="up" id="ejemplo" height="50" width="495" scrolldelay="200">
  <span class="Apple-style-span" style="color: red;">PROFESORES CONTACTAR A SUS ESTUDIATES.</span>
  </marquee> <a></a>
  </center>
  </td>
</tr>
</tbody></table>


</body></html>