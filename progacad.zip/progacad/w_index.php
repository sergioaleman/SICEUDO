<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script type="text/javascript">
var xajaxRequestUri="http://201.249.180.234/anz/estudiantes/progacad/w_index.php?ti=13";
var xajaxDebug=false;
var xajaxStatusMessages=false;
var xajaxWaitCursor=true;
var xajaxDefinedGet=0;
var xajaxDefinedPost=1;
var xajaxLoaded=false;
function xajax_Departamento(){return xajax.call("Departamento", arguments, 1);}
function xajax_ShowAula(){return xajax.call("ShowAula", arguments, 1);}
function xajax_ImprimirNP(){return xajax.call("ImprimirNP", arguments, 1);}
	</script>
	<script type="text/javascript" src="xajax/xajax_js/xajax.js"></script>
	<script type="text/javascript">
window.setTimeout(function () { if (!xajaxLoaded) { alert('Error: the xajax Javascript file could not be included. Perhaps the URL is incorrect?\nURL: xajax/xajax_js/xajax.js'); } }, 6000);
	</script>
 <script type="text/javascript">
 	//MiId = "ResultadoAulas";
	window.whith ='800';

function AbrirVentana( aula, codigo, seccion, periodo ){
	tabla = "informacion.php?aula=" + aula + "&codigo=" + codigo + "&seccion=" + seccion + "&periodo=" + periodo;
	
    window.open( tabla,'HORARIO','width=700, height=450, resizable=no, scrollbars=yes, toolbar=no, location=no' ); 
}	

	
 </script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Universidad de Oriente - DSC-SPA </title>
<script type="text/javascript" src="js/pseudos.js"></script>

</head>
<link rel="stylesheet" type="text/css" media="print" href="style/print.css" />
<link rel="stylesheet" type="text/css" media="screen" href="style/spastyle.css">

<body OnContextMenu="return false">
 <a name="INI" id="INI"></a>
<form action="" method="get" name="frmAula" id="frmAula">
  <table width="780" border="0" align="center">
    <tr>
      <td class="style12">
      <img src="images/logoudo.jpeg" width="100" height="75"  align="left" />
         <span class="style5">
       <b>&nbsp;UNIVERSIDAD DE ORIENTE <BR />
          &nbsp;N&Uacute;CLEO DE ANZO&Aacute;TEGUI<BR />
        &nbsp;PROGRAMACI&Oacute;N ACAD&Eacute;MICA</b></span><br />
         <B> &nbsp;Per&iacute;odo Acad&eacute;mico 
       2020 - 1      </B></td>
    </tr>
    <tr>
      <td><table width="100%" border="0" align="center">
        <tr>
          <td valign="top"><table width="100%" border="0"  >
            <tr>
              <td height="27px" colspan="2" class="bordersTB">
			   <span class="letraGrande" > &nbsp;&nbsp; Programaci&oacute;n Acad&eacute;mica por departamento</span> <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style16" >Seleccione entre las opciones, para ver la programaci&oacute;n ac&aacute;demica de Estudiantes Regulares o de Estudiantes Nuevos</span>             
			   <input type="hidden" name="hTipoEstu" id="hTipoEstu"  value="R"/></td>
            </tr>
            
            <tr>
              <td width="77%" valign="top"  style="border:1px solid #88A2E3"  ><div id="menu">
              <table width ='100%'cellspacing='0'><tr>
			          <td  bgcolor ='#7CA8FF' >
					  <span class="style15"> .: ESTUDIANTE</span></td> <td  bgcolor ='#7CA8FF' >
					 <table width='200'> <tr>
					 <td><label> <input type='radio' name='TipoEstu' value='R' id='TipoEstu' checked ='checked ' onClick="hTipoEstu.value ='R'"  />
                      <span class="style15">REGULAR</span></label></td>	
					  <td> <input type='radio' name='TipoEstu' value='N' id='TipoEstu' onClick="hTipoEstu.value ='N'" />
		<span class="style15">NUEVO</span></label></td>					 														    
					 </tr>
					 </table> 
			  </span></td></tr>
		  <td><label><tr><td><a href="#" onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '6357', '11', 'ADMINISTRACIÓN', TE); MuestraGifEspera(a, 'mensaje');"  >ADMINISTRACI�N</a></td><td><a href='#' onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2126', '16', 'ARQUITECTURA', TE); MuestraGifEspera(a, 'mensaje');">ARQUITECTURA</a></td><tr><td><a href="#" onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '6350', '8', 'CONTADURIA PUBLICA', TE); MuestraGifEspera(a, 'mensaje');"  >CONTADURIA PUBLICA</a></td><td><a href='#' onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2120A', '12', 'INGENIERIA CIVIL', TE); MuestraGifEspera(a, 'mensaje');">INGENIERIA CIVIL</a></td><tr><td><a href="#" onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2060', '4', 'INGENIERIA DE PETROLEO', TE); MuestraGifEspera(a, 'mensaje');"  >INGENIERIA DE PETROLEO</a></td><td><a href='#' onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2075A', '13', 'INGENIERIA DE SISTEMAS', TE); MuestraGifEspera(a, 'mensaje');">INGENIERIA DE SISTEMAS</a></td><tr><td><a href="#" onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2065A', '13', 'INGENIERIA EN  COMPUTACION', TE); MuestraGifEspera(a, 'mensaje');"  >INGENIERIA EN  COMPUTACION</a></td><td><a href='#' onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2115', '3', 'INGENIERIA INDUSTRIAL', TE); MuestraGifEspera(a, 'mensaje');">INGENIERIA INDUSTRIAL</a></td><tr><td><a href="#" onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2105A', '2', 'INGENIERIA MECANICA', TE); MuestraGifEspera(a, 'mensaje');"  >INGENIERIA MECANICA</a></td><td><a href='#' onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2085A', '1', 'INGENIERIA ELECTRICA', TE); MuestraGifEspera(a, 'mensaje');">INGENIERIA�ELECTRICA</a></td><tr><td><a href="#" onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2110A', '5', 'INGENIERIA QUIMICA ', TE); MuestraGifEspera(a, 'mensaje');"  >INGENIERIA�QUIMICA </a></td><td><a href='#' onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '6360', '10', 'LICENCIATURA EN TURISMO', TE); MuestraGifEspera(a, 'mensaje');">LICENCIATURA EN TURISMO</a></td><tr><td><a href="#" onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '4205', '15', 'MEDICINA', TE); MuestraGifEspera(a, 'mensaje');"  >MEDICINA</a></td><td><a href='#' onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2555', '6', 'TECNOL. EN ELECTRONICA', TE); MuestraGifEspera(a, 'mensaje');">TECNOL. EN ELECTRONICA</a></td><tr><td><a href="#" onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '2590A', '6', 'TECNOL. FAB.  MECANICA', TE); MuestraGifEspera(a, 'mensaje');"  >TECNOL. FAB.  MECANICA</a></td><td><a href='#' onclick="NoBoton(); TE=tipoEstu(); a=xajax_Departamento('13', '', '', '', TE); MuestraGifEspera(a, 'mensaje');"></a></td></table>                         
                  </div>  </td>
              <td width="23%" align="center" valign="top"> 
              
               <br /> <img src="images/nuevos1.jpeg" width="123" height="173" border="0" /><br />
                 <table width="100%" border="0">
                  
                </table>
                 </a>              </td>    
            </tr>
          </table> 
            
            <a name="S" id="S"></a><br />
              <div id="btnOk"> </div>
                <div class="style5" id="mensaje"> Seleccione el departamento a consultar </div>
                
           </td>
        </tr>
      </table></td>
    </tr>
    
  </table>
  <br />
</form>



</body>
</html>