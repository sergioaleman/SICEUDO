function miReporte () {
	var i, j=0;
	var formulario = document.getElementById("misReportes");
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('codNucleo').value;
	var codEsp = document.getElementById('sel_esp').value;
	var mensaje = document.getElementById('mensajes');
	
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.type == "radio") {
			if(elemento.checked) {
				j=j+1;
				url = elemento.value;
			}
		}
	}
	if (j == 0)
	{
		mensaje.innerHTML = "Debe seleccionar el tipo de reporte a imprimir";
	}
	else
	{
		mensaje.innerHTML = "";
		var url = "reportes/constancias/"+url+".php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
		openMyModal(url);
	}
}

function miPDF () {
	var i, j=0;
	var formulario = document.getElementById("misReportes");
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('codNucleo').value;
	var codEsp = document.getElementById('sel_esp').value;
	var mensaje = document.getElementById('mensajes');
	
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.type == "radio") {
			if(elemento.checked) {
				j=j+1;
				url = elemento.value;
			}
		}
	}
	if (j == 0)
	{
		mensaje.innerHTML = "Debe seleccionar el reporte que sea guardar en formato pdf";
	}
	else
	{
		mensaje.innerHTML = "";
		var url = "reportes/constancias/"+url+".php?tipo=pdf&nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
		window.open(url, 'horario', 'width=800, height=800, scrollbars=1, location=0, resizable=0');
	}
}