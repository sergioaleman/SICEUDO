<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="https://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="stylesheet" type="text/css" href="cid:css-153aa191-8af4-4653-8a04-a266bd06b95f@mhtml.blink" />

<title>Formulario ingresaro Usuario a D.A.C.E.</title>




</head>
<body align="center">
<table width="500" border="0" cellpadding="0" cellspacing="1" bgcolor="#FBFBFB" align="center">
    <tbody><tr> 
      <td valign="top" width="500" align="center"> 
<form name="form1" method="POST" action="https://dacemonagas.info.ve/sess/AccesoUsuarudomon.php">
<table width="500" style="border:1px solid #000000;" align="center">
<tbody><tr>
  <td align="center"><span class="Estilo2">Accesar a IntraDACE - Estudiante </span></td>
</tr>
</tbody></table>



				    <div align="center">
                    
                     
                      <p><strong>Para Regresar a registrarse </strong>(<a href="https://m.infoudo.com.ve/sess/Registrar.html" class="Estilo1"><strong>. . .Click aquí...</strong></a>)</p>
					  <p><strong>Ingresar al Sistema </strong>(<a href="http://dacemonagas.info.ve/sess/IngresarUsuarioSis.php" class="Estilo1"><strong>. . .Click aquí...</strong></a>)</p>
					  
				    </div>

<!--
<table width="500" style="border:1px solid #000000;" align="center">
<tbody><tr>
<td width="250" align="right">Ingrese su Usuario:</td> 
<td width="250" align="left"><input type="text" size="20" maxlength="20" name="USERNAME" id="Username"> </td>
</tr>
<tr>
<td width="250" align="right">Ingrese su Clave:</td> 
<td width="250" align="left"><input type="password" size="20" maxlength="20" name="PASSWORD" id="Password"></td>
</tr>
</tbody></table>-->


<table width="500" style="border:1px solid #000000;" align="center">
<tbody><tr>
<td colspan="2" align="center"><span class="Estilo5">Nota: </span><span class="Estilo6">S</span><span class="Estilo6">u usuario será la</span><span class="Estilo5"> letra "m"  seguida de su número de cédula, Ejemp: si su número de Cédula es 9.999.999 el usuario será "m9999999", manteniendo la clave ingresada por usted al momento de registrarse </span> <br>
  <input type="button" value="Ingresar"></td>
</tr>
<tr>
<td width="250" align="center"><a href="/sess/Registrar.html" class="Estilo7">Si no ha creado su Clave, *** Click aquí *** </a></td>
<td width="250" align="center"><a href="/sess/Reiniciar.html" class="Estilo7">Si olvidó su Clave *** Click aquí*** </a></td>
</tr>
<tr>
<td height="41" colspan="2" align="center">
   <hr aling="center" size="2" width="450" noshade=""> 
 <!-- <p class="Estilo9">Los estudiantes de Nuevo Ingreso, Segundo Semestre 2010, para registrarse deber&aacute;n pulsar el link &quot;<a href="Registrar.html">Si no est&aacute; registrado.***Clik aqu&iacute;***</a>&quot; y seguir las indicaciones. Le sugerimos leer bien. Su correo electr&oacute;nico lo podrán ver en el link "Ver  Usuario y Clave de Correo&quot;.</p> -->
 <!-- <p><span class="Estilo11 Estilo13"> Si no es el <b>D&iacute;a y Hora de su Cita de Inscripción</b> abst&eacute;ngase de acceder al IntraDACE durante el d&iacute;a, colabore con el proceso</span >.</p> -->
<!--  <p>***<strong>Ver Reingresos Aprobados recibidos en el D.A.C.E. <span class="Estilo14"><a  target="_blank" href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/">Click Aquí</a></span></strong></p> -->
<!--  <p><strong>Ver Cambios de Espec. Aprobados recibidos en el D.A.C.E. <span class="Estilo14"><a  target="_blank" href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/">Click Aquí</a></span></strong></p> -->
<!--	<hr aling="center" size="2" width="450" noshade>
	<p align="justify" class="Estilo12"><strong>***<span class="Estilo18"> <font style="text-decoration: underline blink;" id="blink">AVISO</font></span>: <span class="Estilo32">Proceso de Retiro de Asignatura ha FINALIZADO, en lo que respecta a la consignaci&oacute;n o env&iacute;o al correo del D.A.C.E. del recibo bancario para habilitar el enlace, por lo que se sugiere a los  estudiantes que cumplieron con el paso UNO (1) y DOS (2) ingresar a  IntraDACE y finalizar con el proceso, los que para el momento no lo han realizado. </span> Igual se informa, que en el D.A.C.E. NO se ofrecer&aacute; el Servicio de Taquilla del 06/08 al 19/09/2018, por encontrarse el Personal de la Universidad de oriente de Vacaciones Colectivas Agosto-Septiembre 2018. ***</strong> </p> -->
	<hr aling="center" size="2" width="450" noshade="">
    <p class="Estilo15">*** <a target="_blank" href="https://www.facebook.com/InfoudoMonagasOficial">Quieres ser fans de nuestro muro en FacebookClic aquí !!!</a> ***</p>   
 <p class="Estilo15">**** <a target="_blank" href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/"> Recomendamos visitar nuestro Sites.Google </a> ****</p>
     <!-- <div align="center">
        <p><a href="http://www.monagas.udo.edu.ve/referendum/"><img src="../images/referendumBoton.jpg" width="220" height="80" border="0" align="absbottom"/></a><br>
        </p>
        </div> -->
<!--  --> 
<!--  <div class="Estilo2" id="Fecha_Reloj" align="center">Hora de Sistema</div>   -->
 <!--  
 <p class="Estilo15">*** <a href="http://dace.monagas.udo.edu.ve/CalendarioAcademico.php" target="_blank" class="Estilo15"><strong> Ver  Calendario Período Acadeémico I-2017</strong></a> ***</p> -->
   <p><a href="http://dacemonagas.info.ve/" class="Estilo8">Ir a Control de Estudios ***Click aquí*** </a></p>
   <p><a href="http://m.infoudo.com.ve/" class="Estilo8">Ir a Infoudo Mobile ***Click aquí*** </a></p>
   
    <!--   -->
       <p class="Estilo15"><a href="http://201.249.180.234/egresados/" target="_blank" class="Estilo16"> Enlace directo para Solicitudes de Egresados ***Click aquí***</a></p> 
  <!--    <p class="Estilo15">**** <a href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/RetiroAsignaturaAviso.jpg"  target="_blank" class="Estilo16"> Ver Pasos para Retiro de Asignaturas I-2018 </a> ****</p> -->
  <!--    <p class="Estilo15">**** <a href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/PlanificacionHorarios.pdf"  target="_blank" class="Estilo16"> Ver Horarios  Per&iacute;odo Acad&eacute;mico I-2018 </a> ****</p> 
     <p><a href="../nuevosss/" class="Estilo8 Estilo15">Ver resultado del P.S.I . ***Click aqu&iacute;*** </a></p> -->
   <hr aling="center" size="2" width="450" noshade="">
     <p align="center">
    El arancel de Inscripción para ALUMNOS REGULARES I-2020 es de <span class="Estilo32"> Bs. 348.345,00</span> y el pago debe realizarse a la Cuenta Corriente del <span class="Estilo32">Banco Mercantil</span> número <span class="Estilo32">0105-0054-1810-5425-0324</span> a nombre de <span class="Estilo32">UDO - Ingresos</span>. Para realizar transferencias pueden afiliar este número de cuenta y colocar el siguiente <span class="Estilo32">R.I.F.: G-20000052-0</span> y colocar el correo electrónico <span class="Estilo32">dacemonagas@gmail.com</span>.<br>
     </p>
   <span class="Estilo30">
 
 </span>
 </td>
</tr>
</tbody></table>
</form>
</td>
</tr>
</tbody></table>
<table width="495" style="border:0px solid #000000;" align="center" height="50">
<tbody><tr>
  <td height="50" align="center">
  <center><marquee direction="up" id="ejemplo" height="50" width="495" scrolldelay="200">
    <span class="Apple-style-span" style="color: red;">Inicio de Clases, Período Académico I-2020, el día lunes 22/02/2021.</span>
  </marquee>
  </center>
  </td>
</tr>
</tbody></table>


</body></html>