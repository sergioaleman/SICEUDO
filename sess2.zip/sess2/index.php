<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Formulario ingresaro Usuario a D.A.C.E.</title>
<script language="JavaScript">
<!--
(!alert("Proceso de Inscripci�n para Per�odo Acad�mico II-2021 se estar� realizando el domingo 10/04/2022. Cualquier sugerencia, duda o informaci�n puede plantearla a trav�s de la cuenta de correo dacemonagas@gmail.com. *** Para continuar e ingresar a su IntraDACE, Clic en Aceptar ***"))
//-->
</script>
<script>
function validarEntero(valor){ 
     valor = parseInt(valor) 
     if (isNaN(valor)) { 
           return "" 
     }else{ 
           return valor 
     } 
} 

function valida_envia(){
if (document.form1.USERNAME.value.length==0){
 alert("Tiene que escribir su usuario")
 document.form1.USERNAME.focus()
 return 0;
}
if (document.form1.PASSWORD.value.length==0){
 alert("Tiene que escribir su clave")
 document.form1.PASSWORD.focus()
 return 0;
}
//alert("Muchas gracias por registrar su usuario. Ahora prodra disfrutar de nuetros servicios");
document.form1.submit();
}
</script>
<style type="text/css">
<!--
.Estilo2 {
	color: #0000FF;
	font-weight: bold;
	font-size: 18px;
}
.Estilo5 {
	color: #FF0000;
	font-weight: bold;
	font-size: 10px;
}
.Estilo6 {
	color: #FF0000;
	font-size: 10px;
}
.Estilo12 {color: #000066}
.Estilo7 {font-size: 12px}
.Estilo8 {font-size: 14px}
.Estilo15 {color: #FF0000; font-weight: bold; }
.Estilo16 {color: #669900}
.Estilo17 {color: #FF0000}
.Estilo33 {color: #FF0000}
.Estilo34 {color: #40E718}
.Estilo18 {
	color: #66CC00;
	font-weight: bold;
}
.Estilo32 {color: #FF0000}
-->
</style>
<!--<script language="JavaScript" type="text/JavaScript">
    var Hoy = new Date("10 Apr 2022 07:49:45");
function Reloj(){ 
    Hora = Hoy.getHours()
    Minutos = Hoy.getMinutes() 
    Segundos = Hoy.getSeconds() 
    if (Hora<=9) Hora = "0" + Hora 
    if (Minutos<=9) Minutos = "0" + Minutos 
    if (Segundos<=9) Segundos = "0" + Segundos 
    var Inicio, Script, Final, Total 
    Inicio = '<p class="Estilo111">' 
    Script = "Hora para efectos de inscripción " + Hora + ":" + Minutos + ":" + Segundos 
    Final = "</p>" 
    Total = Inicio + Script + Final
    document.getElementById('Fecha_Reloj').innerHTML = Total 
    Hoy.setSeconds(Hoy.getSeconds() +1)
    setTimeout("Reloj()",1000) 
}
/*    var Hoyservidor = new Date("");
function Relojservidor(){ 
    Horaserv = Hoyservidor.getHours()
    Minutosserv = Hoyservidor.getMinutes() 
    Segundosserv = Hoyservidor.getSeconds() 
    if (Horaserv<=9) Horaserv = "0" + Horaserv 
    if (Minutosserv<=9) Minutosserv = "0" + Minutosserv 
    if (Segundosserv<=9) Segundosserv = "0" + Segundosserv 
    var Inicioserv, Scriptserv, Finalserv, Totalserv 
    Inicioserv = '<p class="Estilo111">' 
    Scriptserv = "Hora Servidor " + Horaserv + ":" + Minutosserv + ":" + Segundosserv 
    Finalserv = "</p>" 
    Totalserv = Inicioserv + Scriptserv + Finalserv
    document.getElementById('Fecha_Relojservidor').innerHTML = Totalserv 
    Hoyservidor.setSeconds(Hoyservidor.getSeconds() +1)
    setTimeout("Relojservidor()",1000) 
}  */
</script>-->
</head>
<body align="center" oncontextmenu="return false" onLoad="Reloj()">
<table width="500" border="0" cellpadding="0" cellspacing="1" bgcolor="#FBFBFB" align="center" >
    <tr> 
      <td valign="top" width="500" align="center"> 
<form name="form1" method="POST" action="http://dacemonagas.info.ve/sess/AccesoUsuarudomon.php" >
<table width="500" style="border:1px solid #000000;" align="center" >
<tr>
  <td align="center"><span class="Estilo2">Accesar a IntraDACE - Estudiante </span></td>
</tr>
</table>
<table width="500" style="border:1px solid #000000;" align="center">
<tr>
<td width="250" align="right">Ingrese su Usuario:</td> 
<td width="250" align="left"><input type="text" size="20" maxlength="20" name="USERNAME" id="Username"> </td>
</tr>
<tr>
<td  width="250" align="right">Ingrese su Clave:</td> 
<td width="250" align="left"><input type="password" size="20" maxlength="20" name="PASSWORD" id="Password"></td>
</tr>
</table>
<table width="500" style="border:1px solid #000000;" align="center">
<tr>
<td colspan="2" align="center"><span class="Estilo5">Nota: </span><span class="Estilo6">S</span><span class="Estilo6">u usuario ser&aacute; la</span><span class="Estilo5"> letra &quot;m&quot;  seguida de su n&uacute;mero de c&eacute;dula, Ejemp: si su n&uacute;mero de C&eacute;dula es 9.999.999 el usuario ser&aacute; &quot;m9999999&quot;, manteniendo la clave ingresada por usted al momento de registrarse </span> <br>
  <input type="button" value="Ingresar"  onClick="valida_envia()"></td>
</tr>
<tr>
<td width="250" align="center"><a href="Registrar.html" class="Estilo7">Si no ha creado su Clave, *** Click aqu&iacute; *** </a></td>
<td width="250" align="center"><a href="Reiniciar.html" class="Estilo7">Si olvid&oacute; su Clave *** Click aqu&iacute;*** </a></td>
</tr>
<tr>
<td height="41" colspan="2" align="center">
   <hr aling="center" size="2" width="450" noshade> 
 <!-- <p class="Estilo9">Los estudiantes de Nuevo Ingreso, Segundo Semestre 2010, para registrarse deber&aacute;n pulsar el link &quot;<a href="Registrar.html">Si no est&aacute; registrado.***Clik aqu&iacute;***</a>&quot; y seguir las indicaciones. Le sugerimos leer bien. Su correo electr&oacute;nico lo podrán ver en el link "Ver  Usuario y Clave de Correo&quot;.</p> -->
 <!-- <p><span class="Estilo11 Estilo13"> Si no es el <b>D&iacute;a y Hora de su Cita de Inscripción</b> abst&eacute;ngase de acceder al IntraDACE durante el d&iacute;a, colabore con el proceso</span >.</p> -->
<!--  <p>***<strong>Ver Reingresos Aprobados recibidos en el D.A.C.E. <span class="Estilo14"><a  target="_blank" href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/">Click Aquí</a></span></strong></p> -->
<!--  <p><strong>Ver Cambios de Espec. Aprobados recibidos en el D.A.C.E. <span class="Estilo14"><a  target="_blank" href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/">Click Aquí</a></span></strong></p> -->
<!--	<hr aling="center" size="2" width="450" noshade>
	<p align="justify" class="Estilo12"><strong>***<span class="Estilo18"> <font style="text-decoration: underline blink;" id="blink">AVISO</font></span>: <span class="Estilo32">Proceso de Retiro de Asignatura ha FINALIZADO, en lo que respecta a la consignaci&oacute;n o env&iacute;o al correo del D.A.C.E. del recibo bancario para habilitar el enlace, por lo que se sugiere a los  estudiantes que cumplieron con el paso UNO (1) y DOS (2) ingresar a  IntraDACE y finalizar con el proceso, los que para el momento no lo han realizado. </span> Igual se informa, que en el D.A.C.E. NO se ofrecer&aacute; el Servicio de Taquilla del 06/08 al 19/09/2018, por encontrarse el Personal de la Universidad de oriente de Vacaciones Colectivas Agosto-Septiembre 2018. ***</strong> </p> -->
	   <input type="button" value="Informaci&oacute;n importante, ver resoluci&oacute;n CU 070/2021" onclick="if(navigator.appName.indexOf('Microsoft Internet Explorer') != -1){window.showModelessDialog('http://dacemonagas.info.ve/Formas/CU_070_2021.jpg','','dialogTop:50px;dialogLeft:50px;dialogHeight:500px;dialogWidth:700px')}if(navigator.appName.indexOf('Netscape') != -1){
window.open('http://dacemonagas.info.ve/Formas/CU_070_2021.jpg','','width=700,height=500,left=50,top=50');void 0}; return false;" />
	<hr aling="center" size="2" width="450" noshade>
    <p class="Estilo15">*** <a target="_blank" href="https://www.facebook.com/pages/Dacemonudo/154531554587096">Quieres ser fans de nuestro muro en FacebookClic aquí !!!</a> ***</p>   
 <p class="Estilo15">**** <a  target="_blank" href="https://twitter.com/dacemonagas"> Recomendamos visitar nuestro Twitter </a> ****</p>
 <!--  <p class="Estilo15">**** <a  target="_blank" href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/"> Recomendamos visitar nuestro Sites.Google </a> ****</p> --> 
     <!-- <div align="center">
        <p><a href="http://www.monagas.udo.edu.ve/referendum/"><img src="../images/referendumBoton.jpg" width="220" height="80" border="0" align="absbottom"/></a><br>
        </p>
        </div> -->
<!--  --> 
<!--<div class="Estilo2" id="Fecha_Reloj" align="center">Hora de Sistema</div>-->

<?php
$DateAndTime = date('m-d-Y h:i:s a', time());  
echo " ";
?>


 <!--  
 <p class="Estilo15">*** <a href="http://dace.monagas.udo.edu.ve/CalendarioAcademico.php" target="_blank" class="Estilo15"><strong> Ver  Calendario Período Acadeémico I-2017</strong></a> ***</p> -->
   <p><a href="http://dacemonagas.info.ve/" class="Estilo8">Ir a Control de Estudios ***Click aqu&iacute;*** </a></p>
    <!--   -->
       <p class="Estilo15"><a href="http://201.249.180.234/egresados/"  target="_blank" class="Estilo16"> Enlace directo para Solicitudes de Egresados ***Click aqu&iacute;***</a></p> 
  <!--    <p class="Estilo15">**** <a href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/RetiroAsignaturaAviso.jpg"  target="_blank" class="Estilo16"> Ver Pasos para Retiro de Asignaturas I-2018 </a> ****</p> -->
  <!--    <p class="Estilo15">**** <a href="https://sites.google.com/a/monagas.udo.edu.ve/estudiantes/PlanificacionHorarios.pdf"  target="_blank" class="Estilo16"> Ver Horarios  Per&iacute;odo Acad&eacute;mico I-2018 </a> ****</p> 
     <p><a href="../nuevosss/" class="Estilo8 Estilo15">Ver resultado del P.S.I . ***Click aqu&iacute;*** </a></p> -->
   <hr aling="center" size="2" width="450" noshade>
     <p align="center">
    El arancel de Inscripci&oacute;n para ALUMNOS REGULARES II-2021 es de <span class="Estilo32"> Bs Digital  4,00</span> y el pago debe realizarse a la Cuenta Corriente del <span class="Estilo32">Banco Mercantil</span> n&uacute;mero <span class="Estilo32">0105-0054-1810-5425-0324</span> a nombre de <span class="Estilo32">UDO - Ingresos</span>. Para realizar transferencias pueden afiliar este n&uacute;mero de cuenta y colocar el siguiente <span class="Estilo32">R.I.F.: G-20000052-0</span> y colocar el correo electr&oacute;nico <span class="Estilo32"><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="cda9acaea8a0a2a3acaaacbe8daaa0aca4a1e3aea2a0">[email&#160;protected]</a></span>.<br>
     </p>
   <span class="Estilo30">

 <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script language="JavaScript">
 </script>
 </span>
 <script language="JavaScript">function blink_uno() {
document.getElementById('blink').style.visibility='visible';
setTimeout('blink_dos()',1000);
}
function blink_dos() {
document.getElementById('blink').style.visibility='hidden';
setTimeout('blink_uno()',1000);
}
blink_uno();
</script></td>
</tr>
</table>
</form>
</td>
</tr>
</table>
<table width="495" style="border:0px solid #000000;" align="center"  height="50">
<tr>
  <td height="50" align="center">
  <center><marquee direction="up" id="ejemplo" height="50" width="495" SCROLLDELAY =200>
    <span class="Apple-style-span" style="color: red;">Publicada Cita de Inscripci&oacute;n de alumnos Regulares, Per&iacute;odo Acad&eacute;mico II-2021.</span>
  </marquee>
  </center>
  </td>
</tr>
</table>
</body>
</html>