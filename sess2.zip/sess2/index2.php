<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<title>Universidad de Oriente - Ncleo de Monagas - Departamento de Admisin y Control de Estudios</title>
</head>
<frameset cols="100%,*">
  <frame name="contenido" target="principal" src="IngresarUsuarioSis.php">
  <frame name="principal">
  <noframes>
  <body>
  <p>Gracias por visitarnos, estamos trabajando para brindarles un mejorar servicio.</p>
  </body>
  </noframes>
</frameset>
</html>