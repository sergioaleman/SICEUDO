var modificarSolicitudCd = 0;

function abrirAjax()
{
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function mostrarEstudianteCd() {
	
	var cedula = document.getElementById('cedula');
	var nombres = document.getElementById('nombres');
	var cod_esp = document.getElementById('cod_esp');
	var nucleo = document.getElementById('nucleo');
	var desNucleo = document.getElementById('desNucleo');
	var fecha = document.getElementById('fecha_rec');
	var ano = document.getElementById('sel_anio');
	var periodo = document.getElementById('sel_periodo');
	var observaciones = document.getElementById('observaciones');
	var estatus = document.getElementById('estatus');
	var asig_cd = document.getElementById('asignaturas');
	var estatus=document.getElementById('txt_estatus');
	var contenido_codigo = abrirAjax();
	
	contenido_codigo.open("GET", "solicitudes/consultas.php?accion=4&cedula="+cedula.value+"&periodo="+periodo.value+"&anio="+ano.value, true);
   contenido_codigo.onreadystatechange=function()
	{
		if (contenido_codigo.readyState==4)
		{
			var arregloDatos;
			arregloDatos = contenido_codigo.responseText.split('||');
			if ((arregloDatos[0] == 0) && (cedula.value != '')) {
				alert("El nÃºmero de cÃ©dula no ha sido registrado como estudiante");
				cedula.value = '';
				cedula.focus();
				return;
			} else if (arregloDatos[12] != 0) {
				var fecha=arregloDatos[6].split("-");
				alert("El estudiante tiene registrada una solicitud para asistir al siguiente curso dirigido \n Asignatura: ("+arregloDatos[14]+") "+arregloDatos[17]+" \n Semestre: "+arregloDatos[8]+"-"+arregloDatos[7]+" \n Estatus: "+arregloDatos[10]+" \n Fecha de Solicitud: "+fecha[2]+"/"+fecha[1]+"/"+fecha[0]);
				cedula.value = '';
				cedula.focus();
				return;
			} else if(arregloDatos[13] != 'INACTIVO'){ //estatus distinto de inactivo
				nombres.value = arregloDatos[1]+', '+arregloDatos[2];
				cod_esp.value = arregloDatos[5];
				nucleo.value = arregloDatos[3];
				desNucleo.value = arregloDatos[4];
				estatus.value=arregloDatos[13];
				especialidadesEstudiante();
				asignaturasEspecialidad(arregloDatos[5]);
				buscarCreditosInscritosDirigido();
				buscarMedidasDirigido();
				
			}
			else if(arregloDatos[13] == 'INACTIVO'){
				alert("Este estudiante se encuentra INACTIVO en el semestre en curso");
				cedula.value = '';
				cedula.focus();
				return;
			}
				
		}
	}
	contenido_codigo.send(null);
}

function asignaturasEspecialidad(especialidad) {
	var asignaturas = document.getElementById('asignaturas');
	var contenido = abrirAjax();
	contenido.open("GET", "solicitudes/consultas.php?accion=5&esp="+especialidad, true);
   contenido.onreadystatechange=function()
	{
		if (contenido.readyState==1)
		{
			asignaturas.length=0;
			var opcion=document.createElement("opcion");
			opcion.value=0;
			opcion.innerHTML= "Cargando...";
			asignaturas.appendChild(opcion);
			asignaturas.disabled=true;
		}
		if (contenido.readyState==4)
		{
			asignaturas.parentNode.innerHTML = contenido.responseText;
		}
	}
	contenido.send(null);
}

function limpiarDirigido() {
	var cedula = document.getElementById('cedula');
	var especialidad = document.getElementById('especialidad');
	var asignaturas = document.getElementById('asignaturas');
	var formulario = document.getElementById('fDirigido');
	
	//cedula.value = '';
	//especialidad.value = 0;
	//especialidad.innerHTML = "<OPTION value='0'>...</OPTION>";
	asignaturas.value = 0;
	//asignaturas.innerHTML = "<OPTION value='0'>...</OPTION>";
	//formulario.reset();
	//cedula.focus();
}

function guardarSolicitudCd() {
	var cedula = document.getElementById("cedula").value;
	var nombres = document.getElementById("nombres").value;
	var nucleo = document.getElementById("nucleo").value;
	var especialidad = document.getElementById("especialidad").value;
	var cod = document.getElementById("asignaturas").value;
	var asig=cod.split("-");
	var asignatura=asig[0];
	var fecha = document.getElementById("fecha_rec").value;
	//var semestre = document.getElementById("semestre").value;
	var periodo=document.getElementById('sel_periodo').value;
	var anio=document.getElementById('sel_anio').value;
	
	var observaciones = document.getElementById("observaciones").value;

	if (modificarSolicitudCd == 0) {
		mensajeGuardar = 'Una vez realizada la solicitud no podrÃ¡ ser modificada ni eliminada Â¿Esta seguro que desea registrar su solicitud de curso dirigido para la asignatura '+asig[0]+" - "+asig[2]+'?','si/no';
	} else {
		mensajeGuardar = 'Â¿Desea modificar la solicitud de curso dirigido del estudiante '+cedula+'?','si/no';
	}
	if ((cedula != '') && (especialidad!='') && (asignatura!=0))
	{
		if (confirm(mensajeGuardar))
		{
			AjaxRequest.post(
							{
									'parameters': {'cedula':cedula,
														'nucleo':nucleo,
														'especialidad':especialidad,
														'asignatura':asignatura,
														'fecha':fecha,
														//'semestre':semestre,
														'periodo':periodo,
														'anio':anio,
														'observaciones':observaciones,
														'modificarSolicitudCd':modificarSolicitudCd,
														'accion':'nuevaSolicitudCd'
														}
									,'onSuccess': nuevaSolicitudCd
									,'url':'solicitudes/transaccion/transDirigidos.php'
									,'onError': function(req)
									{
										alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
									}
							}
							);
		}
	} else {
		alert ("Se encuentran campos sin especificar. Por favor verifique los datos");
	}
}

function nuevaSolicitudCd(req)
{
	var resp = eval("("+ req.responseText +")");
	if(resp!=false) {
		alert("Registro guardado satisfactoriamente. \nIMPORTANTE! esta solicitud estÃ¡ sujeta a revisiÃ³n por la comisiÃ³n asignada, por lo que debe esperar la desiciÃ³n del consejo");
		//limpiarDirigido();
		cambiar_cuerpo('solicitudes/cursos_dirigidos.php', 'cuerpo');
	} else {
		alert("Error! El curso dirigido no pudo ser registrado. Por favor verifique sus datos");
	}
}

////////////////////// PROCESAR CURSOS DIRIGIDOS ///////////////////

function guardarDirigidos() {
	var anyo = document.getElementById('anyo').value;
	var periodo = document.getElementById('periodo').value;
	var oficio = document.getElementById('oficio').value;
	var fecha_aprob = document.getElementById('fecha_aprob').value;
	
	var i, j=0, k=0;
	var seleccion=[]
	formulario = document.getElementById("formSolicitudesDirigidos");
	for (i=0; i<formulario.elements.length; i++) {
		var elemento = formulario.elements[i];
		if(elemento.type == "checkbox") {
			if(elemento.checked) {
				j=j+1;
				seleccion[k] = elemento.value;
				k++;
			}
		}
	}
	if ((anyo == 0) || (periodo == 0) || (oficio == '') || (fecha_aprob == '')) {
		alert('Ha dejado campos vacÃ­os o sin selccionar. Revise sus datos');
		return;
	} else if (j == 0) {
		alert('Debe seleccionar por lo menos un registro de la lista para procesar');
		return;
	} else if (confirm('Â¿Confirma que desea procesar los cursos dirigidos seleccionados?')) {
		AjaxRequest.post
							 (
								{'parameters':{'anyo':anyo,
		 											'periodo':periodo,
													'oficio':oficio,
													'fecha_aprob':fecha_aprob,
													'seleccion':seleccion,
													'accion':'aprobarDirigidos'}
												  ,'onSuccess': function(req){
														respGuardarDirigidos(req)
													}
												  ,'url':'solicitudes/transaccion/transDirigidos.php'
												  ,'onError': function(req)
													{
														 alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
													}
								}
							 );
	}
}

function respGuardarDirigidos(req) {
	var resp = eval("("+req.responseText+")");
	if(resp!=false) {
		alert("Los cursos dirigidos han sido registrados correctamente");
		limpiarDirigido();
	} else {
		alert("Error! Los cursos dirigidos no pudieron ser registrados. Por favor verifique sus datos");
	}
}

/*function limpiarDirigido() {
	var formulario = document.getElementById('fDirigidos');
	var tabla = document.getElementById('tablaSolicitudesDirigidos');
	formulario.reset();
	document.getElementById('todosDirigidos').disabled=true;
	tabla.innerHTML = '';
	tabla.innerHTML = 'No existen solicitudes realizadas';
}
*/
function cargarSolicitudesDirigidos() {
	var anyo = document.getElementById('anyo').value;
	var periodo = document.getElementById('periodo').value;
	
	AjaxRequest.post
												 (
													{'parameters':{ 'anyo':anyo,
																	'periodo':periodo,
																	'accion':'buscarDatosEstuDirigidos'}
													  ,'onSuccess': function(req){
													  	respCargarSolicitudesDirigidos(req)
													  }
													  ,'url':'solicitudes/transaccion/transDirigidos.php'
													  ,'onError': function(req)
														 {
															 alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
														 }
													}
												 );
}

function respCargarSolicitudesDirigidos(req)
{
	document.getElementById('todosDirigidos').disabled=false;
	var resp = eval("("+req.responseText+")");
	
	var tabla = document.getElementById('tablaSolicitudesDirigidos');
	var tbl = document.createElement("table");
	tbl.width='100%';
	var tblBody = document.createElement("tbody");
	
	if(resp.length<=0)
	{
		var row = document.createElement("tr");
		var cell1 = document.createElement("td");
		cell1.width='100%';
		cell1.setAttribute('align','center');
		var cellText1 = document.createTextNode('No existen solicitudes realizadas');
		cell1.appendChild(cellText1);
		row.appendChild(cell1);
		tblBody.appendChild(row);
		tbl.appendChild(tblBody);
		tabla.innerHTML='';
		tabla.appendChild(tbl);
		tbl.setAttribute("border", "0");
	}
	else
	{
		for(var i=0; i<resp.length; i++)
		{
			if(i%2==0) {
				color='#F3F3F3';
			} else {
				color='#DFE4FD';
			}
			// creates a table row
			var row = document.createElement("tr");
			row.setAttribute("id","filaTa"+i);
			row.setAttribute("onmouseover",'estiloSobre("filaTa'+i+'")');
			row.setAttribute("onmouseout",'estiloDeja("filaTa'+i+'","'+color+'")');
			
			var cell1 = document.createElement("td");
			var cell2 = document.createElement("td");
			var cell3 = document.createElement("td");
			var cell4 = document.createElement("td");
			
			cell1.width='2%';
			cell2.width='12%';
			cell3.width='42%';
			cell4.width='42%';
			
			var cellText1 = document.createElement("INPUT");
			cellText1.type = 'checkbox';
			cellText1.id = 'checks'+i;
			cellText1.value = resp[i]['cedula']+'||'+resp[i]['cod_asignatura'];
			cellText1.setAttribute('onclick','activarCheckDirigidoTotal()');
			
			var cellText2 = document.createTextNode(resp[i]['cedula']);
			var cellText3 = document.createTextNode(resp[i]['nombres']+' '+resp[i]['apellidos']);
			var cellText4 = document.createTextNode(resp[i]['nombre']);
			
			cell1.appendChild(cellText1);
			cell1.setAttribute('id','check'+''+i+'');
			cell1.setAttribute('class','columna');
			
			
			cell2.appendChild(cellText2);
			cell2.setAttribute('id','columna');
			cell2.setAttribute('align','left');
			
			cell3.appendChild(cellText3);
			cell3.setAttribute('id','columna');
			cell3.setAttribute('align','left');
			
			cell4.appendChild(cellText4);
			cell4.setAttribute('id','columna');
			cell4.setAttribute('align','left');
			
			row.appendChild(cell1);
			row.appendChild(cell2);
			row.appendChild(cell3);
			row.appendChild(cell4);
			
			row.setAttribute("bgcolor",color);
			row.setAttribute("style","cursor:pointer");
			tblBody.appendChild(row);
		}
		tabla.innerHTML='';
		tabla.appendChild(tbl);
		tbl.setAttribute("border", "0");
		tbl.setAttribute("class",'tabla');
		tbl.appendChild(tblBody);
	}
	
	if(resp.length==0)
	{
		document.getElementById('todosDirigidos').disabled=true;
	}
}

function retirarTodosDirigidos()
{
	c = document.getElementById('todosDirigidos').checked;
	var checkb = document.getElementById('formSolicitudesDirigidos');
	checkb.checkbox;
	
	if(c==true)
	{
		for (i=0; i<checkb.length; i++)
		{
			checkb[i].checked=true;
		}
	}
	else
	{
		for (i=0; i<checkb.length; i++)
		{
			checkb[i].checked=false;
		}
	}
}

function activarCheckDirigidoTotal() {
	var checkb = document.getElementById('formSolicitudesDirigidos');
	checkb.checkbox;
	var totalCheck=0;
	for (i=0; i<checkb.length; i++)
	{
		if (checkb[i].checked)
		{
			totalCheck++;
		}
	}
	if(totalCheck==checkb.length)
	{
		document.getElementById('todosDirigidos').checked=true;
	}
	else
	{
		document.getElementById('todosDirigidos').checked=false;
	}
}
//********************* NUEVAS FUNCIONES *************************************

function buscarCreditosInscritosDirigido()
{
	var cedEstu=document.getElementById('cedula').value;
	var op="buscarCredInscritos";
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"cedEstu":cedEstu,
			"accion":op
		 }
		,'onSuccess':mostrarCredInscrDirigido
		,'url':'solicitudes/transaccion/transDirigidos.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function mostrarCredInscrDirigido(req)
{
	var resp=eval("("+ req.responseText +")");
	var estudiante=document.getElementById('nombres').value;
	var cod=document.getElementById('asignaturas').value;
	var asig=cod.split("-");
	var cred=asig[0];
	var aux=cred.substring(6,7)
	var credAinsc=parseInt(resp)+parseInt(aux);
	document.getElementById('credInsc').value=parseInt(resp);
	
	if(parseInt(resp)>=18)
	{
		alert("Su carga crediticia es mayor o igual de la permitida. (CRÃ‰DITOS INSCRITOS "+resp+". CRÃ‰DITOS A INSCRIBIR "+credAinsc+"). Por favor verifique sus datos");
		//limpiarDirigido();
		document.getElementById('asignaturas').value=0;
	}
	else
	{
		buscarMedidasDirigido();
	}
}

function buscarMedidasDirigido()
{
	var cedEstu = document.getElementById('cedula').value;
	var codEsp = document.getElementById('cod_esp').value;
	var accion = "buscarMedidaDirigido";
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"cedEstu":cedEstu,
			"codEsp": codEsp,
			"accion":accion
		 }
		,'onSuccess':resultadoBuscarMedidasDirigido
		,'url':'solicitudes/transaccion/transDirigidos.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function resultadoBuscarMedidasDirigido(req)
{	
	var resp=eval("("+ req.responseText +")");
	var cedEstu = document.getElementById('cedula').value;
	var nomEstu = document.getElementById('nombres').value;
	var espEstu = document.getElementById('especialidad').value;
	
	if(resp.length>0)
	{
		if (resp[0]['tipo']=='P' || resp[0]['tipo']=='2')
		{
			alert("USTED HA SIDO AFECTADO POR MEDIDAS DE PERMANENCIA");
		}
		else if(resp[0]['tipo']=='R')
		{
			alert("USTED HA SIDO AFECTADO POR MEDIDAS DE REPITENCIA.");
		}
		else
		{
			alert("USTED HA SIDO AFECTADO POR MEDIDA ACADEMICA. NO PODRA REALIZAR SU SOLICITUD. REALICE SU SOLICITUD DE APELACIÃ“N");
		}
		document.getElementById('asignaturas').value=0;
	}
	else
	{
		buscarRepitenciasDirigido(cedEstu);
	}
}

function buscarRepitenciasDirigido(cedula)//***
{
	var op="repitenciasDirigido";
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"cedEstu":cedula,
			"accion":op
		 }
		,'onSuccess':mostrarRepitenciasDirigido
		,'url':'solicitudes/transaccion/transDirigidos.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function mostrarRepitenciasDirigido(req)
{
	var codAsig = document.getElementById('asignaturas').value;
	var nombre = document.getElementById('nombres').value;
	var resp = eval("("+ req.responseText +")");
	var credInsc=document.getElementById('credInsc').value;
	
	for(var i=0; i<resp.length; i++) {
		//alert(resp[i]['cedula']+' . '+resp[i]['cod_asignatura']+' . '+resp[i]['veces_repetidas']);
		if (parseInt(resp[i]['veces_repetidas'])>= 6)
		{
			alert('LA MATRÃCULA DEL ESTUDIANTE ('+nombre+') HA SIDO SUSPENDIDA. POSEE MEDIDA DE REPITENCIA '+resp[i]['veces_repetidas']);
			i = resp.length;
			limpiarDirigido();
		}
		else if(parseInt(resp[i]['veces_repetidas']) == 5)
		{
			alert('Debe inscribir UNICAMENTE la asignatura problema '+resp[i]['cod_asignatura']+'. POSEE REPITENCIA '+resp[i]['veces_repetidas']);
			if (codAsig != resp[i]['cod_asignatura'])
				limpiarDirigido();
			i = resp.length;
		}
		else if (parseInt(resp[i]['veces_repetidas']) == 4)
		{
			alert('Debe inscribir MÃXIMO 8 CRÃ‰DITOS INCLUYENDO la asignatura problema '+resp[i]['cod_asignatura']+'. POSEE REPITENCIA '+resp[i]['veces_repetidas']+'. CrÃ©ditos ya inscritos '+credInsc);
			
			if(credInsc==8)
			{
				alert("Ya usted posee sus 8 crÃ©ditos inscritos. No tiene derecho a inscribir ninguna otra asignatura");
				limpiarDirigido();
			}
			i = resp.length;
		}
		else if ((parseInt(resp[i]['veces_repetidas']) == 3) || (parseInt(resp[i]['veces_repetidas']) == 2) || (parseInt(resp[i]['veces_repetidas']) == 1))
		{
			alert('Debe inscribir de 12 a 18 crÃ©ditos INCLUYENDO la asignatura problema '+resp[i]['cod_asignatura']+'. POSEE REPITENCIA '+resp[i]['veces_repetidas']+'. Total de crÃ©ditos ya inscritos '+credInsc);
			i = resp.length;
		}
	}
}

function buscarCalificacionDirigido()
{
	var cod_nucleo=document.getElementById("nucleo").value;
	var cod=document.getElementById("asignaturas").value;

	var tp=cod.split("-");
	var cod_asig=tp[0];
	var tipo_pensum=tp[1];
	var cedula=document.getElementById("cedula").value;
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"codNucleo":cod_nucleo,
				"codAsig":cod_asig,
				"tipoPensum":tipo_pensum,
				"cedula":cedula,
				"accion":'buscarCalifDirigido'
		 }
		,'onSuccess':respuestaBuscarCalificacionDirigido
		,'url':'solicitudes/transaccion/transDirigidos.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);	
}

function respuestaBuscarCalificacionDirigido(req)
{
	var resp =eval ("("+ req.responseText +")");
	
	if(resp.length>0)
	{
		var cod=document.getElementById("asignaturas").value;
		
		var tp=cod.split("-");
		var nombAsig=tp[2];
		alert("La asignatura ("+resp[0]["cod_asignatura"]+") "+nombAsig+" se encuentra APROBADA, en el semestre "+resp[0]["periodo"]+"-"+resp[0]["anio"]+", en la secciÃ³n "+resp[0]["seccion"]+". Con una calificaciÃ³n de "+resp[0]["calificacion"]+" puntos. Verifique sus datos");
		document.getElementById('asignaturas').value='0';
	}
	else
	{
		buscarAsignaturaPensumDirigido()		
	}
}
	
function buscarAsignaturaPensumDirigido()
{
	var codEsp=document.getElementById('especialidad').value;
	var cod=document.getElementById('asignaturas').value;
	var c=cod.split("-")
	var codAsig=c[0];
	var accion="buscarAsigPensum";
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"codEsp":codEsp,
			"codAsig":codAsig,
			"accion":accion
		 }
		,'onSuccess':mostrarAsignaturaPensumDirigidos
		,'url':'solicitudes/transaccion/transDirigidos.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function mostrarAsignaturaPensumDirigidos(req)
{
	var resp=eval("("+ req.responseText +")");
	var asignatura=document.getElementById('asignaturas').value;
	var prerrequisito="";
	
	if(resp.length>0)
	{
		for(var i=0;i<resp.length;i++)
		{
			prerrequisito+=resp[i]['cod_prerrequisito']+"-";
		}
		buscarPrerrequisitoDirigido(prerrequisito);
	}
}


function buscarPrerrequisitoDirigido(prerrequisito)
{
	var cedEstu=document.getElementById('cedula').value;
	var cod=document.getElementById('asignaturas').value;
	var c=cod.split("-")
	var codAsig=c[0];
	var accion="validarPrerrequisito";
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"cedEstu":cedEstu,
			"codAsig":prerrequisito,
			"accion":accion
		 }
		,'onSuccess':resultadoPrerrequisitoDirigido
		,'url':'solicitudes/transaccion/transDirigidos.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function resultadoPrerrequisitoDirigido(req)
{
	var resp=eval("("+ req.responseText +")");
	var estudiante=document.getElementById('nombres').value;
	var cod=document.getElementById('asignaturas').value;
	var c=cod.split("-")
	var codAsig=c[0];
	
	if(resp==0)
	{
		alert("El estudiante ("+estudiante+") no cumple con el prerrequisito de la asignatura solicitada");
		//limpiarDirigidos();
		document.getElementById('asignaturas').value='0';
	}
	else
	{
		buscarInscritoDirigido();
	}

}

function buscarInscritoDirigido()
{
	var cedEstu=document.getElementById('cedula').value;
	var cod=document.getElementById('asignaturas').value;
	var c=cod.split("-")
	var codAsig=c[0];
	var accion="buscarAsigInscrita";
	
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
			"cedEstu":cedEstu,
			"codAsig":codAsig,
			"accion":accion
		 }
		,'onSuccess':resultadoBuscarInscritoDirigido
		,'url':'solicitudes/transaccion/transDirigidos.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
	
}

function resultadoBuscarInscritoDirigido(req)
{
	var resp=eval("("+ req.responseText +")");
	var estudiante=document.getElementById('nombres').value;
	var cod=document.getElementById('asignaturas').value;
	var c=cod.split("-")
	var codAsig=c[0];
	var credIns=document.getElementById('credInsc').value;
	
	if(resp.length>0)
	{
		if(!confirm("La asignatura ("+codAsig+") - "+c[2]+", se encuentra inscrita en el semestre actual. Si el curso dirigido es posteriormente aprobado la asignatura serÃ¡ eliminada del semestre en curso. Desea de igual forma solicitar el curso dirigido?"))
		{
			//limpiarDirigido();
			document.getElementById('asignaturas').value='0';
		}	
		
	}
	else
	{
		buscarCreditosInscritosDirigido();
	}
}

function verSolicitudDirigidos()
{
	var periodo=document.getElementById('sel_periodo').value;
	var anio=document.getElementById('sel_anio').value;
	var nucleo=document.getElementById('nucUsr').value;
	
	var ancho=900;
	var largo=600;
		
	var url="solicitudes/ver_solicitudes_dirigidos.php?periodo="+periodo+"&anio="+anio+"&codNucleo="+nucleo;
	popup(url,ancho,largo);
}

function generarPlanillaCd() {
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('nucleo').value;
	var codEsp = document.getElementById('especialidad').value;
	var url = "solicitudes/planillas/planilla_dirigido.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}