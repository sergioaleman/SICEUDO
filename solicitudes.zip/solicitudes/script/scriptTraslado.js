function guardarSolicitudTraslado()
{
	var cedEst=document.getElementById('txt_cedula').value;
	var codEsp=document.getElementById('sel_esp').value;
	var cambio=document.getElementById('sel_cambio').value;
	var cambioEsp=document.getElementById('sel_esp_traslado').value;
	var codNucleo=document.getElementById('cod_nucleo').value;
	var codNucSol=document.getElementById('sel_nucleo').value;
	var fechaSol=document.getElementById('fecha_solicitud').value;
	var periodo=document.getElementById('sel_periodo').value;
	var anio=document.getElementById('sel_anio').value;
	var obs=document.getElementById('txt_obs').value;
	var sw=0; var msj='';
	//alert(cambioEsp);
	
	if(cedEst=="") 
	{
		msj='IdentificaciÃ³n\n'; sw="1";
	}
	if(codEsp==0)
	{	
		msj+='Especialidad\n'; sw="1";
	}
	if(cambio==1 && cambioEsp==0)
	{	
		msj+='Especialidad\n'; sw="1";
	}
	if(codNucSol==0)
	{
		msj+='Nucleo Solicitado\n'; sw="1";
	}
	if(codNucleo=="")
	{
		msj+='Nucleo Actual\n'; sw="1";
	}
	if(fechaSol=="")
	{
		msj+='Fecha Solicitud\n'; sw="1";
	}
	if(periodo==0)
	{
		msj+='Periodo\n'; sw="1";
	}
	if(anio==0)
	{
		msj+='AÃ±o\n'; sw="1";
	}
	if(obs=="")
	{
	    msj+='Observacion\n'; sw="1";
	}
	
	if(sw==0)
	{
			if(confirm("Â¿Esta seguro que desea guardar los cambios realizados?"))	
			{
				AjaxRequest.post
				(       
					{
					'parameters':
					 {
						"cedEstu":cedEst,
						"codEsp":codEsp,
						"cambio":cambio,
						"cambioEsp":cambioEsp,
						"codNucSol":codNucSol,
						"codNucleo":codNucleo,
						"fechaSol":fechaSol,
						"periodo":periodo,
						"anio":anio,
						"obs":obs,
						"op":"insertar"
					 }
					,'onSuccess':respuestaTraslado
					,'url':'solicitudes/transaccion/transTraslado.php'
					,'onError':function(req)
						{ 
							alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						}
					}
				);
			}
	
	}
	else
	{
		alert("Ha dejado campos vacios que son necesarios para realizar el registro. Verifique los siguientes datos:\n"+msj);
	}

}

function respuestaTraslado(req)
{
	var resp=eval("("+ req.responseText +")");
	
	if(resp!=false)
	{
		alert("Los datos del Traslado de Nucleo fueron guardados con Ã©xito. Imprime tu Constancia a continuacion");
		limpiarFormTraslado();
	}
	else
	{
		alert("Error al guardar sus datos. \n\nPor favor verifique si la especialidad solicitada corresponde al nÃºcleo destino");
	}
}

function cargarEspecialidadTraslado()
{
	var codNucleo=document.getElementById('sel_nucleo').value;
	
	AjaxRequest.post
    (       
		{
			'parameters':
					 {
						"codNucleo":codNucleo,
						"op":"buscarEspTraslado"
					 }
					,'onSuccess':respuestaCargarEspecialidadTraslado
					,'url':'solicitudes/transaccion/transTraslado.php'
					,'onError':function(req)
						{ 
							alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						}
		}
	);
	
}

function respuestaCargarEspecialidadTraslado(req)
{
	var resp=eval("("+ req.responseText +")");
	
	document.getElementById("sel_esp_traslado").options.length=0;
	document.getElementById("sel_esp_traslado").options[0]= new Option("Seleccione.."); 
	document.getElementById("sel_esp_traslado").options[0].value='0';
	
	if(resp!=false)
	{
		for(var i=0,j=1;i<resp.length;i++,j++)
		{
			document.getElementById("sel_esp_traslado").options[j]= new Option(resp[i]['nombre']); 
			document.getElementById("sel_esp_traslado").options[j].value=resp[i]['codigo'];
		}
	}
	else
	{
		alert("Error. No existen especialidades asociadas al nÃºcleo seleccionado");
	}
}

function generarPlanillaTraslado()
{
	var url="solicitudes/planillas/planilla_traslado.php";
	openMyModal(url);
}

function limpiarFormTraslado()
{
	cambiar_cuerpo('solicitudes/traslado.php', 'cuerpo');
}