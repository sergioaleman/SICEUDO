function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}


function eliminame(tipo){
	
	var especialidad = document.getElementById('cod_esp').value;
	var codigo = document.getElementById('txt_codigo_'+tipo).value;
	
	if(codigo==''){ alert("Debes introducir el cÃ³digo de validaciÃ³n"); return;}
	
	if (confirm("Estas seguro que deseas eliminar tu solicitud de "+tipo+" ? ")) {
		AjaxRequest.post({
			'parameters': {		'cod_esp':especialidad,
								'codigo': codigo,
								'accion':tipo
								}
			,'onSuccess': respuesta_eliminame
			,'url':'solicitudes/transaccion/trans_AnulaSolicitudes.php'
			,'onError': function(req){
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
			}
		);
	}
	else return;
}


function respuesta_eliminame(req)
{
	if(req.responseText!=false)
	{
		var miDiv = document.getElementById(req.responseText.trim());
		miDiv.innerHTML ="<img src='imagenes/ingresar.png' align='middle'><strom><font color ='#0066CC'>Solicitud ANULADA</font></strom>";
		alert("Tu solicitud ha sido anulada");
	}
	else
	{
		alert("Error! \nSu cÃ³digo de validaciÃ³n no coincide con el enviado. Revisa tus datos e intentalo nuevamente");
		return;
	}
}

function anular(accion,tipo){
	var especialidad = document.getElementById('cod_esp').value;
	var correo = document.getElementById('txt_correo').value;
	if(correo==''){ alert("Tu correo no esta actualizado. Debes pasar por las taquillas de DACE"); return;}
	
	if (confirm("Estas seguro que deseas anular tu solicitud de "+tipo+" ? ")) {
		AjaxRequest.post({
			'parameters': {		'cod_esp':especialidad,
								'tipo':tipo,
								'accion':accion
								}
			,'onSuccess': respuesta_anular
			,'url':'solicitudes/transaccion/trans_AnulaSolicitudes.php'
			,'onError': function(req){
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
			}
		);
	}
	else return;
}


function respuesta_anular(req)
{
	if(req.responseText!=false)
	{
	    alert("Tu solicitud necesita ser confirmada!! \nPara confirmar, revisa en tu correo electrÃ³nico e introduce el cÃ³digo enviado");
		cambiar_cuerpo('solicitudes/anulacion_solicitud.php','cuerpo');
	}
	else
	{
		alert("Algo salio mal! \nIntentalo nuevamente");
		cambiar_cuerpo('solicitudes/anulacion_solicitud.php','cuerpo');
	}
	
}