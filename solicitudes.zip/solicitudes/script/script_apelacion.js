function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function generarPlanillaApelacion() {
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('nucleo').value;
	var codEsp = document.getElementById('cod_esp').value;
	var url = "solicitudes/planillas/planilla_apelacion.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}

function enviarApelacion()
{	
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var motivo       = document.getElementById("motivo").value;
	var justifique   = document.getElementById("justifique").value;
	var concepto     = document.getElementById("concepto").value;
	var arancel      = parseFloat(document.getElementById("arancel").value);
	var saldo        = parseFloat(document.getElementById("saldo").value);

	var mensaje = "Â¿Confirma registrar la apelaciÃ³n?" ;
	if (saldo < arancel) {
		alert('Usted no tiene saldo suficiente\n El monto del arancel es BsF. '+arancel);
		return;
	} else if (motivo == "-1") {
		alert('Usted debe seleccionar un Motivo de apelaciÃ³n\n Por favor verifique sus datos');
		return;
	} else if (justifique == "") {
		alert('Usted debe Justificar su apelaciÃ³n\n Por favor verifique sus datos');
		return;
	} else if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'nucleo':nucleo,
													'cod_esp':especialidad,
													'motivo':motivo,
													'justif':justifique,
													'concep':concepto,
													'arancel':arancel,
													'accion':'validarApelacion'
													}
								,'onSuccess': respValidarApelacion
								,'url':'solicitudes/transaccion/trans_apelacion.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function respValidarApelacion(req)
{	
	var cedula = document.getElementById("cedula").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		alert ('Se ha registrado correctamente la solicitud de apelaciÃ³n');
		cambiar_cuerpo('solicitudes/apelacion.php', 'cuerpo');
	} else {
		alert("...ERROR! Su apelaciÃ³n no pudo ser registrada \n Por favor revise los datos suministrados");
		return;
	}
}