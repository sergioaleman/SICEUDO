function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function generarPlanillaCambioEspecialidad() {
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('nucleo').value;
	var codEsp = document.getElementById('cod_esp').value;
	var url = "solicitudes/planillas/planilla_cambio_esp.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}

function enviarCambioEspecialidad()
{	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var esp_solicitada = document.getElementById("esp_solicitada").value;
	var motivo       = document.getElementById("motivo").value;
	var concepto     = document.getElementById("concepto").value;
	var arancel      = parseFloat(document.getElementById("arancel").value);
	var saldo        = parseFloat(document.getElementById("saldo").value);
	
	var mensaje = "Â¿Confirma registrar el cambio de especialidad?" ;
    if (saldo < arancel) {
		alert('Usted no tiene saldo suficiente\n El monto del arancel es BsF. '+arancel);
		return;
	} else if (motivo == "") {
		alert('Usted debe especificar el Motivo del cambio de especialidad\n Por favor verifique sus datos');
		return;
	} else if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'nucleo':nucleo,
													'cod_esp':especialidad,
													'cod_sol':esp_solicitada,
													'motivo':motivo,
													'concep':concepto,
													'arancel':arancel,
													'accion':'validarCambioEspecialidad'
													}
								,'onSuccess': respValidarCambioEspecialidad
								,'url':'solicitudes/transaccion/trans_cambio_esp.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function respValidarCambioEspecialidad(req)
{	
	var cedula = document.getElementById("cedula").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		alert ('Se ha registrado correctamente la solicitud de cambio de  especialidad');
		cambiar_cuerpo('solicitudes/cambio_especialidad.php', 'cuerpo');
	} else {
		alert("ERROR! \n\nSu solicitud de CAMBIO DE ESPECIALIDAD no pudo ser registrada. Por favor verifique sus datos\n");
		return;
	}
}