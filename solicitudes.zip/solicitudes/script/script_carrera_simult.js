function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function generarPlanillaCarreraSimultanea() {
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('nucleo').value;
	var codEsp = document.getElementById('cod_esp').value;
	var url = "solicitudes/planillas/planilla_carrera_simult.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}

function enviarCarreraSimultanea()
{	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var esp_solicitada = document.getElementById("esp_solicitada").value;
	var motivo       = document.getElementById("motivo").value;
	var concepto     = document.getElementById("concepto").value;
	var arancel      = parseFloat(document.getElementById("arancel").value);
	var saldo        = parseFloat(document.getElementById("saldo").value);

	var mensaje = "Â¿Confirma registrar la carrera simultanea?" ;
    if (saldo < arancel) {
		alert('Usted no tiene saldo suficiente\n El monto del arancel es BsF. '+arancel);
		return;
	} else     if (motivo == "") {
		alert('Usted debe especificar el Motivo de la carrera simultanea\n Por favor verifique sus datos');
		return;
	} else if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'nucleo':nucleo,
													'cod_esp':especialidad,
													'cod_sol':esp_solicitada,
													'motivo':motivo,
													'concep':concepto,
													'arancel':arancel,
													'accion':'validarCarreraSimultanea'
													}
								,'onSuccess': respValidarCarreraSimultanea
								,'url':'solicitudes/transaccion/trans_carrera_simult.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function respValidarCarreraSimultanea(req)
{	
	var cedula = document.getElementById("cedula").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		alert ('Se ha registrado correctamente la solicitud de carrera simultanea');
		cambiar_cuerpo('solicitudes/carrera_simultanea.php', 'cuerpo');
	} else {
		alert("...ERROR! Su solicitud de carrera simultanea no pudo ser registrada \n Por favor revise los datos suministrados");
		return;
	}
}