function cargarSeccionesEx() {
	var nucleo = document.getElementById('nucleo').value;
	var especialidad = document.getElementById('cod_esp').value;
	var asignatura = document.getElementById('asignatura').value;
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
		 	 "nucleo": nucleo,
			 "especialidad": especialidad,
			 "asignatura": asignatura,
			 "accion": 'buscarSecciones'
		 }
		,'onSuccess':respMostrarSeccionesEx
		,'url':'solicitudes/transaccion/trans_excesos.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function respMostrarSeccionesEx(req)
{
	var resp = eval ("("+ req.responseText +")");
	document.getElementById('seccion').options.length=0;
	document.getElementById('seccion').options[0]= new Option('*** SELECCIONE LA SECCIÃ“N ***');
	document.getElementById('seccion').options[0].value='-1';
	document.getElementById('seccion').options[0].selected = true;
	if(resp.length > 0)
	{
		for(var i=1,j=0; j<resp.length; i++,j++) {
			document.getElementById('seccion').options[i]= new Option('SECCIÃ“N '+resp[j]['seccion']);
			document.getElementById('seccion').options[i].value = resp[j]['seccion'];
		}
	}
	else
	{
		alert("No existen secciones planificadas para la asignatura seleccionada");
		limpiarExcesos();
	}
}

function inscribir_asignaturaEx()
{
	var mensaje      = '';
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var asignatura   = document.getElementById("asignatura").value;
	var seccion      = document.getElementById("seccion");
	var maxCred      = document.getElementById("max_cred").value;
	var inscritos    = document.getElementById("inscritos").value;
	var solicitados  = document.getElementById("solicitados").value;
	
	if (asignatura == '-1') {
		alert('Debes seleccionar la asignatura');
		return;
	} else if (seccion.value == '-1') {
		alert('Debes seleccionar la secciÃ³n');
		return;		
	/*} else if (parseInt(inscritos) + parseInt(solicitados) + parseInt(asignatura.substring(6,7)) <= 10) {
		alert('La solicitud de la asignatura '+asignatura+' no genera exceso de crÃ©ditos. Por favor revisa los datos suministrados');
		limpiarExcesos();
		return;*/
	} else if (parseInt(inscritos) + parseInt(solicitados) + parseInt(asignatura.substring(6,7)) > parseInt(maxCred)) {
		alert('La solicitud de la asignatura '+asignatura+' genera mÃ¡s de '+parseInt(maxCred)+' crÃ©ditos. Por favor revisa los datos suministrados');
		limpiarExcesos();
		return;
	}
	if ((seccion.value=='95') || (seccion.value=='98')) {
		alert ("SECCIÃ“N NO DISPONIBLE EN EL PROCESO DE SOLICITUDES");
		return;
	}

	mensaje = "Â¿Desea solicitar la asignatura ("+asignatura+") en la secciÃ³n ("+seccion.value+")?";

	if(!confirm(mensaje)) {
		return;
	} else if ((parseInt(inscritos) + parseInt(solicitados) + parseInt(asignatura.substring(6,7))) > parseInt(maxCred)) {
		alert ("No puedes quedar con una carga mayor a ( "+maxCred+" ) unidades de crÃ©ditos");
		limpiarExcesos();
		return;
	} else {
		AjaxRequest.post(
			{
			'parameters': {		'cedula':cedula,
								'cod_esp':especialidad,
								'nucleo':nucleo,
								'asignatura':asignatura,
								'seccion':seccion.value,
								'accion':'nuevaInscripcionEX'
								}
			,'onSuccess': nuevaInscripcionEx
			,'url':'solicitudes/transaccion/trans_excesos.php'
			,'onError': function(req)
			{
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
			}
		);
	}
}

function nuevaInscripcionEx(req)
{
	var seccion = document.getElementById("seccion");
	var resp = eval ("("+ req.responseText +")");
	
	if(resp == false) {
		alert("Error. La asignatura no pudo ser registrada. Por favor revisa los datos suministrados!");
	}
	limpiarExcesos();
}

function eliminar_asignaturaEx(asignatura) {
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	mensaje = "Â¿Confirma que desea eliminar la solicitud de la asignatura ("+asignatura+")?";
	
	if(!confirm(mensaje)) {
		return;
	} else {
		AjaxRequest.post(
			{
			'parameters': {		'cedula':cedula,
								'cod_esp':especialidad,
								'nucleo':nucleo,
								'asignatura':asignatura,
								'accion':'eliminarAsigEX'
								}
			,'onSuccess': respEliminar_asignaturaEx
			,'url':'solicitudes/transaccion/trans_excesos.php'
			,'onError': function(req)
			{
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
			}
		);
	}
}

function respEliminar_asignaturaEx(req)
{
	var seccion = document.getElementById("seccion");
	var resp = eval ("("+ req.responseText +")");
	
	if(resp == false) {
		alert("La solicitud de la asignatura no pudo ser eliminada!");
	}
	limpiarExcesos();
}

function MostrarInscripcionEx()
{
	AjaxRequest.post({
						
						'onSuccess': respMostrarInscripcionEx,
						'url': 'solicitudes/visualizaSolicitudEx.php',
						'onError': function(req){
							alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
		}
	});
}

function respMostrarInscripcionEx(req)
{
	var inscripcion=document.getElementById('tablaInscritas');
	inscripcion.innerHTML='';
	inscripcion.innerHTML=req.responseText;
}

function limpiarExcesos() {
	cambiar_cuerpo('solicitudes/excesos_creditos.php', 'cuerpo');
}

function generarPlanillaEx() {
	var i, j=0;
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('nucleo').value;
	var codEsp = document.getElementById('cod_esp').value;
	var url = "solicitudes/planillas/planilla_exceso.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}

function confirmarSolicitudEx()
{	
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var solicitados  = document.getElementById("solicitados").value;
	var mensaje = "Â¿Confirma registrar la solicitud de exceso de crÃ©ditos del estudiante ("+cedula+")?";
	
	if (solicitados == '0') {
		alert('Debes solicitar por lo menos una asignatura. Por favor verifica tus datos!');
		return;
	} else if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'cod_esp':especialidad,
													'nucleo':nucleo,
													'accion':'validarSolicitudEx'
													}
								,'onSuccess': respConfirmarSolicitudEx
								,'url':'solicitudes/transaccion/trans_excesos.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function respConfirmarSolicitudEx(req)
{	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		alert("Tu solicitud fue registrada correctamente");
		limpiarExcesos();
	} else {
		alert("ERROR! Tu solicitud no pudo ser registrada. Por favor revisa los datos suministrados");
		return;
	}
}

function registrarSolicitudEx() {
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var observacion  = document.getElementById("obs_solicitud").value;
	
	AjaxRequest.post(
						{
								'parameters': { 'cedula':cedula,
												'cod_esp':especialidad,
												'nucleo':nucleo,
												'observacion':observacion,
												'accion':'regSolicitudEx'
												}
								,'onSuccess': respRegSolicitudEx
								,'url':'solicitudes/transaccion/trans_excesos.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);		
}

function respRegSolicitudEx(req)
{
	var resp = eval ("("+ req.responseText +")");
	if (resp == false) {
		alert("ERROR! Tu solicitud no pudo ser registrada. Por favor revisa los datos suministrados");
		return;
	}
}