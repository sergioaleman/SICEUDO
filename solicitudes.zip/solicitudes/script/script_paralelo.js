function cargarSeccionesPa() {
	var nucleo = document.getElementById('nucleo').value;
	var especialidad = document.getElementById('especialidad').value;
	var asignatura = document.getElementById('asignatura').value;
	AjaxRequest.post
	(       
		{
		'parameters':
		 {
		 	 "nucleo": nucleo,
			 "especialidad": especialidad,
			 "asignatura": asignatura,
			 "accion": 'buscarSecciones'
		 }
		,'onSuccess':respMostrarSeccionesPa
		,'url':'solicitudes/transaccion/trans_paralelo.php'
		,'onError':function(req)
			{ 
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
	);
}

function respMostrarSeccionesPa(req)
{
	var resp = eval ("("+ req.responseText +")");
	document.getElementById('seccion').options.length=0;
	document.getElementById('seccion').options[0]= new Option('*** SELECCIONE LA SECCIÃ“N ***');
	document.getElementById('seccion').options[0].value='-1';
	document.getElementById('seccion').options[0].selected = true;
	if(resp.length > 0)
	{
		for(var i=1,j=0; j<resp.length; i++,j++) {
			document.getElementById('seccion').options[i]= new Option('SECCIÃ“N '+resp[j]['seccion']);
			document.getElementById('seccion').options[i].value = resp[j]['seccion'];
		}
	}
	else
	{
		alert("No existen secciones planificadas para la asignatura seleccionada");
		limpiarParalelos();
	}
}

function limpiarParalelos() { 
	cambiar_cuerpo('solicitudes/paralelos.php', 'cuerpo');
}

function inscribir_asignaturaPa() {
	var cedula       = document.getElementById("cedula").value;
	var nucleo       = document.getElementById("nucleo").value;
	var especialidad = document.getElementById("especialidad").value;
	var asignatura   = document.getElementById('asignatura').value;
	var seccion      = document.getElementById('seccion');
	var inscritos    = document.getElementById('inscritos').value;
	var solicitados  = document.getElementById('solicitados').value;
	var credAsig     = asignatura.substr(6,1);
	var sw = 0;
	var exceso = 0;
	
	if (asignatura == '-1') {
		alert('Debes seleccionar la asignatura');
		return;
	} else if (seccion.value == '-1') {
		alert('Debes seleccionar la secciÃ³n');
		return;		
	}
	if ((seccion.value=='95') || (seccion.value=='98')) {
		alert ("SECCIÃ“N NO DISPONIBLE EN EL PROCESO DE SOLICITUDES");
		return;
	}	
	if ((parseInt(inscritos) + parseInt(solicitados) + parseInt(credAsig)) > 18) {
		sw = 1;
		exceso = 1;
	}
	if (sw == 0) {
		var mensaje = "Â¿Confirma que desea solicitar en paralelo la asignatura ("+asignatura+") en la secciÃ³n ("+seccion.value+")?";
	} else {
		var mensaje = "La asignatura ("+asignatura+") en paralelo, genera adicionalmente un exceso de cÅ•editos. Â¿Desea continuar con la operaciÃ³n?";
	}	
	if(confirm(mensaje)) {
			AjaxRequest.post
			(       
					{
					'parameters':
					{
						 "cedula": cedula,
						 "nucleo": nucleo,
						 "especialidad": especialidad,
						 "asignatura": asignatura,
						 "seccion": seccion.value,
						 "exceso": exceso,
						 "accion": 'registrarParalelo'
					 }
					,'onSuccess':respInscribir_asignaturaPa
					,'url':'solicitudes/transaccion/trans_paralelo.php'
					,'onError':function(req)
						{ 
							alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
						}
					}
			);
	}	
}

function respInscribir_asignaturaPa(req) {
	var resp = eval ("("+ req.responseText +")");

	if(resp == false) {
		alert("Error. La asignatura no pudo ser registrada. Por favor revisa los datos suministrados!");
	}
	limpiarParalelos();
}

function eliminar_asignaturaPa(asignatura) {
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	mensaje = "Â¿Confirma que desea eliminar la solicitud de la asignatura ("+asignatura+")?";
	
	if(!confirm(mensaje)) {
		return;
	} else {
		AjaxRequest.post(
			{
			'parameters': {		'cedula':cedula,
								'cod_esp':especialidad,
								'nucleo':nucleo,
								'asignatura':asignatura,
								'accion':'eliminarAsigPA'
								}
			,'onSuccess': respEliminar_asignaturaPa
			,'url':'solicitudes/transaccion/trans_paralelo.php'
			,'onError': function(req)
			{
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
			}
		);
	}
}

function respEliminar_asignaturaPa(req)
{
	var seccion = document.getElementById("seccion");
	var resp = eval ("("+ req.responseText +")");
	
	if(resp == false) {
		alert("La solicitud de la asignatura no pudo ser eliminada!");
	}
	limpiarParalelos();
}

function registrarSolicitudPa() {
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var observacion  = document.getElementById("obs_solicitud").value;
	var asignatura   = document.getElementById('asignatura').value;
	var inscritos    = document.getElementById('inscritos').value;
	var solicitados  = document.getElementById('solicitados').value;
	var credAsig     = asignatura.substr(6,1);
	var exceso       = 0;
	
	if ((parseInt(inscritos) + parseInt(solicitados) + parseInt(credAsig)) > 18) { exceso = 1; }	
	
	AjaxRequest.post(
						{
								'parameters': { 'cedula':cedula,
												'cod_esp':especialidad,
												'nucleo':nucleo,
												'observacion':observacion,
												"exceso": exceso,
												'accion':'regSolicitudPa'
												}
								,'onSuccess': respRegSolicitudPa
								,'url':'solicitudes/transaccion/trans_paralelo.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);		
}

function respRegSolicitudPa(req)
{
	var resp = eval ("("+ req.responseText +")");
	if (resp == false) {
		alert("ERROR! Tu solicitud no pudo ser registrada. Por favor revisa los datos suministrados");
		return;
	}
}

function confirmarSolicitudPa()
{	
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var solicitados  = document.getElementById("solicitados").value;
	var mensaje = "Â¿Confirma registrar la solicitud de asignaturas en paralelo del estudiante ("+cedula+")?";
	
	if (solicitados == '0') {
		alert('Debes solicitar por lo menos una asignatura. Por favor verifica tus datos!');
		return;
	} else if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'cod_esp':especialidad,
													'nucleo':nucleo,
													'accion':'validarSolicitudPa'
													}
								,'onSuccess': respConfirmarSolicitudPa
								,'url':'solicitudes/transaccion/trans_paralelo.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function respConfirmarSolicitudPa(req)
{	
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		alert("Tu solicitud fue registrada correctamente");
		limpiarParalelos();
	} else {
		alert("ERROR! Tu solicitud no pudo ser registrada. Por favor revisa los datos suministrados");
		return;
	}
}

function generarPlanillaPa() {
	var i, j=0;
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('nucleo').value;
	var codEsp = document.getElementById('especialidad').value;
	var url = "solicitudes/planillas/planilla_paralelo.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}