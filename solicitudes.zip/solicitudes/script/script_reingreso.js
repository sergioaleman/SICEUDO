function generarPlanillaReingreso() {
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('nucleo').value;
	var codEsp = document.getElementById('cod_esp').value;
	var url = "solicitudes/planillas/planilla_reingreso.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}

function enviarReingreso()
{	
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var motivo       = document.getElementById("motivo").value;
	var concepto     = document.getElementById("concepto").value;
	var arancel      = parseFloat(document.getElementById("arancel").value);
	var saldo        = parseFloat(document.getElementById("saldo").value);

	var mensaje = "Â¿Confirma registrar el reingreso?" ;
	if (saldo < arancel) {
		alert('Usted no tiene saldo suficiente\n El monto del arancel es BsF. '+arancel);
		return;
	} else if (motivo == "-1") {
		alert('Usted debe seleccionar un Motivo de interrupciÃ³n de los estudios\n Por favor verifique sus datos');
		return;
	} else if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'nucleo':nucleo,
													'cod_esp':especialidad,
													'motivo':motivo,
													'concep':concepto,
													'arancel':arancel,
													'accion':'validarReingreso'
													}
								,'onSuccess': respValidarReingreso
								,'url':'solicitudes/transaccion/trans_reingreso.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function respValidarReingreso(req)
{	
	var cedula = document.getElementById("cedula").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		alert ('Se ha registrado correctamente la solicitud de reingreso');
		cambiar_cuerpo('solicitudes/reingreso.php', 'cuerpo');
	} else {
		alert("...ERROR! Su reingreso no pudo ser registrado \n Por favor revise los datos suministrados");
		return;
	}
}