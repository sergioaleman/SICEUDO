function abrirAjax()
{ 
	var xmlhttp = false;
	try
	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)
		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function permitirRetiro(val) {
	var elementos = document.getElementById('frmRetiro').elements;
	var longitud = document.getElementById('frmRetiro').length;

	for (i=0; i<longitud; i++) 
	{
		if(elementos[i].name.substring(0, 6) == "accion")
		{
			// no permitir mas retiros
			if (!val && elementos[i].selectedIndex == 0) elementos[i].disabled = true;							
			// permitir mas retiros
			if (val) elementos[i].disabled = false;							
		}
	}
}

function modificarRetiroParcial(nro)
{
	var cedula   = document.getElementById("cedula").value;
	var codigo   = document.getElementById("codigo"+nro).value;
	var tipo_pensum= document.getElementById("tipo_pensum"+nro).value;
	var seccion  = document.getElementById("seccion"+nro).value;
	var creditos = document.getElementById("creditos"+nro).value;
	var retirar  = document.getElementById("accion"+nro).value;
	
	var saldo    = document.getElementById("saldo").value;
	var total    = document.getElementById("tot_arancel").value;
	var costo    = document.getElementById("arancel").value;
	var ranterior= document.getElementById("aanterior"+nro).value;
	/**********************************/
	var it_tot = document.getElementById("tot_arancel");
	var it_ant = document.getElementById("aanterior"+nro);
	var it_xret = document.getElementById("asign_x_retirar");
    
	if(retirar > ranterior) { 
		it_tot.value = parseFloat(total)+parseFloat(costo); 
		it_xret.value = parseInt(it_xret.value) - 1;
	}
	if(retirar < ranterior) { 
		it_tot.value = parseFloat(total)-parseFloat(costo); 
		it_xret.value = parseInt(it_xret.value) + 1;
	}
	it_ant.value = retirar;
	/**********************************/
	// no mas retiros si no hay saldo
	if((saldo-it_tot.value)<=0) permitirRetiro(false);
	else {
		// no permite retiros totales
		if((it_xret.value)<=1) permitirRetiro(false); 
		else permitirRetiro(true); 
	}
	/**********************************/

	AjaxRequest.post({
							'parameters': { 'cedula':cedula,
											'codigo':codigo,
											'tipo_pensum':tipo_pensum,
											'seccion':seccion,
											'creditos':creditos,
											'retirar':retirar,
											'accion':'modificarRetiroParcial'
											}
							,'onSuccess': nuevoRetiroParcial
							,'url':'solicitudes/transaccion/trans_retiro.php'
							,'onError': function(req)
							{
								alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								return false;
							}
					});
}

function nuevoRetiroParcial(req)
{
	var resp=eval ("("+ req.responseText +")");
	
	if(resp==false) { alert("la solicitud no pudo ser registrada"); return false; }
	else mostrarRetiroParcial();	
}

function mostrarRetiroParcial()
{
	var cedula   = document.getElementById('cedula').value;
	
	AjaxRequest.post({
						'onSuccess': respMostrarRetiroParcial,
						'url': 'solicitudes/retiro_parcialVista.php?cedula='+cedula,
						'onError': function(req){
							alert('Error!\nStatusText=' + req.statusText + '\nContents=' + req.responseText);
							return false;
						}
				});
}

function respMostrarRetiroParcial(req)
{
	var inscripcion=document.getElementById('tablaRetiradas');
	inscripcion.innerHTML='';
	inscripcion.innerHTML=req.responseText;
}

function enviarRetiroParcial()
{
	var cedula  = document.getElementById("cedula").value;
	var nucleo  = document.getElementById("nucleo").value;
	var especialidad = document.getElementById("especialidad").value;
	var motivo = document.getElementById("motivo").value;
	var creditos = document.getElementById("total").value;
	var mensaje = "Â¿Confirma registrar la solicitud?" ;
	if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'nucleo':nucleo,
													'cod_esp':especialidad,
													'motivo':motivo,
													'credret':creditos,
													'accion':'validarRetiroParcial'
													}
								,'onSuccess': respValidarRetiroParcial
								,'url':'solicitudes/transaccion/trans_retiro.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}
function respValidarRetiroParcial(req)
{	
	var cedula = document.getElementById("cedula").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp != false) {
		alert("Solicitud registrada exitosamente!");
		cambiar_cuerpo('solicitudes/retiro_parcial.php', 'cuerpo');
	} else {
		alert("...ERROR! Su solicitud no pudo ser registrada");
		return;
	}
}

function generarPlanillaRetiroParcial() {
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('nucleo').value;
	var codEsp = document.getElementById('cod_esp').value;
	var url = "solicitudes/planillas/planilla_retiro_parcial.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}

function enviarRetiroTotal()
{	
	var cedula       = document.getElementById("cedula").value;
	var especialidad = document.getElementById("especialidad").value;
	var nucleo       = document.getElementById("nucleo").value;
	var motivo       = document.getElementById("motivo").value;
	var justifique   = document.getElementById("justifique").value;

	var mensaje = "Â¿Confirma registrar el retiro total?" ;
    if (motivo == "-1") {
		alert('Usted debe seleccionar un Motivo del retiro total\n Por favor verifique sus datos');
		return;
	} else if (justifique == "") {
		alert('Usted debe Justificar su retiro total\n Por favor verifique sus datos');
		return;
	} else if(confirm(mensaje)) {
		AjaxRequest.post(
						{
								'parameters': {     'cedula':cedula,
													'nucleo':nucleo,
													'cod_esp':especialidad,
													'motivo':motivo,
													'justif':justifique,
													'accion':'validarRetiroTotal'
													}
								,'onSuccess': respValidarRetiroTotal
								,'url':'solicitudes/transaccion/trans_retiro.php'
								,'onError': function(req)
								{
									alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
								}
						}
						);
	}
}

function respValidarRetiroTotal(req)
{	
	var cedula = document.getElementById("cedula").value;
	var resp = eval ("("+ req.responseText +")");
	if(resp[0].arancel == "VALIDO") {
		alert ('Se ha registrado correctamente la solicitud de retiro total...');
		cambiar_cuerpo('solicitudes/retiro_total.php', 'cuerpo');
	} else {
		alert("...ERROR! Su retiro total no pudo ser registrado ("+resp[0].arancel+") \n Por favor revise los datos suministrados...");
		return;
	}
}

function generarPlanillaRetiroTotal() {
	var cedula = document.getElementById('cedula').value;
	var codNucleo = document.getElementById('nucleo').value;
	var codEsp = document.getElementById('cod_esp').value;
	var url = "solicitudes/planillas/planilla_retiro_total.php?nucleo="+codNucleo+"&esp="+codEsp+"&cedula="+cedula;
	openMyModal(url);
}