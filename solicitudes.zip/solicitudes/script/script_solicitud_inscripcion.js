function isset( obj ) {
  if (typeof(eval(obj)) != 'undefined')
     if (eval(obj) != null)
         return true;
    return false;
   }
   

function abrirAjax(){ 
	var xmlhttp = false;
	try	{
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)	{
		try		{
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E)		{
			if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();
		}
	}
	return xmlhttp;
}

function buscarSeccionesPlanificadas(){
	var opcion = document.getElementById("opcion").value;
	var periodo = document.getElementById("periodo").value;	
	// validar secciones
	if (opcion!='0') {
	   	AjaxRequest.post( {
				'parameters': { 				   
					'cod_asig':opcion,
					'per':periodo,
					'accion':'buscarSeccionPlanificada'
					}
				,'onSuccess': respuestaBuscarSeccion
				,'url':'solicitudes/transaccion/transSolicitudInscripcion.php'
				,'onError': function(req)
				{
					alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
				}
			}
			);		
	}
	else { alert ("error en datos");	}
	}

function respuestaBuscarSeccion (req){
	var resp = eval ("("+ req.responseText +")");
	var secc1 = document.getElementById("seccion1");
	var secc2 = document.getElementById("seccion2");
	secc1.options.length = 0;
	secc2.options.length = 0;		
	for (var i=0;i< resp.length; i++){	
	 var option = document.createElement("option");	
		option.text = resp[i].seccion;
		secc1.add(option);
	}
	for (var i=0; i<resp.length; i++){	
	 var option = document.createElement("option");	
		option.text = resp[i].seccion;
		secc2.add(option);
	}
 }

function mostrarMsg (req){
	//var resp=eval ("("+ req.responseText +")");
	document.getElementById("contenido").innerHTML =req.responseText;
	}
	
function registrarSolicitudInscripcion() {	
	var opcion = document.getElementById("opcion").value;
	var secc1 = document.getElementById("seccion1").value;
	var secc2 = document.getElementById("seccion2").value;
	var motivo = document.getElementById("motivo").value;	
	// validar secciones
	if (opcion!='0' && motivo!='0') {
	   if (confirm ("Â¿ Esta seguro que desea registrar la Solicitud de la asignatura? "+opcion)){
		AjaxRequest.post( {
				'parameters': { 				   
					'cod_asig':opcion,
					'secc1':secc1,
					'secc2':secc2,
					'motivo':motivo,
					'accion':'registrarSolicitud'
					}
				,'onSuccess': muestraRegistroInscripcion
				,'url':'solicitudes/transaccion/transSolicitudInscripcion.php'
				,'onError': function(req)
				{
					alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
				}
			}
			);
		
		}
		else {return;}
	}
	else { alert ("datos incompletos");	}
	
}

function muestraRegistroInscripcion (req){
	var resp = eval ("("+ req.responseText +")");
	var tabla = "<center><table width='60%' style='color:#000'><tr><th colspan='4'>OPCIONES</th></tr> <tr><td><b>CODIGO</b></Td><td><b>ASIGNATURA</b> </Td><td><b>OPCION 1</b> </Td><td><b>OPCION 2</b> </Td></TR>";
	for (var i=0; i<resp.length; i++){
		 tabla += "<tr><td>"+resp[i].cod_asignatura+"</td><td>"+resp[i].nombre+"</td><td align='center'>"+resp[i].seccion1+"</td><td align='center'>"+resp[i].seccion2+"</td></tr>";		
	}
									  
	tabla += "</table></center> ";
	document.getElementById("mensaje").innerHTML =resp[0].respuesta+tabla;
 }

function muestraSolicitudInscripcion() {
	var cedula = document.getElementById("cedula").value;		
	AjaxRequest.post( {
			'parameters': { 				   
				'cedula':cedula,					
				'accion':'muestraSolicitud'
				}
			,'onSuccess': muestraRegistroInscripcion
			,'url':'solicitudes/transaccion/transSolicitudInscripcion.php'
			,'onError': function(req)
			{
				alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
			}
		}
		);
}


function registraSolicitudInscripcion(){
	var periodo = document.getElementById("periodo").value;	
		AjaxRequest.post( {
				'parameters': { 				   					
					'per':periodo,
					'accion':'consultarDemanda'
					}
				,'onSuccess': mensajeOK
				,'url':'admision/transDemanda.php'
				,'onError': function(req)
				{
					alert('Error!\nStatusText='+req.statusText+'\nContents='+req.responseText);
				}
			}
			);
}

function mensajeOK (req){
	var resp=eval ("("+ req.responseText +")");
	document.getElementById("mensaje").innerHTML =req.responseText;
	}